# Short #2 — Snow IT Employee Project

This is the folder structure for the Bangalore traffic Short using the free Snow character rig in Blender.

## Important rule

Never edit the master rig directly.

- Master file:
  `master/snow_v4_master.blend`

- Working file:
  `working/snow_it_employee_working.blend`

All scripted changes must be made only to the working copy.

## First setup

1. Download the Snow v4 `.blend`.
2. Rename it to:

   `snow_v4_master.blend`

3. Put it inside:

   `master/`

4. Run:

   `prepare_working_copy.ps1`

5. Then run:

   `open_working.ps1`

## Folder purpose

```text
master/             original downloaded Snow file — never modify
working/            active editable Blender file
checkpoints/        automatic backups before scripted changes
scripts/            Blender Python automation
config/             project settings and control mappings
props/              phone, laptop, coffee, cab assets
backgrounds/        Bangalore traffic and cab backgrounds
audio/tts/          generated dialogue
audio/music/        background music
audio/sfx/          horns, traffic, notifications, movement sounds
previews/stills/    review frames
previews/videos/    short preview renders
output/             final MP4 and final .blend
handoff/            rig inspection JSON and ChatGPT handoff files
logs/               Blender execution logs
credits/            licence and attribution files
```

## First automation milestone

After placing the Snow rig, run:

```powershell
.\inspect_rig.ps1
```

It creates:

```text
handoff\snow_rig_inventory.json
logs\inspect_rig.log
```

Upload that JSON here so the next scripts can use the real Snow control names.

## Planned five-second proof

```text
0.0s  seated idle
0.5s  blink
1.2s  look toward traffic
2.0s  look down at phone
2.5s  raise phone
3.5s  surprised expression
4.2s  frustrated head movement
5.0s  hold
```
