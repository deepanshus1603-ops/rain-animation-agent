import bpy
import json
from pathlib import Path
from datetime import datetime

PROJECT = Path(__file__).resolve().parents[1]
HANDOFF = PROJECT / "handoff"
LOGS = PROJECT / "logs"

HANDOFF.mkdir(parents=True, exist_ok=True)
LOGS.mkdir(parents=True, exist_ok=True)

def json_safe(value):
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    try:
        return list(value)
    except Exception:
        return str(value)

data = {
    "generated_at": datetime.now().isoformat(),
    "blender_version": bpy.app.version_string,
    "blend_file": bpy.data.filepath,
    "scene": bpy.context.scene.name if bpy.context.scene else None,
    "objects": [],
    "armatures": [],
    "actions": [],
}

for obj in bpy.data.objects:
    data["objects"].append({
        "name": obj.name,
        "type": obj.type,
        "parent": obj.parent.name if obj.parent else None,
        "hidden_viewport": obj.hide_viewport,
        "hidden_render": obj.hide_render,
    })

    if obj.type == "ARMATURE":
        armature_info = {
            "object_name": obj.name,
            "data_name": obj.data.name,
            "pose_bones": [],
            "collections": [],
        }

        try:
            armature_info["collections"] = [
                collection.name for collection in obj.data.collections
            ]
        except Exception:
            pass

        for bone in obj.pose.bones:
            custom_props = {}
            for key in bone.keys():
                if key == "_RNA_UI":
                    continue
                try:
                    custom_props[key] = json_safe(bone[key])
                except Exception:
                    custom_props[key] = "<unreadable>"

            constraints = []
            for constraint in bone.constraints:
                constraints.append({
                    "name": constraint.name,
                    "type": constraint.type,
                    "mute": constraint.mute,
                    "influence": constraint.influence,
                })

            armature_info["pose_bones"].append({
                "name": bone.name,
                "parent": bone.parent.name if bone.parent else None,
                "rotation_mode": bone.rotation_mode,
                "custom_shape": bone.custom_shape.name if bone.custom_shape else None,
                "custom_properties": custom_props,
                "constraints": constraints,
            })

        data["armatures"].append(armature_info)

for action in bpy.data.actions:
    action_info = {
        "name": action.name,
        "frame_range": [float(action.frame_range[0]), float(action.frame_range[1])],
    }

    try:
        action_info["slots"] = [slot.identifier for slot in action.slots]
    except Exception:
        pass

    data["actions"].append(action_info)

output = HANDOFF / "snow_rig_inventory.json"
output.write_text(json.dumps(data, indent=2), encoding="utf-8")

print("SNOW_RIG_INSPECTION_DONE")
print("Output:", output)
