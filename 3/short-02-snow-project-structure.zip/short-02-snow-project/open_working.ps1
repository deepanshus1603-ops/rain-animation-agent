$ErrorActionPreference = "Stop"

$project = Split-Path -Parent $MyInvocation.MyCommand.Path
$working = Join-Path $project "working\snow_it_employee_working.blend"

if (-not (Test-Path $working)) {
    Write-Host "Working file not found." -ForegroundColor Red
    Write-Host "Run .\prepare_working_copy.ps1 first."
    exit 1
}

$blender = $null

$cmd = Get-Command blender -ErrorAction SilentlyContinue
if ($cmd) {
    $blender = $cmd.Source
}

if (-not $blender -and (Test-Path "C:\Program Files\Blender Foundation")) {
    $found = Get-ChildItem "C:\Program Files\Blender Foundation" `
        -Filter blender.exe -Recurse -ErrorAction SilentlyContinue |
        Sort-Object FullName -Descending |
        Select-Object -First 1

    if ($found) {
        $blender = $found.FullName
    }
}

if (-not $blender) {
    Write-Host "Blender was not found." -ForegroundColor Red
    exit 1
}

Write-Host "Opening with:"
Write-Host $blender

& $blender $working
