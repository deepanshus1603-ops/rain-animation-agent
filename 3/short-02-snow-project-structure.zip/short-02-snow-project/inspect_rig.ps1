$ErrorActionPreference = "Stop"

$project = Split-Path -Parent $MyInvocation.MyCommand.Path
$working = Join-Path $project "working\snow_it_employee_working.blend"
$script = Join-Path $project "scripts\inspect_snow_rig.py"
$log = Join-Path $project "logs\inspect_rig.log"
$output = Join-Path $project "handoff\snow_rig_inventory.json"

if (-not (Test-Path $working)) {
    Write-Host "Working file not found." -ForegroundColor Red
    Write-Host "Run .\prepare_working_copy.ps1 first."
    exit 1
}

$blender = $null

$cmd = Get-Command blender -ErrorAction SilentlyContinue
if ($cmd) {
    $blender = $cmd.Source
}

if (-not $blender -and (Test-Path "C:\Program Files\Blender Foundation")) {
    $found = Get-ChildItem "C:\Program Files\Blender Foundation" `
        -Filter blender.exe -Recurse -ErrorAction SilentlyContinue |
        Sort-Object FullName -Descending |
        Select-Object -First 1

    if ($found) {
        $blender = $found.FullName
    }
}

if (-not $blender) {
    Write-Host "Blender was not found." -ForegroundColor Red
    exit 1
}

if (Test-Path $output) {
    Remove-Item $output -Force
}

Write-Host "Inspecting Snow rig..." -ForegroundColor Cyan

& $blender --background $working --python $script 2>&1 |
    Tee-Object -FilePath $log

if ($LASTEXITCODE -ne 0) {
    Write-Host ""
    Write-Host "Inspection failed. Check:" -ForegroundColor Red
    Write-Host $log
    exit $LASTEXITCODE
}

if (-not (Test-Path $output)) {
    Write-Host "Inspection JSON was not created." -ForegroundColor Red
    exit 2
}

Write-Host ""
Write-Host "SUCCESS" -ForegroundColor Green
Write-Host "Rig inventory:"
Write-Host $output
Write-Host ""
Write-Host "Upload snow_rig_inventory.json here."
