$ErrorActionPreference = "Stop"

$project = Split-Path -Parent $MyInvocation.MyCommand.Path
$master = Join-Path $project "master\snow_v4_master.blend"
$working = Join-Path $project "working\snow_it_employee_working.blend"

if (-not (Test-Path $master)) {
    Write-Host "Master file not found:" -ForegroundColor Red
    Write-Host $master
    Write-Host ""
    Write-Host "Place the downloaded Snow v4 file in master\ and rename it:" -ForegroundColor Yellow
    Write-Host "snow_v4_master.blend"
    exit 1
}

if (Test-Path $working) {
    Write-Host "Working copy already exists:" -ForegroundColor Yellow
    Write-Host $working
    Write-Host "No file was overwritten."
    exit 0
}

Copy-Item $master $working

Write-Host ""
Write-Host "SUCCESS" -ForegroundColor Green
Write-Host "Created working copy:"
Write-Host $working
