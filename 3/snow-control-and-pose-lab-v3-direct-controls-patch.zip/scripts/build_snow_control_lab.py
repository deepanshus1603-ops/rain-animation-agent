import bpy
import json
import math
import shutil
from pathlib import Path
from mathutils import Vector

PROJECT = Path(__file__).resolve().parents[1]
CONFIG = json.loads(
    (PROJECT / "config" / "snow_lab_config.json").read_text(encoding="utf-8")
)
CONTROL_MAP = json.loads(
    (PROJECT / "config" / "snow_control_map.json").read_text(encoding="utf-8")
)

OUT = PROJECT / "previews" / "snow_lab"
HANDOFF = PROJECT / "handoff"
OUT.mkdir(parents=True, exist_ok=True)
HANDOFF.mkdir(parents=True, exist_ok=True)

RIG_NAME = CONFIG["rig_object"]
rig = bpy.data.objects.get(RIG_NAME)

if rig is None or rig.type != "ARMATURE":
    raise RuntimeError(f"Animator rig not found: {RIG_NAME}")

if bpy.data.objects.get("META-Snow") is None:
    print("WARNING: META-Snow was not found, but the animator rig exists.")

scene = bpy.context.scene
scene.render.resolution_x = int(CONFIG["render_resolution"][0])
scene.render.resolution_y = int(CONFIG["render_resolution"][1])
scene.render.resolution_percentage = int(CONFIG["render_percentage"])
scene.render.film_transparent = False
scene.render.image_settings.file_format = "PNG"

try:
    scene.render.engine = "BLENDER_EEVEE"
except TypeError:
    try:
        scene.render.engine = "BLENDER_EEVEE_NEXT"
    except TypeError:
        scene.render.engine = "BLENDER_WORKBENCH"

scene.world.color = (0.035, 0.04, 0.055)

def capture_pose(armature):
    pose = {}
    for bone in armature.pose.bones:
        pose[bone.name] = {
            "location": bone.location.copy(),
            "rotation_mode": bone.rotation_mode,
            "rotation_euler": bone.rotation_euler.copy(),
            "rotation_quaternion": bone.rotation_quaternion.copy(),
            "rotation_axis_angle": tuple(bone.rotation_axis_angle),
            "scale": bone.scale.copy(),
        }
    return pose

def restore_pose(armature, pose):
    for name, values in pose.items():
        bone = armature.pose.bones.get(name)
        if bone is None:
            continue

        bone.location = values["location"]
        bone.scale = values["scale"]
        bone.rotation_mode = values["rotation_mode"]

        if bone.rotation_mode == "QUATERNION":
            bone.rotation_quaternion = values["rotation_quaternion"]
        elif bone.rotation_mode == "AXIS_ANGLE":
            bone.rotation_axis_angle = values["rotation_axis_angle"]
        else:
            bone.rotation_euler = values["rotation_euler"]

    bpy.context.view_layer.update()

def capture_action_state(armature):
    if armature.animation_data is None:
        return None, None
    action = armature.animation_data.action
    slot = None
    try:
        slot = armature.animation_data.action_slot
    except Exception:
        pass
    return action, slot

def restore_action_state(armature, state):
    action, slot = state
    armature.animation_data_create()
    armature.animation_data.action = action
    if slot is not None:
        try:
            armature.animation_data.action_slot = slot
        except Exception:
            pass

def assign_action(armature, action):
    armature.animation_data_create()
    armature.animation_data.action = action
    try:
        if action.slots:
            armature.animation_data.action_slot = action.slots[0]
    except Exception:
        pass

def action_keyframes(action):
    frames = set()

    try:
        for fcurve in action.fcurves:
            for point in fcurve.keyframe_points:
                frames.add(round(float(point.co.x), 5))
    except Exception:
        pass

    if frames:
        return sorted(frames)

    try:
        for layer in action.layers:
            for strip in layer.strips:
                for slot in action.slots:
                    try:
                        channelbag = strip.channelbag(slot)
                    except Exception:
                        channelbag = None

                    if channelbag is None:
                        continue

                    for fcurve in channelbag.fcurves:
                        for point in fcurve.keyframe_points:
                            frames.add(round(float(point.co.x), 5))
    except Exception as exc:
        print("Layered action scan warning:", exc)

    return sorted(frames)

def snow_mesh_objects():
    result = []
    for obj in bpy.data.objects:
        if obj.type != "MESH":
            continue
        if not obj.name.startswith("GEO-snow_"):
            continue
        if obj.hide_render:
            continue
        result.append(obj)
    return result

def world_bounds(objects):
    depsgraph = bpy.context.evaluated_depsgraph_get()
    points = []

    for obj in objects:
        evaluated = obj.evaluated_get(depsgraph)
        matrix = evaluated.matrix_world
        for corner in evaluated.bound_box:
            points.append(matrix @ Vector(corner))

    if not points:
        raise RuntimeError("No Snow render geometry found for camera framing.")

    minimum = Vector((
        min(p.x for p in points),
        min(p.y for p in points),
        min(p.z for p in points),
    ))
    maximum = Vector((
        max(p.x for p in points),
        max(p.y for p in points),
        max(p.z for p in points),
    ))
    return minimum, maximum

def look_at(obj, target):
    direction = Vector(target) - obj.location
    obj.rotation_euler = direction.to_track_quat("-Z", "Y").to_euler()

def ensure_camera(direction_name):
    camera_data = bpy.data.cameras.get("SnowLabCameraData")
    if camera_data is None:
        camera_data = bpy.data.cameras.new("SnowLabCameraData")

    camera = bpy.data.objects.get("SnowLabCamera")
    if camera is None:
        camera = bpy.data.objects.new("SnowLabCamera", camera_data)
        bpy.context.collection.objects.link(camera)

    minimum, maximum = world_bounds(snow_mesh_objects())
    center = (minimum + maximum) * 0.5
    height = maximum.z - minimum.z
    depth = maximum.y - minimum.y
    width = maximum.x - minimum.x

    camera.data.type = "ORTHO"
    camera.data.ortho_scale = max(height * 1.16, width * 1.20)

    distance = max(height, width, depth) * 3.5

    directions = {
        "-Y": Vector((0.0, -1.0, 0.0)),
        "+Y": Vector((0.0, 1.0, 0.0)),
        "-X": Vector((-1.0, 0.0, 0.0)),
        "+X": Vector((1.0, 0.0, 0.0)),
    }
    direction = directions[direction_name]
    camera.location = center + direction * distance
    camera.location.z = center.z
    look_at(camera, center)

    scene.camera = camera
    return camera, center, height

def ensure_lab_lights(center, height):
    for name in ["SnowLabKey", "SnowLabFill", "SnowLabRim"]:
        obj = bpy.data.objects.get(name)
        if obj is not None:
            bpy.data.objects.remove(obj, do_unlink=True)

    specifications = [
        ("SnowLabKey", (4.0, -5.0, 4.0), 1100.0, 4.0),
        ("SnowLabFill", (-4.0, -3.0, 2.5), 650.0, 4.0),
        ("SnowLabRim", (2.0, 4.0, 4.5), 850.0, 3.0),
    ]

    for name, offset, energy, size in specifications:
        data = bpy.data.lights.new(name, type="AREA")
        data.energy = energy
        data.shape = "DISK"
        data.size = size

        obj = bpy.data.objects.new(name, data)
        bpy.context.collection.objects.link(obj)
        obj.location = Vector(center) + Vector(offset) * (height / 2.0)
        look_at(obj, center)

def render_still(path):
    scene.render.filepath = str(path)
    bpy.ops.render.render(write_still=True)

def write_gallery(folder, title, files):
    html = [
        "<!doctype html>",
        "<html><head><meta charset='utf-8'>",
        f"<title>{title}</title>",
        "<style>",
        "body{font-family:Segoe UI,Arial;background:#15171c;color:#fff;margin:20px}",
        ".grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:16px}",
        ".card{background:#242832;border-radius:12px;padding:10px}",
        "img{width:100%;height:auto;border-radius:8px;background:#333}",
        "code{color:#ffdc73}",
        "</style></head><body>",
        f"<h1>{title}</h1>",
        "<div class='grid'>"
    ]

    for file in files:
        html.append(
            "<div class='card'>"
            f"<img src='{file.name}' alt='{file.stem}'>"
            f"<p><code>{file.stem}</code></p>"
            "</div>"
        )

    html.extend(["</div></body></html>"])
    (folder / "index.html").write_text("\n".join(html), encoding="utf-8")


def normalized_bone_name(name):
    return "".join(character.lower() for character in name if character.isalnum())

def describe_eye_candidates(armature):
    candidates = []
    for bone in armature.pose.bones:
        lowered = bone.name.lower()
        if "eye" in lowered or "tgt" in lowered or "aim" in lowered:
            candidates.append({
                "name": bone.name,
                "parent": bone.parent.name if bone.parent else None,
                "custom_shape": bone.custom_shape.name if bone.custom_shape else None,
            })
    return candidates

def resolve_eye_target_controls(preferred_armature, preferred_name):
    """
    Resolve the gaze control without assuming one exact bone name.

    Resolution order:
    1. exact preferred name on RIG-Snow;
    2. case-insensitive or normalized-name match on RIG-Snow;
    3. best non-helper TGT/Eye control on RIG-Snow;
    4. paired TGT-Eye.L and TGT-Eye.R controls;
    5. exact/best match on another armature as a last diagnostic fallback.

    Returns:
        eye_armature, [pose_bones], resolution_method
    """
    exact = preferred_armature.pose.bones.get(preferred_name)
    if exact is not None:
        return preferred_armature, [exact], "exact"

    preferred_lower = preferred_name.lower()
    preferred_normalized = normalized_bone_name(preferred_name)

    for bone in preferred_armature.pose.bones:
        if bone.name.lower() == preferred_lower:
            return preferred_armature, [bone], "case_insensitive_exact"

    for bone in preferred_armature.pose.bones:
        if normalized_bone_name(bone.name) == preferred_normalized:
            return preferred_armature, [bone], "normalized_exact"

    # Prefer a visible master target, excluding parent/helper/display bones.
    master_candidates = []
    child_candidates = []

    for bone in preferred_armature.pose.bones:
        lowered = bone.name.lower()

        if "eye" not in lowered or "tgt" not in lowered:
            continue

        if lowered.startswith(("p-", "dsp-", "org-", "def-", "mch-", "str-")):
            continue

        if "mstr" in lowered or "master" in lowered:
            master_candidates.append(bone)
        elif lowered.startswith("tgt-eye"):
            child_candidates.append(bone)

    if master_candidates:
        master_candidates.sort(
            key=lambda bone: (
                0 if bone.custom_shape and bone.custom_shape.name == "WGT-Circle" else 1,
                len(bone.name),
                bone.name,
            )
        )
        return preferred_armature, [master_candidates[0]], "discovered_master_target"

    left = preferred_armature.pose.bones.get("TGT-Eye.L")
    right = preferred_armature.pose.bones.get("TGT-Eye.R")

    if left is not None and right is not None:
        return preferred_armature, [left, right], "paired_eye_targets"

    if len(child_candidates) >= 2:
        child_candidates.sort(key=lambda bone: bone.name)
        return preferred_armature, child_candidates[:2], "discovered_paired_targets"

    if len(child_candidates) == 1:
        return preferred_armature, child_candidates, "single_discovered_target"

    # Search another armature only as a last resort. This is useful if the
    # downloaded rig variant stores the gaze target on a separate control rig.
    for obj in bpy.data.objects:
        if obj.type != "ARMATURE" or obj == preferred_armature:
            continue

        exact = obj.pose.bones.get(preferred_name)
        if exact is not None:
            return obj, [exact], f"exact_on_{obj.name}"

        discovered = []
        for bone in obj.pose.bones:
            lowered = bone.name.lower()
            if (
                "eye" in lowered
                and "tgt" in lowered
                and not lowered.startswith(("p-", "dsp-", "org-", "def-", "mch-", "str-"))
            ):
                discovered.append(bone)

        if discovered:
            discovered.sort(
                key=lambda bone: (
                    0 if "mstr" in bone.name.lower() else 1,
                    len(bone.name),
                    bone.name,
                )
            )
            return obj, [discovered[0]], f"discovered_on_{obj.name}"

    return preferred_armature, [], "not_found"


original_pose = capture_pose(rig)
original_action_state = capture_action_state(rig)
original_frame = scene.frame_current

# Remove any assigned action while running transform-axis tests.
rig.animation_data_create()
rig.animation_data.action = None
restore_pose(rig, original_pose)

# ------------------------------------------------------------------
# Camera direction gallery
# ------------------------------------------------------------------
view_folder = OUT / "01_camera_views"
view_folder.mkdir(parents=True, exist_ok=True)
view_files = []

for view in ["-Y", "+Y", "-X", "+X"]:
    camera, center, height = ensure_camera(view)
    ensure_lab_lights(center, height)
    file = view_folder / f"view_{view.replace('+','pos').replace('-','neg')}.png"
    render_still(file)
    view_files.append(file)

write_gallery(view_folder, "Snow Camera Direction Lab", view_files)

# Use configured direction for the remaining labs.
camera, center, height = ensure_camera(CONFIG["camera_view"])
ensure_lab_lights(center, height)

# ------------------------------------------------------------------
# Head rotation axis lab
# ------------------------------------------------------------------
head_folder = OUT / "02_head_axes"
head_folder.mkdir(parents=True, exist_ok=True)
head_files = []

head_name = CONTROL_MAP["controls"]["head"]
head = rig.pose.bones.get(head_name)
if head is None:
    raise RuntimeError(f"Head control missing: {head_name}")

tests = [("neutral", None, 0.0)]
degrees = float(CONFIG["head_rotation_degrees"])

for axis_index, axis_name in enumerate(["x", "y", "z"]):
    tests.append((f"{axis_name}_plus", axis_index, degrees))
    tests.append((f"{axis_name}_minus", axis_index, -degrees))

for label, axis_index, angle in tests:
    restore_pose(rig, original_pose)

    if axis_index is not None:
        head.rotation_mode = "XYZ"
        head.rotation_euler[axis_index] += math.radians(angle)

    bpy.context.view_layer.update()
    file = head_folder / f"head_{label}.png"
    render_still(file)
    head_files.append(file)

write_gallery(head_folder, "Snow Head Axis Lab", head_files)

# ------------------------------------------------------------------
# Eye target translation axis lab
# ------------------------------------------------------------------
eye_folder = OUT / "03_eye_target_axes"
eye_folder.mkdir(parents=True, exist_ok=True)
eye_files = []

eye_name = CONTROL_MAP["controls"]["eye_target"]
eye_rig, eye_targets, eye_resolution = resolve_eye_target_controls(
    rig,
    eye_name,
)

eye_diagnostic = {
    "preferred_control": eye_name,
    "resolved_armature": eye_rig.name if eye_rig else None,
    "resolved_controls": [bone.name for bone in eye_targets],
    "resolution_method": eye_resolution,
    "rig_snow_candidates": describe_eye_candidates(rig),
}

(HANDOFF / "snow_eye_target_resolution.json").write_text(
    json.dumps(eye_diagnostic, indent=2),
    encoding="utf-8",
)

print("Eye target resolution method:", eye_resolution)
print("Eye target armature:", eye_rig.name if eye_rig else None)
print("Eye target controls:", [bone.name for bone in eye_targets])

eye_tests = [("neutral", None, 0.0)]
delta = float(CONFIG["eye_target_delta"])

for axis_index, axis_name in enumerate(["x", "y", "z"]):
    eye_tests.append((f"{axis_name}_plus", axis_index, delta))
    eye_tests.append((f"{axis_name}_minus", axis_index, -delta))

if eye_targets:
    # Capture/restore the resolved armature separately if it is not RIG-Snow.
    eye_original_pose = (
        original_pose
        if eye_rig == rig
        else capture_pose(eye_rig)
    )

    for label, axis_index, amount in eye_tests:
        restore_pose(rig, original_pose)

        if eye_rig != rig:
            restore_pose(eye_rig, eye_original_pose)

        if axis_index is not None:
            for eye_target in eye_targets:
                eye_target.location[axis_index] += amount

        bpy.context.view_layer.update()
        file = eye_folder / f"eyes_{label}.png"
        render_still(file)
        eye_files.append(file)

    if eye_rig != rig:
        restore_pose(eye_rig, eye_original_pose)
else:
    # Do not abort the whole lab. Render a neutral reference and continue
    # with blink and body-pose galleries.
    restore_pose(rig, original_pose)
    file = eye_folder / "eyes_control_not_found_neutral.png"
    render_still(file)
    eye_files.append(file)

    warning = eye_folder / "EYE_CONTROL_NOT_FOUND.txt"
    warning.write_text(
        "No gaze target control could be resolved.\n"
        "See handoff/snow_eye_target_resolution.json for runtime candidates.\n",
        encoding="utf-8",
    )

write_gallery(
    eye_folder,
    f"Snow Eye Target Axis Lab — {eye_resolution}",
    eye_files,
)

# ------------------------------------------------------------------
# Direct eyelid control lab (does not depend on missing pose actions)
# ------------------------------------------------------------------
eyelid_folder = OUT / "04_eyelid_direct_controls"
eyelid_folder.mkdir(parents=True, exist_ok=True)
eyelid_files = []

def resolve_pose_bone(armature, preferred_name, keywords=()):
    exact = armature.pose.bones.get(preferred_name)
    if exact is not None:
        return exact, "exact"

    normalized_preferred = normalized_bone_name(preferred_name)
    for bone in armature.pose.bones:
        if normalized_bone_name(bone.name) == normalized_preferred:
            return bone, "normalized"

    lowered_keywords = [keyword.lower() for keyword in keywords]
    candidates = []
    for bone in armature.pose.bones:
        lowered = bone.name.lower()
        if all(keyword in lowered for keyword in lowered_keywords):
            candidates.append(bone)

    if candidates:
        candidates.sort(key=lambda bone: (len(bone.name), bone.name))
        return candidates[0], "keyword"

    return None, "not_found"

upper_left, upper_left_method = resolve_pose_bone(
    rig, "MSTR-Eyelid_Upper.L", ("mstr", "eyelid", "upper", ".l")
)
upper_right, upper_right_method = resolve_pose_bone(
    rig, "MSTR-Eyelid_Upper.R", ("mstr", "eyelid", "upper", ".r")
)
lower_left, lower_left_method = resolve_pose_bone(
    rig, "MSTR-Eyelid_Lower.L", ("mstr", "eyelid", "lower", ".l")
)
lower_right, lower_right_method = resolve_pose_bone(
    rig, "MSTR-Eyelid_Lower.R", ("mstr", "eyelid", "lower", ".r")
)

eyelid_controls = {
    "upper_left": upper_left.name if upper_left else None,
    "upper_right": upper_right.name if upper_right else None,
    "lower_left": lower_left.name if lower_left else None,
    "lower_right": lower_right.name if lower_right else None,
    "resolution_methods": {
        "upper_left": upper_left_method,
        "upper_right": upper_right_method,
        "lower_left": lower_left_method,
        "lower_right": lower_right_method,
    },
}

(HANDOFF / "snow_eyelid_control_resolution.json").write_text(
    json.dumps(eyelid_controls, indent=2),
    encoding="utf-8",
)

# Use a close face camera so eyelid changes are visible.
restore_pose(rig, original_pose)
head_world = rig.matrix_world @ head.matrix.translation
camera, center, height = ensure_camera(CONFIG["camera_view"])
face_direction = Vector((0.0, -1.0, 0.0))
face_distance = max(height, 1.0) * 3.5
camera.location = head_world + face_direction * face_distance
camera.location.z = head_world.z
look_at(camera, head_world)
camera.data.ortho_scale = max(height * 0.32, 0.78)
ensure_lab_lights(head_world, max(height * 0.35, 0.8))

# Neutral face reference.
restore_pose(rig, original_pose)
bpy.context.view_layer.update()
neutral_file = eyelid_folder / "eyelids_neutral.png"
render_still(neutral_file)
eyelid_files.append(neutral_file)

upper_pair = [bone for bone in (upper_left, upper_right) if bone is not None]
lower_pair = [bone for bone in (lower_left, lower_right) if bone is not None]

eyelid_delta = float(CONFIG.get("eyelid_test_delta", 0.055))

for group_name, controls in [("upper", upper_pair), ("lower", lower_pair)]:
    if not controls:
        continue

    for axis_index, axis_name in enumerate(["x", "y", "z"]):
        for direction_name, sign in [("plus", 1.0), ("minus", -1.0)]:
            restore_pose(rig, original_pose)
            for control in controls:
                control.location[axis_index] += sign * eyelid_delta
            bpy.context.view_layer.update()
            file = eyelid_folder / (
                f"eyelid_{group_name}_{axis_name}_{direction_name}.png"
            )
            render_still(file)
            eyelid_files.append(file)

write_gallery(
    eyelid_folder,
    "Snow Direct Eyelid Control Lab",
    eyelid_files,
)

# ------------------------------------------------------------------
# Manual seated-pose candidates (does not depend on Snow_BodyPoses)
# ------------------------------------------------------------------
seat_folder = OUT / "05_manual_seated_candidates"
seat_folder.mkdir(parents=True, exist_ok=True)
seat_files = []

required_seat_names = {
    "torso": "MSTR-Spine_Torso",
    "hips": "MSTR-Spine_Hips",
    "chest": "MSTR-Spine_Chest",
    "left_foot": "IK-MSTR-Foot.L",
    "right_foot": "IK-MSTR-Foot.R",
    "left_knee": "IK-POLE-Thigh.L",
    "right_knee": "IK-POLE-Thigh.R",
    "properties": "Properties",
}

seat_controls = {}
for key, preferred in required_seat_names.items():
    bone, method = resolve_pose_bone(rig, preferred, tuple(preferred.lower().replace('-', ' ').replace('.', ' ').split()))
    seat_controls[key] = {
        "preferred": preferred,
        "resolved": bone.name if bone else None,
        "method": method,
    }

(HANDOFF / "snow_seated_control_resolution.json").write_text(
    json.dumps(seat_controls, indent=2),
    encoding="utf-8",
)

resolved = {
    key: rig.pose.bones.get(info["resolved"]) if info["resolved"] else None
    for key, info in seat_controls.items()
}

# Enable leg IK when the properties control exposes the expected values.
properties_bone = resolved.get("properties")
if properties_bone is not None:
    for prop_name in ["ik_left_thigh", "ik_right_thigh"]:
        if prop_name in properties_bone:
            properties_bone[prop_name] = 1.0
    for prop_name in ["ik_stretch_left_thigh", "ik_stretch_right_thigh"]:
        if prop_name in properties_bone:
            properties_bone[prop_name] = 0.25

seat_candidates = [
    {
        "name": "A_shallow",
        "torso_drop": 0.34,
        "foot_forward": 0.28,
        "foot_up": 0.04,
        "knee_forward": 0.50,
        "knee_up": 0.16,
        "torso_pitch_degrees": 2.0,
    },
    {
        "name": "B_medium",
        "torso_drop": 0.52,
        "foot_forward": 0.46,
        "foot_up": 0.07,
        "knee_forward": 0.72,
        "knee_up": 0.23,
        "torso_pitch_degrees": 4.0,
    },
    {
        "name": "C_deep",
        "torso_drop": 0.70,
        "foot_forward": 0.62,
        "foot_up": 0.10,
        "knee_forward": 0.92,
        "knee_up": 0.30,
        "torso_pitch_degrees": 6.0,
    },
]

seat_ready = all(
    resolved.get(key) is not None
    for key in ["torso", "left_foot", "right_foot", "left_knee", "right_knee"]
)

if seat_ready:
    for candidate in seat_candidates:
        restore_pose(rig, original_pose)

        torso_control = resolved["torso"]
        torso_control.location.z -= candidate["torso_drop"]
        torso_control.rotation_mode = "XYZ"
        torso_control.rotation_euler[0] += math.radians(
            candidate["torso_pitch_degrees"]
        )

        # Snow faces -Y in the selected front view, so negative local Y moves
        # feet and knee poles toward the front of the cab.
        resolved["left_foot"].location.y -= candidate["foot_forward"]
        resolved["right_foot"].location.y -= candidate["foot_forward"]
        resolved["left_foot"].location.z += candidate["foot_up"]
        resolved["right_foot"].location.z += candidate["foot_up"]

        resolved["left_knee"].location.y -= candidate["knee_forward"]
        resolved["right_knee"].location.y -= candidate["knee_forward"]
        resolved["left_knee"].location.z += candidate["knee_up"]
        resolved["right_knee"].location.z += candidate["knee_up"]

        bpy.context.view_layer.update()

        for view_name in ["-Y", "+X"]:
            camera, center, height = ensure_camera(view_name)
            ensure_lab_lights(center, height)
            file = seat_folder / (
                f"seat_{candidate['name']}_{view_name.replace('+','pos').replace('-','neg')}.png"
            )
            render_still(file)
            seat_files.append(file)
else:
    restore_pose(rig, original_pose)
    camera, center, height = ensure_camera(CONFIG["camera_view"])
    ensure_lab_lights(center, height)
    file = seat_folder / "seat_controls_missing_neutral.png"
    render_still(file)
    seat_files.append(file)
    (seat_folder / "SEATED_CONTROLS_MISSING.txt").write_text(
        "One or more manual sitting controls were not resolved.\n"
        "See handoff/snow_seated_control_resolution.json.\n",
        encoding="utf-8",
    )

write_gallery(
    seat_folder,
    "Snow Manual Seated Pose Candidates",
    seat_files,
)

# ------------------------------------------------------------------
# Runtime action inventory (informational only; never required)
# ------------------------------------------------------------------
action_inventory = []
for action in bpy.data.actions:
    action_inventory.append({
        "name": action.name,
        "frame_range": [
            float(action.frame_range[0]),
            float(action.frame_range[1]),
        ],
    })

(HANDOFF / "snow_runtime_actions.json").write_text(
    json.dumps(action_inventory, indent=2),
    encoding="utf-8",
)

manifest = {
    "blender_version": bpy.app.version_string,
    "blend_file": bpy.data.filepath,
    "rig_object": rig.name,
    "camera_view_used": CONFIG["camera_view"],
    "head_control": head_name,
    "eye_target_preferred": eye_name,
    "eye_target_resolution_method": eye_resolution,
    "eye_target_armature": eye_rig.name if eye_rig else None,
    "eye_target_controls": [bone.name for bone in eye_targets],
    "head_test_degrees": degrees,
    "eye_target_test_delta": delta,
    "eyelid_controls": eyelid_controls,
    "eyelid_files": [str(path.relative_to(PROJECT)) for path in eyelid_files],
    "seat_controls": seat_controls,
    "seat_candidates": seat_candidates if seat_ready else [],
    "seat_file_count": len(seat_files),
    "runtime_action_count": len(action_inventory),
    "output_folder": str(OUT),
}

(HANDOFF / "snow_control_lab_manifest.json").write_text(
    json.dumps(manifest, indent=2),
    encoding="utf-8",
)

# Restore the unsaved working session state before exit.
restore_action_state(rig, original_action_state)
restore_pose(rig, original_pose)
scene.frame_set(original_frame)

print("SNOW_CONTROL_LAB_DONE")
print("Results:", OUT)
print("Manifest:", HANDOFF / "snow_control_lab_manifest.json")
