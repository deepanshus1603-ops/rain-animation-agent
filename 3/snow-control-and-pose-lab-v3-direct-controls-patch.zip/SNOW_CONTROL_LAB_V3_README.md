# Snow Control Lab V3 — Direct Controls

The current full Snow package does not expose the optional pose-library actions
at runtime:

- `Snow_eyemask_default`
- `Snow_eyemask_closed`
- `Snow_BodyPoses`

Those actions are convenient extras, not required for animation. V3 removes all
dependence on them.

## What V3 tests directly

1. Camera directions
2. Head rotation axes
3. Paired eye targets (`TGT-Eye.L` and `TGT-Eye.R`)
4. Upper/lower eyelid master controls, using close-up face renders
5. Three manually generated seated-pose candidates using real torso, foot-IK
   and knee-pole controls
6. A runtime action inventory for information only

## Install

Extract the ZIP and copy everything into:

```text
short-02-snow-project\
```

Replace existing files.

## Run

```powershell
.\run_snow_control_lab.ps1
```

## Review

Open:

```text
previews\snow_lab\04_eyelid_direct_controls\index.html
previews\snow_lab\05_manual_seated_candidates\index.html
```

The sitting candidates are deliberately calibration poses:

- A — shallow bend
- B — medium bend
- C — deep bend

Each has front and side views.

## Upload

```text
handoff\snow_control_lab_results.zip
```

That ZIP now includes the rendered galleries and all generated diagnostic JSON
files.
