$ErrorActionPreference = "Stop"

$project = Split-Path -Parent $MyInvocation.MyCommand.Path
$working = Join-Path $project "working\snow_it_employee_working.blend"
$script = Join-Path $project "scripts\build_snow_control_lab.py"
$checkpointDir = Join-Path $project "checkpoints"
$logDir = Join-Path $project "logs"
$handoffDir = Join-Path $project "handoff"
$resultFolder = Join-Path $project "previews\snow_lab"
$manifest = Join-Path $handoffDir "snow_control_lab_manifest.json"
$resultZip = Join-Path $handoffDir "snow_control_lab_results.zip"

$stdoutLog = Join-Path $logDir "snow_control_lab_stdout.log"
$stderrLog = Join-Path $logDir "snow_control_lab_stderr.log"
$combinedLog = Join-Path $logDir "snow_control_lab.log"

if (-not (Test-Path $working)) {
    Write-Host "FAILED: Working file not found." -ForegroundColor Red
    Write-Host $working
    exit 1
}

if (-not (Test-Path $script)) {
    Write-Host "FAILED: Blender lab script not found." -ForegroundColor Red
    Write-Host $script
    exit 2
}

$blender = $null

$cmd = Get-Command blender -ErrorAction SilentlyContinue
if ($cmd) {
    $blender = $cmd.Source
}

if (-not $blender -and (Test-Path "C:\Program Files\Blender Foundation")) {
    $found = Get-ChildItem "C:\Program Files\Blender Foundation" `
        -Filter blender.exe -Recurse -ErrorAction SilentlyContinue |
        Sort-Object FullName -Descending |
        Select-Object -First 1

    if ($found) {
        $blender = $found.FullName
    }
}

if (-not $blender) {
    Write-Host "FAILED: Blender executable not found." -ForegroundColor Red
    exit 3
}

New-Item -ItemType Directory -Force -Path $checkpointDir | Out-Null
New-Item -ItemType Directory -Force -Path $logDir | Out-Null
New-Item -ItemType Directory -Force -Path $handoffDir | Out-Null

$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$checkpoint = Join-Path $checkpointDir "snow_before_control_lab_$timestamp.blend"
Copy-Item $working $checkpoint -Force

if (Test-Path $resultFolder) {
    Remove-Item $resultFolder -Recurse -Force
}

foreach ($file in @($manifest, $resultZip, $stdoutLog, $stderrLog, $combinedLog)) {
    if (Test-Path $file) {
        Remove-Item $file -Force
    }
}

Write-Host "Using Blender: $blender" -ForegroundColor Cyan
Write-Host "Checkpoint: $checkpoint" -ForegroundColor Cyan
Write-Host "Running Snow control and pose lab..." -ForegroundColor Cyan
Write-Host "Blender stdout/stderr will be captured safely." -ForegroundColor Yellow

# Start-Process avoids PowerShell converting Blender stderr into a terminating
# NativeCommandError when ErrorActionPreference is Stop.
$arguments = @(
    "--background",
    "`"$working`"",
    "--python",
    "`"$script`""
)

$process = Start-Process `
    -FilePath $blender `
    -ArgumentList $arguments `
    -NoNewWindow `
    -Wait `
    -PassThru `
    -RedirectStandardOutput $stdoutLog `
    -RedirectStandardError $stderrLog

$stdout = ""
$stderr = ""

if (Test-Path $stdoutLog) {
    $stdout = Get-Content $stdoutLog -Raw
}

if (Test-Path $stderrLog) {
    $stderr = Get-Content $stderrLog -Raw
}

@(
    "===== STDOUT ====="
    $stdout
    ""
    "===== STDERR ====="
    $stderr
) | Set-Content $combinedLog

if ($stdout) {
    Write-Host $stdout
}

if ($stderr) {
    Write-Host ""
    Write-Host "Blender stderr:" -ForegroundColor Yellow
    Write-Host $stderr
}

if ($process.ExitCode -ne 0) {
    Write-Host ""
    Write-Host "FAILED: Blender returned exit code $($process.ExitCode)." -ForegroundColor Red
    Write-Host "Full combined log:" -ForegroundColor Yellow
    Write-Host $combinedLog
    Write-Host ""
    Write-Host "Last 60 log lines:" -ForegroundColor Yellow
    Get-Content $combinedLog -Tail 60
    exit $process.ExitCode
}

if (-not (Test-Path $manifest)) {
    Write-Host ""
    Write-Host "FAILED: Lab manifest was not created." -ForegroundColor Red
    Write-Host "Check:" -ForegroundColor Yellow
    Write-Host $combinedLog
    exit 4
}

if (-not (Test-Path $resultFolder)) {
    Write-Host ""
    Write-Host "FAILED: Lab image folder was not created." -ForegroundColor Red
    Write-Host "Check:" -ForegroundColor Yellow
    Write-Host $combinedLog
    exit 5
}

$packageFolder = Join-Path $project "_snow_lab_handoff_package"
if (Test-Path $packageFolder) { Remove-Item $packageFolder -Recurse -Force }
New-Item -ItemType Directory -Force -Path $packageFolder | Out-Null
Copy-Item $resultFolder (Join-Path $packageFolder "snow_lab") -Recurse -Force
Get-ChildItem $handoffDir -File -Filter "snow_*.json" | ForEach-Object {
    Copy-Item $_.FullName (Join-Path $packageFolder $_.Name) -Force
}
Compress-Archive -Path "$packageFolder\*" -DestinationPath $resultZip -Force
Remove-Item $packageFolder -Recurse -Force

Write-Host ""
Write-Host "SUCCESS" -ForegroundColor Green
Write-Host "The working .blend was not overwritten."
Write-Host ""
Write-Host "Open galleries under:"
Write-Host "  previews\snow_lab\01_camera_views\index.html"
Write-Host "  previews\snow_lab\02_head_axes\index.html"
Write-Host "  previews\snow_lab\03_eye_target_axes\index.html"
Write-Host "  previews\snow_lab\04_eyelid_direct_controls\index.html"
Write-Host "  previews\snow_lab\05_manual_seated_candidates\index.html"
Write-Host ""
Write-Host "Upload:"
Write-Host "  handoff\snow_control_lab_results.zip"
