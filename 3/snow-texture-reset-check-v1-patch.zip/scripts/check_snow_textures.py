import bpy
import json
from pathlib import Path
from datetime import datetime
from mathutils import Vector

PROJECT = Path(__file__).resolve().parents[1]
PREVIEW = PROJECT / "previews" / "texture_check"
HANDOFF = PROJECT / "handoff"
PREVIEW.mkdir(parents=True, exist_ok=True)
HANDOFF.mkdir(parents=True, exist_ok=True)


def packed_status(image):
    try:
        if image.packed_file is not None:
            return True
    except Exception:
        pass
    try:
        if len(image.packed_files) > 0:
            return True
    except Exception:
        pass
    return False


def absolute_image_path(image):
    raw = image.filepath or image.filepath_raw or ""
    if not raw:
        return ""
    try:
        return bpy.path.abspath(raw, library=image.library)
    except Exception:
        try:
            return bpy.path.abspath(raw)
        except Exception:
            return raw


def image_users(image):
    users = []
    for material in bpy.data.materials:
        if not material.use_nodes or material.node_tree is None:
            continue
        for node in material.node_tree.nodes:
            if node.type == "TEX_IMAGE" and node.image == image:
                users.append({"material": material.name, "node": node.name})
    return users


report = {
    "generated_at": datetime.now().isoformat(),
    "blender_version": bpy.app.version_string,
    "blend_file": bpy.data.filepath,
    "images": [],
    "summary": {},
}

missing = []
external = []
packed = []

for image in bpy.data.images:
    path = absolute_image_path(image)
    is_packed = packed_status(image)
    exists = False

    if image.source == "FILE" and path:
        exists = Path(path).exists()

    is_missing = image.source == "FILE" and not is_packed and bool(path) and not exists

    entry = {
        "name": image.name,
        "source": image.source,
        "filepath_raw": image.filepath_raw,
        "absolute_path": path,
        "packed": is_packed,
        "exists": exists,
        "missing": is_missing,
        "size": [int(image.size[0]), int(image.size[1])],
        "users": image_users(image),
    }
    report["images"].append(entry)

    if is_missing:
        missing.append(entry)
    elif is_packed:
        packed.append(entry)
    elif image.source == "FILE":
        external.append(entry)

report["summary"] = {
    "total_images": len(report["images"]),
    "packed_images": len(packed),
    "available_external_images": len(external),
    "missing_external_images": len(missing),
    "textures_ok": len(missing) == 0,
}

report_path = HANDOFF / "snow_texture_report.json"
report_path.write_text(json.dumps(report, indent=2), encoding="utf-8")

# Build a simple front camera without modifying or saving the working file.
render_meshes = [
    obj for obj in bpy.data.objects
    if obj.type == "MESH" and obj.name.startswith("GEO-snow_") and not obj.hide_render
]

if not render_meshes:
    raise RuntimeError("No visible Snow render meshes found.")

points = []
depsgraph = bpy.context.evaluated_depsgraph_get()
for obj in render_meshes:
    evaluated = obj.evaluated_get(depsgraph)
    for corner in evaluated.bound_box:
        points.append(evaluated.matrix_world @ Vector(corner))

minimum = Vector((
    min(p.x for p in points),
    min(p.y for p in points),
    min(p.z for p in points),
))
maximum = Vector((
    max(p.x for p in points),
    max(p.y for p in points),
    max(p.z for p in points),
))
center = (minimum + maximum) * 0.5
height = maximum.z - minimum.z
width = maximum.x - minimum.x
depth = maximum.y - minimum.y

camera_data = bpy.data.cameras.new("SnowTextureCheckCameraData")
camera = bpy.data.objects.new("SnowTextureCheckCamera", camera_data)
bpy.context.collection.objects.link(camera)
camera.data.type = "ORTHO"
camera.data.ortho_scale = max(height * 1.15, width * 1.25)
distance = max(height, width, depth) * 3.5
camera.location = center + Vector((0.0, -distance, 0.0))
camera.location.z = center.z
camera.rotation_euler = (Vector(center) - camera.location).to_track_quat("-Z", "Y").to_euler()

scene = bpy.context.scene
scene.camera = camera
scene.render.resolution_x = 360
scene.render.resolution_y = 640
scene.render.resolution_percentage = 100
scene.render.image_settings.file_format = "PNG"
scene.render.film_transparent = False
scene.world.color = (0.035, 0.04, 0.055)

try:
    scene.render.engine = "BLENDER_EEVEE"
except TypeError:
    try:
        scene.render.engine = "BLENDER_EEVEE_NEXT"
    except TypeError:
        scene.render.engine = "BLENDER_WORKBENCH"


def look_at(obj, target):
    obj.rotation_euler = (Vector(target) - obj.location).to_track_quat("-Z", "Y").to_euler()

for index, (offset, energy, size) in enumerate([
    ((4.0, -5.0, 4.0), 1100.0, 4.0),
    ((-4.0, -3.0, 2.5), 650.0, 4.0),
    ((2.0, 4.0, 4.5), 850.0, 3.0),
]):
    data = bpy.data.lights.new(f"SnowTextureCheckLight{index}", type="AREA")
    data.energy = energy
    data.shape = "DISK"
    data.size = size
    obj = bpy.data.objects.new(f"SnowTextureCheckLight{index}", data)
    bpy.context.collection.objects.link(obj)
    obj.location = center + Vector(offset) * (height / 2.0)
    look_at(obj, center)

preview_path = PREVIEW / "snow_front_texture_check.png"
scene.render.filepath = str(preview_path)
bpy.ops.render.render(write_still=True)

print("SNOW_TEXTURE_CHECK_DONE")
print("Missing external images:", len(missing))
print("Report:", report_path)
print("Preview:", preview_path)
