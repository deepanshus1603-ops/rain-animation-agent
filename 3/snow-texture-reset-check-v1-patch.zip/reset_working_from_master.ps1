$ErrorActionPreference = "Stop"

$project = Split-Path -Parent $MyInvocation.MyCommand.Path
$master = Join-Path $project "master\snow_v4_master.blend"
$working = Join-Path $project "working\snow_it_employee_working.blend"
$checkpointDir = Join-Path $project "checkpoints"

if (-not (Test-Path $master)) {
    Write-Host "FAILED: Master Snow file not found:" -ForegroundColor Red
    Write-Host $master
    exit 1
}

$masterSize = (Get-Item $master).Length
$masterSizeMB = $masterSize / 1MB

Write-Host ("Master size: {0:N2} MB" -f $masterSizeMB) -ForegroundColor Cyan

if ($masterSize -lt 50MB) {
    Write-Host "" 
    Write-Host "FAILED: This Snow file is too small and is probably incomplete." -ForegroundColor Red
    Write-Host "Download the full official Snow v4 file, then replace:" -ForegroundColor Yellow
    Write-Host "  master\snow_v4_master.blend"
    exit 2
}

New-Item -ItemType Directory -Force -Path $checkpointDir | Out-Null
New-Item -ItemType Directory -Force -Path (Split-Path $working) | Out-Null

if (Test-Path $working) {
    $timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
    $checkpoint = Join-Path $checkpointDir "snow_working_before_full_rig_$timestamp.blend"
    Copy-Item $working $checkpoint
    Write-Host "Backed up existing working file:" -ForegroundColor Cyan
    Write-Host $checkpoint
}

Copy-Item $master $working -Force

Write-Host ""
Write-Host "SUCCESS" -ForegroundColor Green
Write-Host "Working copy refreshed from the full master:"
Write-Host $working
Write-Host ("Working size: {0:N2} MB" -f ((Get-Item $working).Length / 1MB))
