# Snow Full-Rig Reset and Texture Check

The Snow control lab rendered the entire character magenta. In Blender, that indicates missing image textures.

The current small master file should be replaced with the full official Snow v4 download before animation continues.

## 1. Replace the master file

Download the full Snow v4 rig from Blender Studio.

Place it here with this exact name:

```text
master\snow_v4_master.blend
```

## 2. Refresh the working copy safely

```powershell
.\reset_working_from_master.ps1
```

The script:

- rejects suspiciously small master files;
- creates a checkpoint of the current working file;
- replaces only the working copy;
- never edits the master.

## 3. Verify textures

```powershell
.\run_snow_texture_check.ps1
```

Expected terminal result:

```text
Missing external images: 0
Textures OK: True
```

It creates:

```text
handoff\snow_texture_check_results.zip
```

Upload that ZIP next.

## Why animation is paused

The control lab itself succeeded:

- front camera direction was identified;
- head axes were identified;
- blink action worked;
- body pose library was reviewed.

However, no final animation should be built while all materials render magenta.
