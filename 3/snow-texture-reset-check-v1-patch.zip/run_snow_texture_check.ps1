$ErrorActionPreference = "Stop"

$project = Split-Path -Parent $MyInvocation.MyCommand.Path
$working = Join-Path $project "working\snow_it_employee_working.blend"
$script = Join-Path $project "scripts\check_snow_textures.py"
$log = Join-Path $project "logs\snow_texture_check.log"
$report = Join-Path $project "handoff\snow_texture_report.json"
$preview = Join-Path $project "previews\texture_check\snow_front_texture_check.png"
$resultZip = Join-Path $project "handoff\snow_texture_check_results.zip"

if (-not (Test-Path $working)) {
    Write-Host "FAILED: Working file not found." -ForegroundColor Red
    Write-Host "Run .\reset_working_from_master.ps1 first."
    exit 1
}

$blender = $null
$cmd = Get-Command blender -ErrorAction SilentlyContinue
if ($cmd) { $blender = $cmd.Source }

if (-not $blender -and (Test-Path "C:\Program Files\Blender Foundation")) {
    $found = Get-ChildItem "C:\Program Files\Blender Foundation" `
        -Filter blender.exe -Recurse -ErrorAction SilentlyContinue |
        Sort-Object FullName -Descending |
        Select-Object -First 1
    if ($found) { $blender = $found.FullName }
}

if (-not $blender) {
    Write-Host "FAILED: Blender executable not found." -ForegroundColor Red
    exit 2
}

New-Item -ItemType Directory -Force -Path (Split-Path $log) | Out-Null
New-Item -ItemType Directory -Force -Path (Split-Path $report) | Out-Null

if (Test-Path $report) { Remove-Item $report -Force }
if (Test-Path $preview) { Remove-Item $preview -Force }
if (Test-Path $resultZip) { Remove-Item $resultZip -Force }

Write-Host "Using Blender: $blender" -ForegroundColor Cyan
Write-Host "Checking Snow textures..." -ForegroundColor Cyan

& $blender --background $working --python $script 2>&1 |
    Tee-Object -FilePath $log

if ($LASTEXITCODE -ne 0) {
    Write-Host "FAILED: Blender returned exit code $LASTEXITCODE." -ForegroundColor Red
    exit $LASTEXITCODE
}

if (-not (Test-Path $report)) {
    Write-Host "FAILED: Texture report was not created." -ForegroundColor Red
    exit 3
}

if (-not (Test-Path $preview)) {
    Write-Host "FAILED: Texture preview was not created." -ForegroundColor Red
    exit 4
}

$temp = Join-Path $project "handoff\_snow_texture_results"
if (Test-Path $temp) { Remove-Item $temp -Recurse -Force }
New-Item -ItemType Directory -Force -Path $temp | Out-Null
Copy-Item $report (Join-Path $temp "snow_texture_report.json")
Copy-Item $preview (Join-Path $temp "snow_front_texture_check.png")
Compress-Archive -Path "$temp\*" -DestinationPath $resultZip -Force
Remove-Item $temp -Recurse -Force

$summary = Get-Content $report -Raw | ConvertFrom-Json
Write-Host ""
Write-Host "SUCCESS" -ForegroundColor Green
Write-Host ("Missing external images: {0}" -f $summary.summary.missing_external_images)
Write-Host ("Textures OK: {0}" -f $summary.summary.textures_ok)
Write-Host "Upload: handoff\snow_texture_check_results.zip"
