import bpy
import json
import math
import shutil
from pathlib import Path
from mathutils import Vector

PROJECT = Path(__file__).resolve().parents[1]
CONFIG = json.loads(
    (PROJECT / "config" / "snow_lab_config.json").read_text(encoding="utf-8")
)
CONTROL_MAP = json.loads(
    (PROJECT / "config" / "snow_control_map.json").read_text(encoding="utf-8")
)

OUT = PROJECT / "previews" / "snow_lab"
HANDOFF = PROJECT / "handoff"
OUT.mkdir(parents=True, exist_ok=True)
HANDOFF.mkdir(parents=True, exist_ok=True)

RIG_NAME = CONFIG["rig_object"]
rig = bpy.data.objects.get(RIG_NAME)

if rig is None or rig.type != "ARMATURE":
    raise RuntimeError(f"Animator rig not found: {RIG_NAME}")

if bpy.data.objects.get("META-Snow") is None:
    print("WARNING: META-Snow was not found, but the animator rig exists.")

scene = bpy.context.scene
scene.render.resolution_x = int(CONFIG["render_resolution"][0])
scene.render.resolution_y = int(CONFIG["render_resolution"][1])
scene.render.resolution_percentage = int(CONFIG["render_percentage"])
scene.render.film_transparent = False
scene.render.image_settings.file_format = "PNG"

try:
    scene.render.engine = "BLENDER_EEVEE"
except TypeError:
    try:
        scene.render.engine = "BLENDER_EEVEE_NEXT"
    except TypeError:
        scene.render.engine = "BLENDER_WORKBENCH"

scene.world.color = (0.035, 0.04, 0.055)

def capture_pose(armature):
    pose = {}
    for bone in armature.pose.bones:
        pose[bone.name] = {
            "location": bone.location.copy(),
            "rotation_mode": bone.rotation_mode,
            "rotation_euler": bone.rotation_euler.copy(),
            "rotation_quaternion": bone.rotation_quaternion.copy(),
            "rotation_axis_angle": tuple(bone.rotation_axis_angle),
            "scale": bone.scale.copy(),
        }
    return pose

def restore_pose(armature, pose):
    for name, values in pose.items():
        bone = armature.pose.bones.get(name)
        if bone is None:
            continue

        bone.location = values["location"]
        bone.scale = values["scale"]
        bone.rotation_mode = values["rotation_mode"]

        if bone.rotation_mode == "QUATERNION":
            bone.rotation_quaternion = values["rotation_quaternion"]
        elif bone.rotation_mode == "AXIS_ANGLE":
            bone.rotation_axis_angle = values["rotation_axis_angle"]
        else:
            bone.rotation_euler = values["rotation_euler"]

    bpy.context.view_layer.update()

def capture_action_state(armature):
    if armature.animation_data is None:
        return None, None
    action = armature.animation_data.action
    slot = None
    try:
        slot = armature.animation_data.action_slot
    except Exception:
        pass
    return action, slot

def restore_action_state(armature, state):
    action, slot = state
    armature.animation_data_create()
    armature.animation_data.action = action
    if slot is not None:
        try:
            armature.animation_data.action_slot = slot
        except Exception:
            pass

def assign_action(armature, action):
    armature.animation_data_create()
    armature.animation_data.action = action
    try:
        if action.slots:
            armature.animation_data.action_slot = action.slots[0]
    except Exception:
        pass

def action_keyframes(action):
    frames = set()

    try:
        for fcurve in action.fcurves:
            for point in fcurve.keyframe_points:
                frames.add(round(float(point.co.x), 5))
    except Exception:
        pass

    if frames:
        return sorted(frames)

    try:
        for layer in action.layers:
            for strip in layer.strips:
                for slot in action.slots:
                    try:
                        channelbag = strip.channelbag(slot)
                    except Exception:
                        channelbag = None

                    if channelbag is None:
                        continue

                    for fcurve in channelbag.fcurves:
                        for point in fcurve.keyframe_points:
                            frames.add(round(float(point.co.x), 5))
    except Exception as exc:
        print("Layered action scan warning:", exc)

    return sorted(frames)

def snow_mesh_objects():
    result = []
    for obj in bpy.data.objects:
        if obj.type != "MESH":
            continue
        if not obj.name.startswith("GEO-snow_"):
            continue
        if obj.hide_render:
            continue
        result.append(obj)
    return result

def world_bounds(objects):
    depsgraph = bpy.context.evaluated_depsgraph_get()
    points = []

    for obj in objects:
        evaluated = obj.evaluated_get(depsgraph)
        matrix = evaluated.matrix_world
        for corner in evaluated.bound_box:
            points.append(matrix @ Vector(corner))

    if not points:
        raise RuntimeError("No Snow render geometry found for camera framing.")

    minimum = Vector((
        min(p.x for p in points),
        min(p.y for p in points),
        min(p.z for p in points),
    ))
    maximum = Vector((
        max(p.x for p in points),
        max(p.y for p in points),
        max(p.z for p in points),
    ))
    return minimum, maximum

def look_at(obj, target):
    direction = Vector(target) - obj.location
    obj.rotation_euler = direction.to_track_quat("-Z", "Y").to_euler()

def ensure_camera(direction_name):
    camera_data = bpy.data.cameras.get("SnowLabCameraData")
    if camera_data is None:
        camera_data = bpy.data.cameras.new("SnowLabCameraData")

    camera = bpy.data.objects.get("SnowLabCamera")
    if camera is None:
        camera = bpy.data.objects.new("SnowLabCamera", camera_data)
        bpy.context.collection.objects.link(camera)

    minimum, maximum = world_bounds(snow_mesh_objects())
    center = (minimum + maximum) * 0.5
    height = maximum.z - minimum.z
    depth = maximum.y - minimum.y
    width = maximum.x - minimum.x

    camera.data.type = "ORTHO"
    camera.data.ortho_scale = max(height * 1.16, width * 1.20)

    distance = max(height, width, depth) * 3.5

    directions = {
        "-Y": Vector((0.0, -1.0, 0.0)),
        "+Y": Vector((0.0, 1.0, 0.0)),
        "-X": Vector((-1.0, 0.0, 0.0)),
        "+X": Vector((1.0, 0.0, 0.0)),
    }
    direction = directions[direction_name]
    camera.location = center + direction * distance
    camera.location.z = center.z
    look_at(camera, center)

    scene.camera = camera
    return camera, center, height

def ensure_lab_lights(center, height):
    for name in ["SnowLabKey", "SnowLabFill", "SnowLabRim"]:
        obj = bpy.data.objects.get(name)
        if obj is not None:
            bpy.data.objects.remove(obj, do_unlink=True)

    specifications = [
        ("SnowLabKey", (4.0, -5.0, 4.0), 1100.0, 4.0),
        ("SnowLabFill", (-4.0, -3.0, 2.5), 650.0, 4.0),
        ("SnowLabRim", (2.0, 4.0, 4.5), 850.0, 3.0),
    ]

    for name, offset, energy, size in specifications:
        data = bpy.data.lights.new(name, type="AREA")
        data.energy = energy
        data.shape = "DISK"
        data.size = size

        obj = bpy.data.objects.new(name, data)
        bpy.context.collection.objects.link(obj)
        obj.location = Vector(center) + Vector(offset) * (height / 2.0)
        look_at(obj, center)

def render_still(path):
    scene.render.filepath = str(path)
    bpy.ops.render.render(write_still=True)

def write_gallery(folder, title, files):
    html = [
        "<!doctype html>",
        "<html><head><meta charset='utf-8'>",
        f"<title>{title}</title>",
        "<style>",
        "body{font-family:Segoe UI,Arial;background:#15171c;color:#fff;margin:20px}",
        ".grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:16px}",
        ".card{background:#242832;border-radius:12px;padding:10px}",
        "img{width:100%;height:auto;border-radius:8px;background:#333}",
        "code{color:#ffdc73}",
        "</style></head><body>",
        f"<h1>{title}</h1>",
        "<div class='grid'>"
    ]

    for file in files:
        html.append(
            "<div class='card'>"
            f"<img src='{file.name}' alt='{file.stem}'>"
            f"<p><code>{file.stem}</code></p>"
            "</div>"
        )

    html.extend(["</div></body></html>"])
    (folder / "index.html").write_text("\n".join(html), encoding="utf-8")


def normalized_bone_name(name):
    return "".join(character.lower() for character in name if character.isalnum())

def describe_eye_candidates(armature):
    candidates = []
    for bone in armature.pose.bones:
        lowered = bone.name.lower()
        if "eye" in lowered or "tgt" in lowered or "aim" in lowered:
            candidates.append({
                "name": bone.name,
                "parent": bone.parent.name if bone.parent else None,
                "custom_shape": bone.custom_shape.name if bone.custom_shape else None,
            })
    return candidates

def resolve_eye_target_controls(preferred_armature, preferred_name):
    """
    Resolve the gaze control without assuming one exact bone name.

    Resolution order:
    1. exact preferred name on RIG-Snow;
    2. case-insensitive or normalized-name match on RIG-Snow;
    3. best non-helper TGT/Eye control on RIG-Snow;
    4. paired TGT-Eye.L and TGT-Eye.R controls;
    5. exact/best match on another armature as a last diagnostic fallback.

    Returns:
        eye_armature, [pose_bones], resolution_method
    """
    exact = preferred_armature.pose.bones.get(preferred_name)
    if exact is not None:
        return preferred_armature, [exact], "exact"

    preferred_lower = preferred_name.lower()
    preferred_normalized = normalized_bone_name(preferred_name)

    for bone in preferred_armature.pose.bones:
        if bone.name.lower() == preferred_lower:
            return preferred_armature, [bone], "case_insensitive_exact"

    for bone in preferred_armature.pose.bones:
        if normalized_bone_name(bone.name) == preferred_normalized:
            return preferred_armature, [bone], "normalized_exact"

    # Prefer a visible master target, excluding parent/helper/display bones.
    master_candidates = []
    child_candidates = []

    for bone in preferred_armature.pose.bones:
        lowered = bone.name.lower()

        if "eye" not in lowered or "tgt" not in lowered:
            continue

        if lowered.startswith(("p-", "dsp-", "org-", "def-", "mch-", "str-")):
            continue

        if "mstr" in lowered or "master" in lowered:
            master_candidates.append(bone)
        elif lowered.startswith("tgt-eye"):
            child_candidates.append(bone)

    if master_candidates:
        master_candidates.sort(
            key=lambda bone: (
                0 if bone.custom_shape and bone.custom_shape.name == "WGT-Circle" else 1,
                len(bone.name),
                bone.name,
            )
        )
        return preferred_armature, [master_candidates[0]], "discovered_master_target"

    left = preferred_armature.pose.bones.get("TGT-Eye.L")
    right = preferred_armature.pose.bones.get("TGT-Eye.R")

    if left is not None and right is not None:
        return preferred_armature, [left, right], "paired_eye_targets"

    if len(child_candidates) >= 2:
        child_candidates.sort(key=lambda bone: bone.name)
        return preferred_armature, child_candidates[:2], "discovered_paired_targets"

    if len(child_candidates) == 1:
        return preferred_armature, child_candidates, "single_discovered_target"

    # Search another armature only as a last resort. This is useful if the
    # downloaded rig variant stores the gaze target on a separate control rig.
    for obj in bpy.data.objects:
        if obj.type != "ARMATURE" or obj == preferred_armature:
            continue

        exact = obj.pose.bones.get(preferred_name)
        if exact is not None:
            return obj, [exact], f"exact_on_{obj.name}"

        discovered = []
        for bone in obj.pose.bones:
            lowered = bone.name.lower()
            if (
                "eye" in lowered
                and "tgt" in lowered
                and not lowered.startswith(("p-", "dsp-", "org-", "def-", "mch-", "str-"))
            ):
                discovered.append(bone)

        if discovered:
            discovered.sort(
                key=lambda bone: (
                    0 if "mstr" in bone.name.lower() else 1,
                    len(bone.name),
                    bone.name,
                )
            )
            return obj, [discovered[0]], f"discovered_on_{obj.name}"

    return preferred_armature, [], "not_found"


original_pose = capture_pose(rig)
original_action_state = capture_action_state(rig)
original_frame = scene.frame_current

# Remove any assigned action while running transform-axis tests.
rig.animation_data_create()
rig.animation_data.action = None
restore_pose(rig, original_pose)

# ------------------------------------------------------------------
# Camera direction gallery
# ------------------------------------------------------------------
view_folder = OUT / "01_camera_views"
view_folder.mkdir(parents=True, exist_ok=True)
view_files = []

for view in ["-Y", "+Y", "-X", "+X"]:
    camera, center, height = ensure_camera(view)
    ensure_lab_lights(center, height)
    file = view_folder / f"view_{view.replace('+','pos').replace('-','neg')}.png"
    render_still(file)
    view_files.append(file)

write_gallery(view_folder, "Snow Camera Direction Lab", view_files)

# Use configured direction for the remaining labs.
camera, center, height = ensure_camera(CONFIG["camera_view"])
ensure_lab_lights(center, height)

# ------------------------------------------------------------------
# Head rotation axis lab
# ------------------------------------------------------------------
head_folder = OUT / "02_head_axes"
head_folder.mkdir(parents=True, exist_ok=True)
head_files = []

head_name = CONTROL_MAP["controls"]["head"]
head = rig.pose.bones.get(head_name)
if head is None:
    raise RuntimeError(f"Head control missing: {head_name}")

tests = [("neutral", None, 0.0)]
degrees = float(CONFIG["head_rotation_degrees"])

for axis_index, axis_name in enumerate(["x", "y", "z"]):
    tests.append((f"{axis_name}_plus", axis_index, degrees))
    tests.append((f"{axis_name}_minus", axis_index, -degrees))

for label, axis_index, angle in tests:
    restore_pose(rig, original_pose)

    if axis_index is not None:
        head.rotation_mode = "XYZ"
        head.rotation_euler[axis_index] += math.radians(angle)

    bpy.context.view_layer.update()
    file = head_folder / f"head_{label}.png"
    render_still(file)
    head_files.append(file)

write_gallery(head_folder, "Snow Head Axis Lab", head_files)

# ------------------------------------------------------------------
# Eye target translation axis lab
# ------------------------------------------------------------------
eye_folder = OUT / "03_eye_target_axes"
eye_folder.mkdir(parents=True, exist_ok=True)
eye_files = []

eye_name = CONTROL_MAP["controls"]["eye_target"]
eye_rig, eye_targets, eye_resolution = resolve_eye_target_controls(
    rig,
    eye_name,
)

eye_diagnostic = {
    "preferred_control": eye_name,
    "resolved_armature": eye_rig.name if eye_rig else None,
    "resolved_controls": [bone.name for bone in eye_targets],
    "resolution_method": eye_resolution,
    "rig_snow_candidates": describe_eye_candidates(rig),
}

(HANDOFF / "snow_eye_target_resolution.json").write_text(
    json.dumps(eye_diagnostic, indent=2),
    encoding="utf-8",
)

print("Eye target resolution method:", eye_resolution)
print("Eye target armature:", eye_rig.name if eye_rig else None)
print("Eye target controls:", [bone.name for bone in eye_targets])

eye_tests = [("neutral", None, 0.0)]
delta = float(CONFIG["eye_target_delta"])

for axis_index, axis_name in enumerate(["x", "y", "z"]):
    eye_tests.append((f"{axis_name}_plus", axis_index, delta))
    eye_tests.append((f"{axis_name}_minus", axis_index, -delta))

if eye_targets:
    # Capture/restore the resolved armature separately if it is not RIG-Snow.
    eye_original_pose = (
        original_pose
        if eye_rig == rig
        else capture_pose(eye_rig)
    )

    for label, axis_index, amount in eye_tests:
        restore_pose(rig, original_pose)

        if eye_rig != rig:
            restore_pose(eye_rig, eye_original_pose)

        if axis_index is not None:
            for eye_target in eye_targets:
                eye_target.location[axis_index] += amount

        bpy.context.view_layer.update()
        file = eye_folder / f"eyes_{label}.png"
        render_still(file)
        eye_files.append(file)

    if eye_rig != rig:
        restore_pose(eye_rig, eye_original_pose)
else:
    # Do not abort the whole lab. Render a neutral reference and continue
    # with blink and body-pose galleries.
    restore_pose(rig, original_pose)
    file = eye_folder / "eyes_control_not_found_neutral.png"
    render_still(file)
    eye_files.append(file)

    warning = eye_folder / "EYE_CONTROL_NOT_FOUND.txt"
    warning.write_text(
        "No gaze target control could be resolved.\n"
        "See handoff/snow_eye_target_resolution.json for runtime candidates.\n",
        encoding="utf-8",
    )

write_gallery(
    eye_folder,
    f"Snow Eye Target Axis Lab — {eye_resolution}",
    eye_files,
)

# ------------------------------------------------------------------
# Blink pose actions
# ------------------------------------------------------------------
blink_folder = OUT / "04_blink_actions"
blink_folder.mkdir(parents=True, exist_ok=True)
blink_files = []

for label, action_name in CONFIG["blink_actions"].items():
    action = bpy.data.actions.get(action_name)
    if action is None:
        print("Missing blink action:", action_name)
        continue

    restore_pose(rig, original_pose)
    assign_action(rig, action)

    frame = int(round(float(action.frame_range[0])))
    scene.frame_set(frame)
    bpy.context.view_layer.update()

    file = blink_folder / f"blink_{label}_frame_{frame:03d}.png"
    render_still(file)
    blink_files.append(file)

write_gallery(blink_folder, "Snow Blink Pose Actions", blink_files)

# ------------------------------------------------------------------
# Body pose library gallery
# ------------------------------------------------------------------
body_folder = OUT / "05_body_pose_library"
body_folder.mkdir(parents=True, exist_ok=True)
body_files = []

body_action_name = CONFIG["body_pose_action"]
body_action = bpy.data.actions.get(body_action_name)

if body_action is None:
    raise RuntimeError(f"Body pose action missing: {body_action_name}")

restore_pose(rig, original_pose)
assign_action(rig, body_action)

frames = action_keyframes(body_action)

if not frames:
    frames = list(range(
        int(CONFIG["body_pose_fallback_start"]),
        int(CONFIG["body_pose_fallback_end"]) + 1,
        int(CONFIG["body_pose_fallback_step"])
    ))

# Keep integer frames and remove very dense duplicates.
integer_frames = sorted(set(int(round(frame)) for frame in frames))

# If the action contains too many keyed frames, pose libraries commonly
# store poses in 10-frame increments. Prefer those for the gallery.
if len(integer_frames) > 40:
    integer_frames = [
        frame for frame in integer_frames
        if frame % int(CONFIG["body_pose_fallback_step"]) == 0
    ]

for frame in integer_frames:
    scene.frame_set(frame)
    bpy.context.view_layer.update()

    file = body_folder / f"body_pose_frame_{frame:03d}.png"
    render_still(file)
    body_files.append(file)

write_gallery(
    body_folder,
    f"Snow Body Pose Library — {body_action_name}",
    body_files
)

manifest = {
    "blender_version": bpy.app.version_string,
    "blend_file": bpy.data.filepath,
    "rig_object": rig.name,
    "camera_view_used": CONFIG["camera_view"],
    "head_control": head_name,
    "eye_target_preferred": eye_name,
    "eye_target_resolution_method": eye_resolution,
    "eye_target_armature": eye_rig.name if eye_rig else None,
    "eye_target_controls": [bone.name for bone in eye_targets],
    "head_test_degrees": degrees,
    "eye_target_test_delta": delta,
    "blink_files": [str(path.relative_to(PROJECT)) for path in blink_files],
    "body_pose_action": body_action_name,
    "body_pose_frames": integer_frames,
    "body_pose_file_count": len(body_files),
    "output_folder": str(OUT),
}

(HANDOFF / "snow_control_lab_manifest.json").write_text(
    json.dumps(manifest, indent=2),
    encoding="utf-8",
)

# Restore the unsaved working session state before exit.
restore_action_state(rig, original_action_state)
restore_pose(rig, original_pose)
scene.frame_set(original_frame)

print("SNOW_CONTROL_LAB_DONE")
print("Results:", OUT)
print("Manifest:", HANDOFF / "snow_control_lab_manifest.json")
