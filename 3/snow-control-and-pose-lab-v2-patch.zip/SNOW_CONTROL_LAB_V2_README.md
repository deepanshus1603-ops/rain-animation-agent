# Snow Control and Pose Lab V2

This patch fixes the runtime error:

```text
RuntimeError: Eye target control missing: MSTR-TGT-Eyes
```

The uploaded rig inventory does contain these gaze-related controls:

```text
P-MSTR-TGT-Eyes
MSTR-TGT-Eyes
TGT-Eye.L
TGT-Eye.R
```

However, the lab now avoids relying on one hard-coded runtime name.

## V2 resolution strategy

The script tries:

1. exact `MSTR-TGT-Eyes`;
2. case-insensitive and normalized-name matching;
3. another master target containing `TGT` and `Eye`;
4. the pair `TGT-Eye.L` and `TGT-Eye.R`;
5. another armature as a diagnostic fallback.

If no usable eye target is found, the script writes a diagnostic JSON and
continues with blink and body-pose rendering instead of aborting the lab.

## Install

Extract this ZIP and copy all contents into:

```text
short-02-snow-project\
```

Replace the existing files when Windows asks.

## Run

```powershell
.\run_snow_control_lab.ps1
```

## New diagnostic output

```text
handoff\snow_eye_target_resolution.json
```

## Expected result

The lab should finish and create:

```text
handoff\snow_control_lab_results.zip
```

Upload that ZIP next.

If the eye target is still unusual, also upload:

```text
handoff\snow_eye_target_resolution.json
```
