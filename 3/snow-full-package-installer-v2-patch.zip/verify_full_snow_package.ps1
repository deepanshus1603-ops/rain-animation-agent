$ErrorActionPreference = "Stop"

$project = Split-Path -Parent $MyInvocation.MyCommand.Path

$targets = @(
    @{
        Name = "Master"
        Blend = Join-Path $project "master\snow_v4_master.blend"
        Textures = Join-Path $project "master\textures"
    },
    @{
        Name = "Working"
        Blend = Join-Path $project "working\snow_it_employee_working.blend"
        Textures = Join-Path $project "working\textures"
    }
)

$failed = $false

foreach ($target in $targets) {
    Write-Host ""
    Write-Host "$($target.Name) package" -ForegroundColor Cyan

    if (-not (Test-Path $target.Blend)) {
        Write-Host "Missing blend: $($target.Blend)" -ForegroundColor Red
        $failed = $true
        continue
    }

    if (-not (Test-Path $target.Textures)) {
        Write-Host "Missing textures: $($target.Textures)" -ForegroundColor Red
        $failed = $true
        continue
    }

    $blend = Get-Item $target.Blend
    $files = Get-ChildItem $target.Textures -File -Recurse
    $sizeMB = [math]::Round(
        (($files | Measure-Object Length -Sum).Sum / 1MB),
        2
    )

    Write-Host "Blend size: $([math]::Round($blend.Length / 1MB, 2)) MB"
    Write-Host "Texture files: $($files.Count)"
    Write-Host "Texture size: $sizeMB MB"

    $required = @(
        "eyes_diffuse.png",
        "hair_diffuse.png",
        "pants_diffuse.png",
        "shirt_diffuse.png",
        "shoes_diffuse.png",
        "skin_diffuse.1001.png"
    )

    foreach ($fileName in $required) {
        $match = Get-ChildItem $target.Textures -File -Recurse |
            Where-Object { $_.Name -eq $fileName } |
            Select-Object -First 1

        if (-not $match) {
            Write-Host "Missing required texture: $fileName" -ForegroundColor Red
            $failed = $true
        }
    }
}

Write-Host ""

if ($failed) {
    Write-Host "VERIFY FAILED" -ForegroundColor Red
    exit 1
}

Write-Host "VERIFY PASS" -ForegroundColor Green
Write-Host "Both master and working packages contain the complete texture set."
