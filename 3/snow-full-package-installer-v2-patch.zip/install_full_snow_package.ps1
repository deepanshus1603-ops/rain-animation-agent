param(
    [string]$ZipPath = ""
)

$ErrorActionPreference = "Stop"

$project = Split-Path -Parent $MyInvocation.MyCommand.Path
$masterDir = Join-Path $project "master"
$workingDir = Join-Path $project "working"
$checkpointDir = Join-Path $project "checkpoints"
$tempDir = Join-Path $project "_snow_package_install_temp"

New-Item -ItemType Directory -Force -Path $masterDir | Out-Null
New-Item -ItemType Directory -Force -Path $workingDir | Out-Null
New-Item -ItemType Directory -Force -Path $checkpointDir | Out-Null

if (-not $ZipPath) {
    $candidates = @(
        (Join-Path $project "Snow_v4.2.zip"),
        (Join-Path (Split-Path $project -Parent) "Snow_v4.2.zip"),
        (Join-Path $env:USERPROFILE "Downloads\Snow_v4.2.zip")
    )

    foreach ($candidate in $candidates) {
        if (Test-Path $candidate) {
            $ZipPath = $candidate
            break
        }
    }
}

if (-not $ZipPath -or -not (Test-Path $ZipPath)) {
    Write-Host "FAILED: Snow_v4.2.zip was not found." -ForegroundColor Red
    Write-Host ""
    Write-Host "Either place Snow_v4.2.zip in the project root, or run:" -ForegroundColor Yellow
    Write-Host '.\install_full_snow_package.ps1 -ZipPath "C:\path\to\Snow_v4.2.zip"'
    exit 1
}

Write-Host "Using Snow package:" -ForegroundColor Cyan
Write-Host $ZipPath

if (Test-Path $tempDir) {
    Remove-Item $tempDir -Recurse -Force
}

New-Item -ItemType Directory -Force -Path $tempDir | Out-Null
Expand-Archive -LiteralPath $ZipPath -DestinationPath $tempDir -Force

$blend = Get-ChildItem $tempDir -Recurse -File -Filter "*.blend" |
    Where-Object { $_.Name -match "snow" } |
    Select-Object -First 1

$textures = Get-ChildItem $tempDir -Recurse -Directory |
    Where-Object { $_.Name -eq "textures" } |
    Select-Object -First 1

if (-not $blend) {
    Write-Host "FAILED: No Snow .blend file was found inside the ZIP." -ForegroundColor Red
    exit 2
}

if (-not $textures) {
    Write-Host "FAILED: No textures folder was found inside the ZIP." -ForegroundColor Red
    exit 3
}

$textureFiles = Get-ChildItem $textures.FullName -File -Recurse
$textureSizeMB = [math]::Round(
    (($textureFiles | Measure-Object Length -Sum).Sum / 1MB),
    2
)

Write-Host ""
Write-Host "Package check:" -ForegroundColor Cyan
Write-Host "Blend: $($blend.Name)"
Write-Host "Blend size: $([math]::Round($blend.Length / 1MB, 2)) MB"
Write-Host "Texture files: $($textureFiles.Count)"
Write-Host "Texture size: $textureSizeMB MB"

if ($textureFiles.Count -lt 25 -or $textureSizeMB -lt 70) {
    Write-Host "FAILED: The texture package appears incomplete." -ForegroundColor Red
    exit 4
}

$masterBlend = Join-Path $masterDir "snow_v4_master.blend"
$workingBlend = Join-Path $workingDir "snow_it_employee_working.blend"
$masterTextures = Join-Path $masterDir "textures"
$workingTextures = Join-Path $workingDir "textures"

$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"

if (Test-Path $workingBlend) {
    $backup = Join-Path $checkpointDir "snow_working_before_full_package_$timestamp.blend"
    Copy-Item $workingBlend $backup -Force
    Write-Host "Backed up old working blend:" -ForegroundColor Yellow
    Write-Host $backup
}

if (Test-Path $masterTextures) {
    Remove-Item $masterTextures -Recurse -Force
}

if (Test-Path $workingTextures) {
    Remove-Item $workingTextures -Recurse -Force
}

Copy-Item $blend.FullName $masterBlend -Force
Copy-Item $blend.FullName $workingBlend -Force

Copy-Item $textures.FullName $masterTextures -Recurse -Force
Copy-Item $textures.FullName $workingTextures -Recurse -Force

Remove-Item $tempDir -Recurse -Force

$masterTextureCount = (Get-ChildItem $masterTextures -File -Recurse).Count
$workingTextureCount = (Get-ChildItem $workingTextures -File -Recurse).Count

if (-not (Test-Path $masterBlend)) {
    Write-Host "FAILED: Master blend was not installed." -ForegroundColor Red
    exit 5
}

if (-not (Test-Path $workingBlend)) {
    Write-Host "FAILED: Working blend was not installed." -ForegroundColor Red
    exit 6
}

if ($masterTextureCount -ne $textureFiles.Count) {
    Write-Host "FAILED: Master texture copy is incomplete." -ForegroundColor Red
    exit 7
}

if ($workingTextureCount -ne $textureFiles.Count) {
    Write-Host "FAILED: Working texture copy is incomplete." -ForegroundColor Red
    exit 8
}

Write-Host ""
Write-Host "SUCCESS" -ForegroundColor Green
Write-Host "The complete Snow package is installed."
Write-Host ""
Write-Host "Master:"
Write-Host "  master\snow_v4_master.blend"
Write-Host "  master\textures\"
Write-Host ""
Write-Host "Working:"
Write-Host "  working\snow_it_employee_working.blend"
Write-Host "  working\textures\"
Write-Host ""
Write-Host "Next run:"
Write-Host "  .\run_snow_control_lab.ps1"
