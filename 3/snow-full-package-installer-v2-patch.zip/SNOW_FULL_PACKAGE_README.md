# Snow Full Package Installer V2

You were correct: the Snow download is a ZIP package made of:

```text
Snow\
├── snow_v4.2.blend
└── textures\
    ├── eyes_diffuse.png
    ├── hair_diffuse.png
    ├── pants_diffuse.png
    ├── skin_diffuse.1001.png
    └── many more images
```

The `.blend` itself is only around 8 MB. Most of the download size is the
external texture folder.

The magenta renders happened because only the `.blend` file was copied into
the project. Blender expects the `textures` folder beside the `.blend`.

## Install this patch

Extract this patch and copy these files into:

```text
short-02-snow-project\
```

You should then have:

```text
install_full_snow_package.ps1
verify_full_snow_package.ps1
```

## Run

The installer automatically searches:

1. the project root;
2. the parent directory;
3. your Downloads folder.

Place `Snow_v4.2.zip` in one of those locations, then run:

```powershell
.\install_full_snow_package.ps1
```

You can also give the path explicitly:

```powershell
.\install_full_snow_package.ps1 `
  -ZipPath "C:\Users\Dipanshu\Downloads\Snow_v4.2.zip"
```

The script creates:

```text
master\
├── snow_v4_master.blend
└── textures\

working\
├── snow_it_employee_working.blend
└── textures\
```

It also backs up the previous working `.blend` into `checkpoints`.

## Verify

```powershell
.\verify_full_snow_package.ps1
```

Expected ending:

```text
VERIFY PASS
```

## Then rerun the control lab

```powershell
.\run_snow_control_lab.ps1
```

The new rendered galleries should show Snow's real materials instead of
magenta.
