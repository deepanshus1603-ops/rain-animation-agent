@echo off
powershell -ExecutionPolicy Bypass -File "%~dp0run_snow_control_lab.ps1"
pause
