# Snow Control and Pose Lab V1

This is a patch for the existing:

```text
short-02-snow-project
```

It uses the actual control names found in `snow_rig_inventory.json`.

## Why this lab comes before the first animation

The Snow rig is professional, but we still need to identify:

1. which camera direction shows the front of the character;
2. which local head axis is yaw, pitch and tilt;
3. which eye-target axis moves the gaze left/right and up/down;
4. whether the supplied closed-eye pose action works correctly;
5. whether the supplied `Snow_BodyPoses` library already contains a useful seated pose.

This avoids guessing rotations and repeating the arm-calibration problem from the old PNG puppet.

## Install the patch

Extract the ZIP.

Copy its contents directly into the existing project root:

```text
short-02-snow-project\
```

After copying, the project root should contain:

```text
run_snow_control_lab.ps1
scripts\build_snow_control_lab.py
config\snow_control_map.json
config\snow_lab_config.json
```

## Run

```powershell
.\run_snow_control_lab.ps1
```

The launcher:

- verifies `working\snow_it_employee_working.blend`;
- creates a timestamped checkpoint;
- runs Blender in background mode;
- does not save changes into the working file;
- renders low-resolution review images;
- creates a ZIP for upload.

## Review galleries

Open these in a browser:

```text
previews\snow_lab\01_camera_views\index.html
previews\snow_lab\02_head_axes\index.html
previews\snow_lab\03_eye_target_axes\index.html
previews\snow_lab\04_blink_actions\index.html
previews\snow_lab\05_body_pose_library\index.html
```

## Upload next

Upload:

```text
handoff\snow_control_lab_results.zip
```

After reviewing it, the next package will create:

```text
seated idle
→ blink
→ look toward traffic
→ look down at phone
→ raise phone with real arm IK
→ surprised reaction
```

## Camera correction

The default camera direction is:

```json
"camera_view": "-Y"
```

If the camera gallery shows that `+Y` is the front, change the value in:

```text
config\snow_lab_config.json
```

and run the lab again.
