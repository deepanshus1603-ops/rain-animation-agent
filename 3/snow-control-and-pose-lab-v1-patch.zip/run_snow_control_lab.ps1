$ErrorActionPreference = "Stop"

$project = Split-Path -Parent $MyInvocation.MyCommand.Path
$working = Join-Path $project "working\snow_it_employee_working.blend"
$script = Join-Path $project "scripts\build_snow_control_lab.py"
$checkpointDir = Join-Path $project "checkpoints"
$log = Join-Path $project "logs\snow_control_lab.log"
$manifest = Join-Path $project "handoff\snow_control_lab_manifest.json"
$resultFolder = Join-Path $project "previews\snow_lab"
$resultZip = Join-Path $project "handoff\snow_control_lab_results.zip"

if (-not (Test-Path $working)) {
    Write-Host "FAILED: Working file not found." -ForegroundColor Red
    Write-Host $working
    exit 1
}

$blender = $null
$cmd = Get-Command blender -ErrorAction SilentlyContinue

if ($cmd) {
    $blender = $cmd.Source
}

if (-not $blender -and (Test-Path "C:\Program Files\Blender Foundation")) {
    $found = Get-ChildItem "C:\Program Files\Blender Foundation" `
        -Filter blender.exe -Recurse -ErrorAction SilentlyContinue |
        Sort-Object FullName -Descending |
        Select-Object -First 1

    if ($found) {
        $blender = $found.FullName
    }
}

if (-not $blender) {
    Write-Host "FAILED: Blender executable not found." -ForegroundColor Red
    exit 2
}

New-Item -ItemType Directory -Force -Path $checkpointDir | Out-Null
New-Item -ItemType Directory -Force -Path (Split-Path $log) | Out-Null
New-Item -ItemType Directory -Force -Path (Split-Path $manifest) | Out-Null

$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$checkpoint = Join-Path $checkpointDir "snow_before_control_lab_$timestamp.blend"
Copy-Item $working $checkpoint

if (Test-Path $resultFolder) {
    Remove-Item $resultFolder -Recurse -Force
}

if (Test-Path $manifest) {
    Remove-Item $manifest -Force
}

if (Test-Path $resultZip) {
    Remove-Item $resultZip -Force
}

Write-Host "Using Blender: $blender" -ForegroundColor Cyan
Write-Host "Checkpoint: $checkpoint" -ForegroundColor Cyan
Write-Host "Running read-only Snow control and pose lab..." -ForegroundColor Cyan
Write-Host "This may render several low-resolution review images." -ForegroundColor Yellow

& $blender --background $working --python $script 2>&1 |
    Tee-Object -FilePath $log

if ($LASTEXITCODE -ne 0) {
    Write-Host ""
    Write-Host "FAILED: Blender returned exit code $LASTEXITCODE." -ForegroundColor Red
    Write-Host "Log: $log"
    exit $LASTEXITCODE
}

if (-not (Test-Path $manifest)) {
    Write-Host "FAILED: Lab manifest was not created." -ForegroundColor Red
    exit 3
}

if (-not (Test-Path $resultFolder)) {
    Write-Host "FAILED: Lab image folder was not created." -ForegroundColor Red
    exit 4
}

Compress-Archive -Path "$resultFolder\*" -DestinationPath $resultZip -Force

Write-Host ""
Write-Host "SUCCESS" -ForegroundColor Green
Write-Host "The working .blend was not saved or overwritten."
Write-Host "Open galleries under:"
Write-Host "  previews\snow_lab\01_camera_views\index.html"
Write-Host "  previews\snow_lab\02_head_axes\index.html"
Write-Host "  previews\snow_lab\03_eye_target_axes\index.html"
Write-Host "  previews\snow_lab\04_blink_actions\index.html"
Write-Host "  previews\snow_lab\05_body_pose_library\index.html"
Write-Host ""
Write-Host "Upload this result ZIP:"
Write-Host "  handoff\snow_control_lab_results.zip"
