# Snow Control Lab Launcher Fix V1

Your full Snow package installation is correct:

- master textures: 33 files
- working textures: 33 files
- verification: PASS

The control lab stopped because the original PowerShell launcher used:

```powershell
$ErrorActionPreference = "Stop"
& $blender ... 2>&1 | Tee-Object ...
```

PowerShell converted Blender's stderr into a terminating
`NativeCommandError`, so the launcher stopped before it could capture the
complete Blender traceback.

## Install

Copy this file into the existing project root and replace the old file:

```text
run_snow_control_lab.ps1
```

## Run

```powershell
.\run_snow_control_lab.ps1
```

The new launcher uses `Start-Process` and separately captures:

```text
logs\snow_control_lab_stdout.log
logs\snow_control_lab_stderr.log
logs\snow_control_lab.log
```

If the Blender Python script has a genuine error, the launcher now prints the
last 60 lines instead of hiding the traceback.

If successful, upload:

```text
handoff\snow_control_lab_results.zip
```
