param(
    [switch]$Push,
    [string]$RepoRoot = ""
)

$ErrorActionPreference = "Stop"

if ([string]::IsNullOrWhiteSpace($RepoRoot)) {
    $RepoRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
}

$RepoRoot = (Resolve-Path $RepoRoot).Path
$ProjectRoot = Split-Path -Parent $RepoRoot

$MasterBlend = Join-Path $ProjectRoot "project4_rain_wave_working.blend"
$AgentBlend = Join-Path $RepoRoot "workspace\agent_working.blend"
$CheckpointDir = Join-Path $RepoRoot "workspace\checkpoints"
$ApplyScript = Join-Path $RepoRoot "blender_tools\apply_face_v1.py"
$WriteReport = Join-Path $RepoRoot "workspace\face_v1_write_report.json"

if (-not (Test-Path $MasterBlend)) { throw "Master blend missing: $MasterBlend" }
if (-not (Test-Path $AgentBlend)) { throw "Agent blend missing: $AgentBlend" }
if (-not (Test-Path $ApplyScript)) { throw "Face script missing: $ApplyScript" }

New-Item -ItemType Directory -Path $CheckpointDir -Force | Out-Null

$Blender = Get-ChildItem "C:\Program Files\Blender Foundation" -Filter blender.exe -Recurse -ErrorAction SilentlyContinue |
    Sort-Object FullName -Descending |
    Select-Object -First 1 -ExpandProperty FullName

if (-not $Blender) { throw "Blender executable not found." }

$Timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$Checkpoint = Join-Path $CheckpointDir "agent_working_before_face_v1_$Timestamp.blend"

$MasterHashBefore = (Get-FileHash $MasterBlend -Algorithm SHA256).Hash
$AgentHashBefore = (Get-FileHash $AgentBlend -Algorithm SHA256).Hash

Copy-Item $AgentBlend $Checkpoint -Force

Write-Host ""
Write-Host "=============================================="
Write-Host "RAIN FACE V1 - WRITE_SAFE"
Write-Host "=============================================="
Write-Host "Checkpoint: $Checkpoint"
Write-Host "Master will not be modified."
Write-Host ""

& $Blender `
    --background `
    $AgentBlend `
    --python $ApplyScript `
    -- `
    $WriteReport

$ExitCode = $LASTEXITCODE

if ($ExitCode -ne 0 -or -not (Test-Path $WriteReport)) {
    Copy-Item $Checkpoint $AgentBlend -Force
    throw "Face write failed. Agent blend restored from checkpoint."
}

$Report = Get-Content $WriteReport -Raw | ConvertFrom-Json

if (-not $Report.saved -or -not $Report.protected_controls_unchanged -or @($Report.errors).Count -gt 0) {
    Copy-Item $Checkpoint $AgentBlend -Force
    throw "Safety validation failed. Agent blend restored from checkpoint."
}

$MasterHashAfter = (Get-FileHash $MasterBlend -Algorithm SHA256).Hash

if ($MasterHashBefore -ne $MasterHashAfter) {
    Copy-Item $Checkpoint $AgentBlend -Force
    throw "MASTER BLEND HASH CHANGED. Agent copy restored; stop and investigate immediately."
}

Write-Host ""
Write-Host "Face write passed. Protected arm animation was unchanged."
Write-Host "Refreshing READ_ONLY state..."

& (Join-Path $RepoRoot "collect-rain-state.ps1")
if ($LASTEXITCODE -ne 0) {
    throw "READ_ONLY state collection failed after face write."
}

Write-Host ""
Write-Host "Rendering comparison previews..."

& (Join-Path $RepoRoot "collect-rain-previews.ps1")
if ($LASTEXITCODE -ne 0) {
    throw "Preview collection failed after face write."
}

# Copy write report into the handoff after state collector cleared/rebuilt handoff/latest.
Copy-Item `
    $WriteReport `
    (Join-Path $RepoRoot "handoff\latest\face_v1_write_report.json") `
    -Force

Write-Host ""
Write-Host "=============================================="
Write-Host "RAIN FACE V1 RESULT: PASS"
Write-Host "=============================================="
Write-Host "Checkpoint: $Checkpoint"
Write-Host "Protected arms unchanged: True"
Write-Host "Master unchanged: True"
Write-Host "Smile: frames 28-82"
Write-Host "Blink: frame 50"
Write-Host "Preview: handoff\latest\previews"
Write-Host "=============================================="

if ($Push) {
    Write-Host ""
    Write-Host "Publishing complete face-v1 handoff..."

    git -C $RepoRoot add handoff/latest

    $Staged = git -C $RepoRoot diff --cached --name-only

    if (-not [string]::IsNullOrWhiteSpace($Staged)) {
        $CommitTime = (Get-Date).ToString("s")
        git -C $RepoRoot commit -m "Add Rain face v1 handoff $CommitTime"
        if ($LASTEXITCODE -ne 0) { throw "git commit failed" }

        git -C $RepoRoot push
        if ($LASTEXITCODE -ne 0) { throw "git push failed" }

        Write-Host "Face-v1 handoff pushed successfully."
    }
}
