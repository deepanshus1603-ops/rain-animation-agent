# Rain Face v1 — WRITE_SAFE

The latest handoff shows:

- the existing wave is present in `RIG-rainAction.002`
- Blender 5.2 layered action contains 68 F-curves
- all 8 face controls currently have **no keyframes**
- the right and left arm animation is present and protected
- preview renders show a neutral face across the wave

This pack performs the first controlled face write on the **agent copy only**.

## Face animation added

Smile:

```text
1   neutral
20  neutral
28  55% smile
36  full subtle smile
75  hold smile
82  soften
96  neutral
```

Blink:

```text
48  open
50  closed
53  open
```

The smile uses conservative lip-corner X motion and more upward Z motion plus a tiny cheek raise.

## Safety

Before any modification:

- creates a checkpoint copy of `workspace\agent_working.blend`
- records the complete F-curve/keyframe signature of all protected arm controls

Before saving:

- confirms the protected arm signatures are byte-for-byte equivalent at the data level
- refuses to save if protected animation changed

After saving:

- confirms the MASTER `.blend` SHA256 is unchanged
- re-runs READ_ONLY scene collection
- re-renders the comparison preview frames

If the face write fails, the PowerShell orchestrator restores the agent `.blend` from the checkpoint.

## GPU laptop

Install:

```powershell
powershell -ExecutionPolicy Bypass -File .\install-face-v1.ps1
```

Then:

```powershell
cd "$HOME\Desktop\blender\project4\rain-animation-agent"
powershell -ExecutionPolicy Bypass -File .\apply-rain-face-v1.ps1
```

Do **not** use `-Push` on the first run.

If it reports:

```text
RAIN FACE V1 RESULT: PASS
```

then inspect/publish with:

```powershell
powershell -ExecutionPolicy Bypass -File .\apply-rain-face-v1.ps1 -Push
```

Note: because the first successful run already adds face keyframes, running the whole write command a second time will intentionally refuse to overwrite them. Therefore, after a first PASS, publish the existing handoff with Git manually or use the normal handoff workflow rather than reapplying. If you want to publish immediately, you may instead run the first command with `-Push`.
