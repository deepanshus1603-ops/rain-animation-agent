import bpy
import json
import os
import sys
import traceback
from bpy_extras.anim_utils import animdata_get_channelbag_for_assigned_slot

RIG_NAME = "RIG-rain"

FACE_CONTROLS = [
    "ACT-Lips_Corner.L",
    "ACT-Lips_Corner.R",
    "ACT-Cheek_Outer.L",
    "ACT-Cheek_Outer.R",
    "ACT-Eyelid_Upper.L",
    "ACT-Eyelid_Upper.R",
    "ACT-Eyelid_Lower.L",
    "ACT-Eyelid_Lower.R",
]

PROTECTED_CONTROLS = [
    "FK-Upperarm_Parent.R",
    "FK-Upperarm.R",
    "FK-Forearm.R",
    "FK-Hand.R",
    "FK-Upperarm_Parent.L",
    "FK-Upperarm.L",
    "FK-Forearm.L",
    "FK-Hand.L",
]

def get_args():
    report = os.path.abspath(bpy.path.abspath("//face_v1_report.json"))
    if "--" in sys.argv:
        args = sys.argv[sys.argv.index("--") + 1:]
        if args:
            report = os.path.abspath(args[0])
    return report

def get_rig():
    rig = bpy.data.objects.get(RIG_NAME)
    if rig is None:
        raise RuntimeError(f"Rig '{RIG_NAME}' not found.")
    return rig

def get_channelbag(rig):
    ad = rig.animation_data
    if ad is None or ad.action is None:
        raise RuntimeError("Rain rig has no active Action.")
    bag = animdata_get_channelbag_for_assigned_slot(ad)
    if bag is None:
        raise RuntimeError("Could not resolve the assigned Blender 5.2 Action channelbag.")
    return bag

def relevant_fcurves(rig, bone_names):
    bag = get_channelbag(rig)
    prefixes = tuple(f'pose.bones["{name}"]' for name in bone_names)
    curves = []
    for fc in bag.fcurves:
        if fc.data_path.startswith(prefixes):
            curves.append(fc)
    return curves

def curve_signature(rig, bone_names):
    sig = []
    for fc in relevant_fcurves(rig, bone_names):
        points = []
        for kp in fc.keyframe_points:
            points.append({
                "co": [round(float(kp.co.x), 6), round(float(kp.co.y), 8)],
                "interpolation": kp.interpolation,
            })
        sig.append({
            "data_path": fc.data_path,
            "array_index": int(fc.array_index),
            "points": points,
        })
    sig.sort(key=lambda x: (x["data_path"], x["array_index"]))
    return sig

def frames_for_controls(rig, bone_names):
    result = {name: [] for name in bone_names}
    for fc in relevant_fcurves(rig, bone_names):
        for name in bone_names:
            prefix = f'pose.bones["{name}"]'
            if fc.data_path.startswith(prefix):
                result[name].extend(float(kp.co.x) for kp in fc.keyframe_points)
    return {k: sorted(set(round(x, 3) for x in v)) for k, v in result.items()}

def set_location(pb, xyz, frame):
    pb.location.x = xyz[0]
    pb.location.y = xyz[1]
    pb.location.z = xyz[2]
    pb.keyframe_insert(data_path="location", frame=frame)

def set_component(pb, axis, value, frame):
    if axis == "x":
        pb.location.x = value
    elif axis == "y":
        pb.location.y = value
    elif axis == "z":
        pb.location.z = value
    else:
        raise ValueError(axis)
    pb.keyframe_insert(data_path="location", frame=frame)

def scale_tuple(values, factor):
    return tuple(v * factor for v in values)

def set_bezier_for_face_curves(rig):
    for fc in relevant_fcurves(rig, FACE_CONTROLS):
        for kp in fc.keyframe_points:
            kp.interpolation = "BEZIER"
            try:
                kp.handle_left_type = "AUTO_CLAMPED"
                kp.handle_right_type = "AUTO_CLAMPED"
            except Exception:
                pass

report_path = get_args()
os.makedirs(os.path.dirname(report_path), exist_ok=True)

report = {
    "mode": "WRITE_SAFE_FACE_V1",
    "blend_file": bpy.data.filepath,
    "rig": RIG_NAME,
    "saved": False,
    "protected_controls_unchanged": False,
    "face_controls_before": {},
    "face_controls_after": {},
    "protected_signature_before": None,
    "protected_signature_after": None,
    "errors": [],
}

try:
    rig = get_rig()

    # Verify all required controls before touching anything.
    for name in FACE_CONTROLS + PROTECTED_CONTROLS:
        if rig.pose.bones.get(name) is None:
            raise RuntimeError(f"Required pose control missing: {name}")

    # First facial write is only allowed when these controls have no existing keyframes.
    existing_face_frames = frames_for_controls(rig, FACE_CONTROLS)
    report["face_controls_before"] = existing_face_frames
    if any(existing_face_frames[name] for name in FACE_CONTROLS):
        raise RuntimeError(
            "Face controls already contain keyframes. Refusing first-pass face write to avoid overwriting existing animation."
        )

    protected_before = curve_signature(rig, PROTECTED_CONTROLS)
    report["protected_signature_before"] = protected_before

    lip_l = rig.pose.bones["ACT-Lips_Corner.L"]
    lip_r = rig.pose.bones["ACT-Lips_Corner.R"]
    cheek_l = rig.pose.bones["ACT-Cheek_Outer.L"]
    cheek_r = rig.pose.bones["ACT-Cheek_Outer.R"]

    upper_l = rig.pose.bones["ACT-Eyelid_Upper.L"]
    upper_r = rig.pose.bones["ACT-Eyelid_Upper.R"]
    lower_l = rig.pose.bones["ACT-Eyelid_Lower.L"]
    lower_r = rig.pose.bones["ACT-Eyelid_Lower.R"]

    neutral = (0.0, 0.0, 0.0)

    # Conservative friendly smile: mostly upward motion, very little sideways stretch.
    smile_l = (0.0060, 0.0030, 0.0180)
    smile_r = (-0.0055, 0.0030, 0.0185)
    cheek_l_smile = (0.0, 0.0030, 0.0)
    cheek_r_smile = (0.0, 0.0028, 0.0)

    # Smile timing.
    for frame, factor in [
        (1, 0.0),
        (20, 0.0),
        (28, 0.55),
        (36, 1.0),
        (75, 1.0),
        (82, 0.60),
        (96, 0.0),
    ]:
        set_location(lip_l, scale_tuple(smile_l, factor), frame)
        set_location(lip_r, scale_tuple(smile_r, factor), frame)
        set_location(cheek_l, scale_tuple(cheek_l_smile, factor), frame)
        set_location(cheek_r, scale_tuple(cheek_r_smile, factor), frame)

    # Natural single blink around frame 50.
    # Open -> closed in 2 frames -> open in 3 frames.
    for frame in (1, 48, 53, 96):
        set_location(upper_l, neutral, frame)
        set_location(upper_r, neutral, frame)
        set_location(lower_l, neutral, frame)
        set_location(lower_r, neutral, frame)

    set_location(upper_l, (0.0, -0.038, 0.0), 50)
    set_location(upper_r, (0.0, -0.038, 0.0), 50)
    set_location(lower_l, (0.0, 0.018, 0.0), 50)
    set_location(lower_r, (0.0, 0.018, 0.0), 50)

    set_bezier_for_face_curves(rig)

    protected_after = curve_signature(rig, PROTECTED_CONTROLS)
    report["protected_signature_after"] = protected_after
    report["protected_controls_unchanged"] = (protected_before == protected_after)

    if not report["protected_controls_unchanged"]:
        raise RuntimeError(
            "Protected arm animation changed during facial write. Refusing to save."
        )

    report["face_controls_after"] = frames_for_controls(rig, FACE_CONTROLS)

    # Save only after protected animation has been verified unchanged.
    bpy.ops.wm.save_as_mainfile(filepath=bpy.data.filepath)
    report["saved"] = True

except Exception as exc:
    report["errors"].append(f"{type(exc).__name__}: {exc}")
    report["errors"].append(traceback.format_exc())

with open(report_path, "w", encoding="utf-8") as f:
    json.dump(report, f, indent=2)

print()
print("============================================")
if report["saved"] and report["protected_controls_unchanged"] and not report["errors"]:
    print("RAIN_FACE_V1_WRITE_OK")
else:
    print("RAIN_FACE_V1_WRITE_FAILED")
print("============================================")
print("Saved:", report["saved"])
print("Protected arm animation unchanged:", report["protected_controls_unchanged"])
print("Report:", report_path)
print("Errors:", len(report["errors"]))
print("============================================")
print()

if report["errors"]:
    raise SystemExit(2)
