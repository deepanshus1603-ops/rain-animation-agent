param(
    [string]$RepoRoot = (Join-Path $env:USERPROFILE "Desktop\blender\project4\rain-animation-agent")
)

$ErrorActionPreference = "Stop"
$Seed = Split-Path -Parent $MyInvocation.MyCommand.Path

if (-not (Test-Path (Join-Path $RepoRoot ".git"))) {
    throw "Rain repository not found: $RepoRoot"
}

New-Item -ItemType Directory -Path (Join-Path $RepoRoot "blender_tools") -Force | Out-Null

Copy-Item `
    (Join-Path $Seed "blender_tools\apply_face_v1.py") `
    (Join-Path $RepoRoot "blender_tools\apply_face_v1.py") `
    -Force

Copy-Item `
    (Join-Path $Seed "apply-rain-face-v1.ps1") `
    (Join-Path $RepoRoot "apply-rain-face-v1.ps1") `
    -Force

Write-Host ""
Write-Host "Installed Rain WRITE_SAFE face-v1 tools."
Write-Host ""
Write-Host "Next:"
Write-Host "  cd $RepoRoot"
Write-Host "  powershell -ExecutionPolicy Bypass -File .\apply-rain-face-v1.ps1"
