param(
    [string]$RepoRoot = ""
)

$ErrorActionPreference = "Stop"

if ([string]::IsNullOrWhiteSpace($RepoRoot)) {
    $RepoRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
}

$RepoRoot = (Resolve-Path $RepoRoot).Path
$ProjectRoot = Split-Path -Parent $RepoRoot

$MasterBlend = Join-Path $ProjectRoot "project4_rain_wave_working.blend"
$AgentBlend = Join-Path $RepoRoot "workspace\agent_working.blend"
$CheckpointDir = Join-Path $RepoRoot "workspace\checkpoints"
$ApplyScript = Join-Path $RepoRoot "blender_tools\apply_face_v2_balanced.py"
$WriteReport = Join-Path $RepoRoot "workspace\face_v2_write_report.json"

if (-not (Test-Path $MasterBlend)) { throw "Master blend missing." }
if (-not (Test-Path $AgentBlend)) { throw "Agent blend missing." }
if (-not (Test-Path $ApplyScript)) { throw "Face V2 script missing." }

New-Item -ItemType Directory -Path $CheckpointDir -Force | Out-Null

$Blender = Get-ChildItem "C:\Program Files\Blender Foundation" -Filter blender.exe -Recurse -ErrorAction SilentlyContinue |
    Sort-Object FullName -Descending |
    Select-Object -First 1 -ExpandProperty FullName

if (-not $Blender) { throw "Blender executable not found." }

$Timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$Checkpoint = Join-Path $CheckpointDir "agent_working_before_face_v2_$Timestamp.blend"

$MasterHashBefore = (Get-FileHash $MasterBlend -Algorithm SHA256).Hash
Copy-Item $AgentBlend $Checkpoint -Force

Write-Host ""
Write-Host "=============================================="
Write-Host "RAIN FACE V2 - BALANCED SMILE"
Write-Host "=============================================="
Write-Host "Checkpoint: $Checkpoint"
Write-Host ""

& $Blender --background $AgentBlend --python $ApplyScript -- $WriteReport
$ExitCode = $LASTEXITCODE

if ($ExitCode -ne 0 -or -not (Test-Path $WriteReport)) {
    Copy-Item $Checkpoint $AgentBlend -Force
    throw "Face V2 write failed. Agent blend restored from checkpoint."
}

$Report = Get-Content $WriteReport -Raw | ConvertFrom-Json

if (
    -not $Report.saved -or
    -not $Report.protected_arms_unchanged -or
    -not $Report.blink_unchanged -or
    -not $Report.smile_keyframe_frames_unchanged -or
    @($Report.errors).Count -gt 0
) {
    Copy-Item $Checkpoint $AgentBlend -Force
    throw "Face V2 safety validation failed. Agent blend restored."
}

$MasterHashAfter = (Get-FileHash $MasterBlend -Algorithm SHA256).Hash
if ($MasterHashBefore -ne $MasterHashAfter) {
    Copy-Item $Checkpoint $AgentBlend -Force
    throw "MASTER blend hash changed. Agent blend restored. Stop immediately."
}

Write-Host "Refreshing scene state..."
& (Join-Path $RepoRoot "collect-rain-state.ps1")
if ($LASTEXITCODE -ne 0) { throw "Post-write state inspection failed." }

Write-Host "Rendering updated previews..."
& (Join-Path $RepoRoot "collect-rain-previews.ps1")
if ($LASTEXITCODE -ne 0) { throw "Post-write preview render failed." }

Copy-Item $WriteReport (Join-Path $RepoRoot "handoff\latest\face_v2_write_report.json") -Force

Write-Host ""
Write-Host "=============================================="
Write-Host "RAIN FACE V2 RESULT: PASS"
Write-Host "=============================================="
Write-Host "Smile preset: Smile B - balanced"
Write-Host "Protected arms unchanged: True"
Write-Host "Blink unchanged: True"
Write-Host "Master unchanged: True"
Write-Host "Checkpoint: $Checkpoint"
Write-Host "Preview: handoff\latest\previews"
Write-Host "=============================================="
