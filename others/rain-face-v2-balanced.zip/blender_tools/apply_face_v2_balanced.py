import bpy
import json
import os
import sys
import traceback
from bpy_extras.anim_utils import animdata_get_channelbag_for_assigned_slot

RIG_NAME = "RIG-rain"

SMILE_CONTROLS = [
    "ACT-Lips_Corner.L",
    "ACT-Lips_Corner.R",
    "ACT-Cheek_Outer.L",
    "ACT-Cheek_Outer.R",
]

BLINK_CONTROLS = [
    "ACT-Eyelid_Upper.L",
    "ACT-Eyelid_Upper.R",
    "ACT-Eyelid_Lower.L",
    "ACT-Eyelid_Lower.R",
]

PROTECTED_ARM_CONTROLS = [
    "FK-Upperarm_Parent.R",
    "FK-Upperarm.R",
    "FK-Forearm.R",
    "FK-Hand.R",
    "FK-Upperarm_Parent.L",
    "FK-Upperarm.L",
    "FK-Forearm.L",
    "FK-Hand.L",
]

EXPECTED_SMILE_FRAMES = [1.0, 20.0, 28.0, 36.0, 75.0, 82.0, 96.0]
EXPECTED_BLINK_FRAMES = [1.0, 48.0, 50.0, 53.0, 96.0]

def get_report_path():
    p = os.path.abspath(bpy.path.abspath("//face_v2_report.json"))
    if "--" in sys.argv:
        args = sys.argv[sys.argv.index("--") + 1:]
        if args:
            p = os.path.abspath(args[0])
    return p

def get_rig():
    rig = bpy.data.objects.get(RIG_NAME)
    if rig is None:
        raise RuntimeError(f"Rig '{RIG_NAME}' not found.")
    return rig

def get_channelbag(rig):
    ad = rig.animation_data
    if ad is None or ad.action is None:
        raise RuntimeError("Rain rig has no active action.")
    bag = animdata_get_channelbag_for_assigned_slot(ad)
    if bag is None:
        raise RuntimeError("Could not resolve Blender 5.2 action channelbag.")
    return bag

def relevant_fcurves(rig, bone_names):
    bag = get_channelbag(rig)
    prefixes = tuple(f'pose.bones["{n}"]' for n in bone_names)
    return [fc for fc in bag.fcurves if fc.data_path.startswith(prefixes)]

def curve_signature(rig, bone_names):
    sig = []
    for fc in relevant_fcurves(rig, bone_names):
        pts = []
        for kp in fc.keyframe_points:
            pts.append({
                "co": [round(float(kp.co.x), 6), round(float(kp.co.y), 8)],
                "interpolation": kp.interpolation,
            })
        sig.append({
            "data_path": fc.data_path,
            "array_index": int(fc.array_index),
            "points": pts,
        })
    sig.sort(key=lambda x: (x["data_path"], x["array_index"]))
    return sig

def frames_for_bone(rig, bone_name):
    frames = set()
    prefix = f'pose.bones["{bone_name}"]'
    for fc in relevant_fcurves(rig, [bone_name]):
        if fc.data_path.startswith(prefix):
            for kp in fc.keyframe_points:
                frames.add(round(float(kp.co.x), 3))
    return sorted(frames)

def set_location(pb, xyz, frame):
    pb.location.x = xyz[0]
    pb.location.y = xyz[1]
    pb.location.z = xyz[2]
    pb.keyframe_insert(data_path="location", frame=frame)

def scale_tuple(values, factor):
    return tuple(v * factor for v in values)

def smooth_smile_curves(rig):
    for fc in relevant_fcurves(rig, SMILE_CONTROLS):
        for kp in fc.keyframe_points:
            kp.interpolation = "BEZIER"
            try:
                kp.handle_left_type = "AUTO_CLAMPED"
                kp.handle_right_type = "AUTO_CLAMPED"
            except Exception:
                pass

report_path = get_report_path()
os.makedirs(os.path.dirname(report_path), exist_ok=True)

report = {
    "mode": "WRITE_SAFE_FACE_V2_BALANCED",
    "blend_file": bpy.data.filepath,
    "saved": False,
    "protected_arms_unchanged": False,
    "blink_unchanged": False,
    "smile_keyframe_frames_unchanged": False,
    "errors": [],
}

try:
    rig = get_rig()

    for name in SMILE_CONTROLS + BLINK_CONTROLS + PROTECTED_ARM_CONTROLS:
        if rig.pose.bones.get(name) is None:
            raise RuntimeError(f"Missing required pose control: {name}")

    # Verify we are modifying the expected Face V1 structure only.
    for name in SMILE_CONTROLS:
        frames = frames_for_bone(rig, name)
        if frames != EXPECTED_SMILE_FRAMES:
            raise RuntimeError(
                f"{name} has unexpected keyframe frames {frames}; expected {EXPECTED_SMILE_FRAMES}. Refusing overwrite."
            )

    for name in BLINK_CONTROLS:
        frames = frames_for_bone(rig, name)
        if frames != EXPECTED_BLINK_FRAMES:
            raise RuntimeError(
                f"{name} has unexpected blink frames {frames}; expected {EXPECTED_BLINK_FRAMES}. Refusing overwrite."
            )

    arms_before = curve_signature(rig, PROTECTED_ARM_CONTROLS)
    blink_before = curve_signature(rig, BLINK_CONTROLS)
    smile_frames_before = {n: frames_for_bone(rig, n) for n in SMILE_CONTROLS}

    lip_l = rig.pose.bones["ACT-Lips_Corner.L"]
    lip_r = rig.pose.bones["ACT-Lips_Corner.R"]
    cheek_l = rig.pose.bones["ACT-Cheek_Outer.L"]
    cheek_r = rig.pose.bones["ACT-Cheek_Outer.R"]

    # Chosen from the read-only Smile Lab: Smile B (balanced).
    smile_l = (0.0040, 0.0020, 0.0135)
    smile_r = (-0.0038, 0.0020, 0.0140)
    cheek_l_smile = (0.0, 0.0014, 0.0)
    cheek_r_smile = (0.0, 0.0013, 0.0)

    # Preserve Face V1 timing while replacing only the smile strength/shape.
    timeline = [
        (1, 0.0),
        (20, 0.0),
        (28, 0.55),
        (36, 1.0),
        (75, 1.0),
        (82, 0.60),
        (96, 0.0),
    ]

    for frame, factor in timeline:
        set_location(lip_l, scale_tuple(smile_l, factor), frame)
        set_location(lip_r, scale_tuple(smile_r, factor), frame)
        set_location(cheek_l, scale_tuple(cheek_l_smile, factor), frame)
        set_location(cheek_r, scale_tuple(cheek_r_smile, factor), frame)

    smooth_smile_curves(rig)

    arms_after = curve_signature(rig, PROTECTED_ARM_CONTROLS)
    blink_after = curve_signature(rig, BLINK_CONTROLS)
    smile_frames_after = {n: frames_for_bone(rig, n) for n in SMILE_CONTROLS}

    report["protected_arms_unchanged"] = (arms_before == arms_after)
    report["blink_unchanged"] = (blink_before == blink_after)
    report["smile_keyframe_frames_unchanged"] = (smile_frames_before == smile_frames_after)

    if not report["protected_arms_unchanged"]:
        raise RuntimeError("Protected arm animation changed. Refusing save.")

    if not report["blink_unchanged"]:
        raise RuntimeError("Blink animation changed. Refusing save.")

    if not report["smile_keyframe_frames_unchanged"]:
        raise RuntimeError("Smile keyframe frame set changed unexpectedly. Refusing save.")

    bpy.ops.wm.save_as_mainfile(filepath=bpy.data.filepath)
    report["saved"] = True

except Exception as exc:
    report["errors"].append(f"{type(exc).__name__}: {exc}")
    report["errors"].append(traceback.format_exc())

with open(report_path, "w", encoding="utf-8") as f:
    json.dump(report, f, indent=2)

print("")
print("============================================")
if report["saved"] and not report["errors"]:
    print("RAIN_FACE_V2_BALANCED_OK")
else:
    print("RAIN_FACE_V2_BALANCED_FAILED")
print("============================================")
print("Saved:", report["saved"])
print("Protected arms unchanged:", report["protected_arms_unchanged"])
print("Blink unchanged:", report["blink_unchanged"])
print("Smile keyframe frames unchanged:", report["smile_keyframe_frames_unchanged"])
print("Report:", report_path)
print("Errors:", len(report["errors"]))
print("============================================")
print("")

if report["errors"]:
    raise SystemExit(2)
