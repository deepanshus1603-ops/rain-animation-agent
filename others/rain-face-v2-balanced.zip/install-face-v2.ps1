param(
    [string]$RepoRoot = (Join-Path $env:USERPROFILE "Desktop\blender\project4\rain-animation-agent")
)

$ErrorActionPreference = "Stop"
$Seed = Split-Path -Parent $MyInvocation.MyCommand.Path

if (-not (Test-Path (Join-Path $RepoRoot ".git"))) {
    throw "Rain repository not found: $RepoRoot"
}

Copy-Item `
    (Join-Path $Seed "blender_tools\apply_face_v2_balanced.py") `
    (Join-Path $RepoRoot "blender_tools\apply_face_v2_balanced.py") `
    -Force

Copy-Item `
    (Join-Path $Seed "apply-rain-face-v2.ps1") `
    (Join-Path $RepoRoot "apply-rain-face-v2.ps1") `
    -Force

Write-Host ""
Write-Host "Installed Rain Face V2 balanced-smile tools."
