# Rain Face V2 — Balanced Smile

The read-only smile lab rendered five facial variants.

The balanced candidate is the best base for the current friendly wave:

```text
Smile B
lip L:   x 0.0040, y 0.0020, z 0.0135
lip R:   x -0.0038, y 0.0020, z 0.0140
cheek L: y 0.0014
cheek R: y 0.0013
```

It is visibly softer than Face V1, avoids excessive horizontal stretching, and retains a clear friendly expression.

This pack updates **only the four smile controls**. It preserves:

- all arm F-curves/keyframes
- the existing blink controls and blink timing
- the existing smile keyframe frame positions
- the master `.blend`

Before modifying the agent copy it creates another checkpoint.

## GPU laptop

Install:

```powershell
powershell -ExecutionPolicy Bypass -File .\install-face-v2.ps1
```

Then:

```powershell
cd "$HOME\Desktop\blender\project4\rain-animation-agent"
powershell -ExecutionPolicy Bypass -File .\apply-rain-face-v2.ps1
```

Expected:

```text
RAIN FACE V2 RESULT: PASS
Protected arms unchanged: True
Blink unchanged: True
Master unchanged: True
```

Do not run the V2 apply command twice. After PASS, publish `handoff/latest` using Git and regenerate the normal ChatGPT handoff ZIP.
