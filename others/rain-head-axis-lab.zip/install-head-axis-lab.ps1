param(
    [string]$RepoRoot = (Join-Path $env:USERPROFILE "Desktop\blender\project4\rain-animation-agent")
)

$ErrorActionPreference = "Stop"
$Seed = Split-Path -Parent $MyInvocation.MyCommand.Path

if (-not (Test-Path (Join-Path $RepoRoot ".git"))) {
    throw "Rain repository not found: $RepoRoot"
}

Copy-Item `
    (Join-Path $Seed "blender_tools\render_head_axis_lab.py") `
    (Join-Path $RepoRoot "blender_tools\render_head_axis_lab.py") `
    -Force

Copy-Item `
    (Join-Path $Seed "collect-head-axis-lab.ps1") `
    (Join-Path $RepoRoot "collect-head-axis-lab.ps1") `
    -Force

Write-Host ""
Write-Host "Installed READ_ONLY FK-Head axis lab."
