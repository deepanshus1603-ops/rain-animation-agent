param(
    [switch]$Push,
    [string]$RepoRoot = ""
)

$ErrorActionPreference = "Stop"

if ([string]::IsNullOrWhiteSpace($RepoRoot)) {
    $RepoRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
}

$RepoRoot = (Resolve-Path $RepoRoot).Path
$ProjectRoot = Split-Path -Parent $RepoRoot

$MasterBlend = Join-Path $ProjectRoot "project4_rain_wave_working.blend"
$AgentBlend = Join-Path $RepoRoot "workspace\agent_working.blend"
$Script = Join-Path $RepoRoot "blender_tools\render_head_axis_lab.py"

$Latest = Join-Path $RepoRoot "handoff\latest"
$Output = Join-Path $Latest "head_axis_lab"
$Log = Join-Path $Latest "head_axis_lab_log.txt"
$Report = Join-Path $Latest "head_axis_lab_report.md"

if (-not (Test-Path $MasterBlend)) { throw "Missing master blend." }
if (-not (Test-Path $AgentBlend)) { throw "Missing agent blend." }
if (-not (Test-Path $Script)) { throw "Missing head axis lab script." }

New-Item -ItemType Directory -Path $Output -Force | Out-Null
Get-ChildItem $Output -Force -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force

$Blender = Get-ChildItem "C:\Program Files\Blender Foundation" -Filter blender.exe -Recurse -ErrorAction SilentlyContinue |
    Sort-Object FullName -Descending |
    Select-Object -First 1 -ExpandProperty FullName

if (-not $Blender) { throw "Blender executable not found." }

$MasterBefore = (Get-FileHash $MasterBlend -Algorithm SHA256).Hash
$AgentBefore = (Get-FileHash $AgentBlend -Algorithm SHA256).Hash

$PreviousErrorActionPreference = $ErrorActionPreference
$ErrorActionPreference = "Continue"
try {
    & $Blender --background $AgentBlend --python $Script -- $Output 2>&1 |
        Tee-Object -FilePath $Log
    $ExitCode = $LASTEXITCODE
}
finally {
    $ErrorActionPreference = $PreviousErrorActionPreference
}

$MasterAfter = (Get-FileHash $MasterBlend -Algorithm SHA256).Hash
$AgentAfter = (Get-FileHash $AgentBlend -Algorithm SHA256).Hash

$MasterUnchanged = ($MasterBefore -eq $MasterAfter)
$AgentUnchanged = ($AgentBefore -eq $AgentAfter)
$Images = @(Get-ChildItem $Output -Filter "*.jpg" -ErrorAction SilentlyContinue)
$Pass = ($ExitCode -eq 0 -and $Images.Count -eq 7 -and $MasterUnchanged -and $AgentUnchanged)

@"
# Rain Head Axis Lab Report

- Mode: READ_ONLY_HEAD_AXIS_LAB
- Result: $(if ($Pass) {"PASS"} else {"FAIL"})
- Blender exit code: $ExitCode
- Control: FK-Head
- Base frame: 60
- Images rendered: $($Images.Count)/7
- Master blend unchanged: $MasterUnchanged
- Agent blend unchanged: $AgentUnchanged
- Output: handoff/latest/head_axis_lab
"@ | Set-Content $Report -Encoding UTF8

Write-Host ""
Write-Host "=============================================="
Write-Host "RAIN HEAD AXIS LAB RESULT: $(if ($Pass) {'PASS'} else {'FAIL'})"
Write-Host "=============================================="
Write-Host "Control: FK-Head"
Write-Host "Images: $($Images.Count)/7"
Write-Host "Master unchanged: $MasterUnchanged"
Write-Host "Agent unchanged: $AgentUnchanged"
Write-Host "Output: $Output"
Write-Host "=============================================="

if (-not $Pass) {
    throw "Head axis lab failed. Check $Log"
}

if ($Push) {
    git -C $RepoRoot add `
        handoff/latest/head_axis_lab `
        handoff/latest/head_axis_lab_log.txt `
        handoff/latest/head_axis_lab_report.md

    $Staged = git -C $RepoRoot diff --cached --name-only

    if ($Staged) {
        $Timestamp = (Get-Date).ToString("s")
        git -C $RepoRoot commit -m "Add Rain head axis lab $Timestamp"
        if ($LASTEXITCODE -ne 0) { throw "git commit failed" }

        git -C $RepoRoot pull --rebase origin main
        if ($LASTEXITCODE -ne 0) { throw "git rebase failed" }

        git -C $RepoRoot push origin main
        if ($LASTEXITCODE -ne 0) { throw "git push failed" }

        Write-Host "Head axis lab pushed successfully."
    }
}
