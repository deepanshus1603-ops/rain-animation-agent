# Rain Head Axis Lab

The real CloudRig scan shows the best high-level head control is:

```text
FK-Head
Collection: Main FK Controls
Rotation mode: XYZ
Rotation locks: none
Constraints: none
Existing keyframes: none
```

This makes it the safest control to test before adding head acting.

`MSTR-Head_Lower` and `MSTR-Head_Upper` are face-subsystem controls, not the first choice for whole-head acting.

`FK-Neck` is also animator-facing and clean, but we should identify the head tilt axis on `FK-Head` first.

## What this lab does

READ_ONLY at frame 60:

```text
neutral
X +5 degrees
X -5 degrees
Y +5 degrees
Y -5 degrees
Z +5 degrees
Z -5 degrees
```

Each pose is applied only in memory, rendered, then discarded. The `.blend` is never saved.

## GPU laptop

Install:

```powershell
powershell -ExecutionPolicy Bypass -File .\install-head-axis-lab.ps1
```

Run:

```powershell
cd "$HOME\Desktop\blender\project4\rain-animation-agent"
powershell -ExecutionPolicy Bypass -File .\collect-head-axis-lab.ps1
```

Expected:

```text
RAIN HEAD AXIS LAB RESULT: PASS
Images: 7/7
Master unchanged: True
Agent unchanged: True
```

If PASS:

```powershell
powershell -ExecutionPolicy Bypass -File .\collect-head-axis-lab.ps1 -Push
```

Then regenerate the standard ChatGPT handoff ZIP on the work laptop and upload it.

ChatGPT will compare the seven renders and identify which axis/direction produces the natural side tilt.
