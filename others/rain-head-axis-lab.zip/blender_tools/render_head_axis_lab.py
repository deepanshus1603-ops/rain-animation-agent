import bpy
import json
import math
import os
import sys
import warnings
from mathutils import Vector

warnings.filterwarnings("ignore", category=DeprecationWarning)

RIG_NAME = "RIG-rain"
HEAD_CONTROL = "FK-Head"
BASE_FRAME = 60

# Test small head rotations only. Nothing is saved.
CANDIDATES = [
    ("neutral", 0.0, 0.0, 0.0),
    ("head_X_pos_5deg", math.radians(5.0), 0.0, 0.0),
    ("head_X_neg_5deg", math.radians(-5.0), 0.0, 0.0),
    ("head_Y_pos_5deg", 0.0, math.radians(5.0), 0.0),
    ("head_Y_neg_5deg", 0.0, math.radians(-5.0), 0.0),
    ("head_Z_pos_5deg", 0.0, 0.0, math.radians(5.0)),
    ("head_Z_neg_5deg", 0.0, 0.0, math.radians(-5.0)),
]

def parse_args():
    out_dir = os.path.abspath(bpy.path.abspath("//head_axis_lab"))
    if "--" in sys.argv:
        args = sys.argv[sys.argv.index("--") + 1:]
        if args:
            out_dir = os.path.abspath(args[0])
    return out_dir

def look_at(obj, target):
    obj.rotation_euler = (Vector(target) - obj.location).to_track_quat("-Z", "Y").to_euler()

def object_bounds(obj):
    try:
        return [obj.matrix_world @ Vector(c) for c in obj.bound_box]
    except Exception:
        return []

def choose_upper_subjects():
    exact = bpy.data.objects.get("GEO-rain-head")
    objs = []
    if exact and exact.type == "MESH":
        objs.append(exact)

    # Include head/face/hair and upper-body Rain meshes for composition.
    for o in bpy.context.scene.objects:
        n = o.name.lower()
        if o.type != "MESH" or "rain" not in n:
            continue
        if any(k in n for k in (
            "head", "face", "hair", "eye", "brow", "lash", "teeth", "mouth",
            "body", "shirt", "top", "torso", "upper"
        )):
            if o not in objs:
                objs.append(o)

    if not objs:
        objs = [o for o in bpy.context.scene.objects if o.type == "MESH" and "rain" in o.name.lower()]
    if not objs:
        objs = [o for o in bpy.context.scene.objects if o.type == "MESH"]
    return objs

def bounds(objects):
    pts = []
    for o in objects:
        pts.extend(object_bounds(o))
    if not pts:
        return Vector((0,0,1.5)), Vector((0.7,0.5,1.0))
    mn = Vector((min(p.x for p in pts), min(p.y for p in pts), min(p.z for p in pts)))
    mx = Vector((max(p.x for p in pts), max(p.y for p in pts), max(p.z for p in pts)))
    return (mn + mx) * 0.5, (mx - mn)

def make_camera(scene, center, size):
    # Bias target upward for head-and-shoulders framing.
    target = Vector((center.x, center.y, center.z + max(size.z * 0.18, 0.12)))
    height = max(float(size.z) * 0.65, 0.8)
    width = max(float(size.x), 0.5)
    distance = max(height * 2.1, width * 1.9, 2.0)

    data = bpy.data.cameras.new("RAIN_HEAD_AXIS_CAMERA_DATA")
    cam = bpy.data.objects.new("RAIN_HEAD_AXIS_CAMERA", data)
    scene.collection.objects.link(cam)
    cam.location = Vector((target.x, target.y - distance, target.z))
    data.lens = 70
    look_at(cam, target)
    scene.camera = cam
    return cam, target, distance

def make_lights(scene, center, size):
    h = max(float(size.z), 1.0)
    w = max(float(size.x), 0.6)

    lights = []
    def area(name, loc, energy, sz):
        data = bpy.data.lights.new(name+"_DATA", "AREA")
        data.energy = energy
        data.size = sz
        obj = bpy.data.objects.new(name, data)
        scene.collection.objects.link(obj)
        obj.location = Vector(loc)
        look_at(obj, center)
        lights.append(obj)

    area("RAIN_HEAD_KEY", (center.x-w*1.5, center.y-h*1.7, center.z+h*1.0), 700, h*0.9)
    area("RAIN_HEAD_FILL", (center.x+w*1.4, center.y-h*1.3, center.z+h*0.6), 350, h*1.0)
    area("RAIN_HEAD_RIM", (center.x, center.y+h*1.3, center.z+h*0.9), 500, h*0.7)
    return lights

def make_override_material():
    mat = bpy.data.materials.new("RAIN_HEAD_AXIS_GRAY")
    mat.use_nodes = True
    bsdf = mat.node_tree.nodes.get("Principled BSDF")
    if bsdf:
        bsdf.inputs["Base Color"].default_value = (0.42, 0.42, 0.42, 1.0)
        bsdf.inputs["Roughness"].default_value = 0.58
    return mat

out_dir = parse_args()
os.makedirs(out_dir, exist_ok=True)

scene = bpy.context.scene
rig = bpy.data.objects.get(RIG_NAME)
if rig is None:
    raise RuntimeError(f"{RIG_NAME} not found")

head = rig.pose.bones.get(HEAD_CONTROL)
if head is None:
    raise RuntimeError(f"{HEAD_CONTROL} not found")

if head.rotation_mode != "XYZ":
    raise RuntimeError(f"{HEAD_CONTROL} rotation mode is {head.rotation_mode}, expected XYZ")

if any(head.lock_rotation):
    raise RuntimeError(f"{HEAD_CONTROL} has locked rotation axis: {list(head.lock_rotation)}")

# Record starting transform after evaluating animation at frame 60.
scene.frame_set(BASE_FRAME)
bpy.context.view_layer.update()
base_rot = head.rotation_euler.copy()
base_loc = head.location.copy()
base_scale = head.scale.copy()

original = {
    "camera": scene.camera,
    "engine": scene.render.engine,
    "x": scene.render.resolution_x,
    "y": scene.render.resolution_y,
    "pct": scene.render.resolution_percentage,
    "format": scene.render.image_settings.file_format,
    "quality": scene.render.image_settings.quality,
    "filepath": scene.render.filepath,
    "frame": scene.frame_current,
    "override": scene.view_layers[0].material_override,
}

center, size = bounds(choose_upper_subjects())
cam, target, distance = make_camera(scene, center, size)
lights = make_lights(scene, center, size)
gray = make_override_material()
scene.view_layers[0].material_override = gray

manifest = {
    "mode": "READ_ONLY_HEAD_AXIS_LAB",
    "base_frame": BASE_FRAME,
    "control": HEAD_CONTROL,
    "rotation_mode": head.rotation_mode,
    "base_rotation_euler": [float(v) for v in base_rot],
    "candidates": [],
    "camera_target": [float(v) for v in target],
    "camera_distance": float(distance),
}

try:
    try:
        scene.render.engine = "BLENDER_EEVEE_NEXT"
    except Exception:
        pass

    scene.render.resolution_x = 720
    scene.render.resolution_y = 720
    scene.render.resolution_percentage = 100
    scene.render.image_settings.file_format = "JPEG"
    scene.render.image_settings.quality = 94

    for name, dx, dy, dz in CANDIDATES:
        # Apply temporary offset relative to evaluated base pose.
        head.location = base_loc
        head.scale = base_scale
        head.rotation_euler = (
            base_rot.x + dx,
            base_rot.y + dy,
            base_rot.z + dz,
        )
        bpy.context.view_layer.update()

        filename = name + ".jpg"
        filepath = os.path.join(out_dir, filename)
        scene.render.filepath = filepath
        bpy.ops.render.render(write_still=True)

        manifest["candidates"].append({
            "name": name,
            "delta_degrees": [
                round(math.degrees(dx), 3),
                round(math.degrees(dy), 3),
                round(math.degrees(dz), 3),
            ],
            "file": filename,
        })
        print("RAIN_HEAD_AXIS_OK", name, filepath)

finally:
    # Restore in-memory pose and render state; file is never saved.
    head.location = base_loc
    head.rotation_euler = base_rot
    head.scale = base_scale
    scene.camera = original["camera"]
    scene.render.engine = original["engine"]
    scene.render.resolution_x = original["x"]
    scene.render.resolution_y = original["y"]
    scene.render.resolution_percentage = original["pct"]
    scene.render.image_settings.file_format = original["format"]
    scene.render.image_settings.quality = original["quality"]
    scene.render.filepath = original["filepath"]
    scene.frame_set(original["frame"])
    scene.view_layers[0].material_override = original["override"]

with open(os.path.join(out_dir, "head_axis_manifest.json"), "w", encoding="utf-8") as f:
    json.dump(manifest, f, indent=2)

print("")
print("============================================")
print("RAIN_HEAD_AXIS_LAB_COMPLETE")
print("============================================")
print("READ ONLY: YES")
print("Control:", HEAD_CONTROL)
print("Frame:", BASE_FRAME)
print("Images:", len(CANDIDATES))
print("Output:", out_dir)
print("============================================")
