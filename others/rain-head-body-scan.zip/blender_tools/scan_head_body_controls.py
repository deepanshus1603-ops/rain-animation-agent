import bpy
import json
import os
import sys
from bpy_extras.anim_utils import animdata_get_channelbag_for_assigned_slot

RIG_NAME = "RIG-rain"

HELPER_PREFIXES = (
    "DEF-", "MCH-", "TAN-", "N-", "P-BB-", "BB-", "WGT-"
)

KEYWORDS = (
    "head", "neck", "chest", "torso", "spine", "hips", "hip",
    "pelvis", "root", "cog", "body", "shoulder", "clavicle"
)

def get_output():
    out = os.path.abspath(bpy.path.abspath("//head_body_scan.json"))
    if "--" in sys.argv:
        args = sys.argv[sys.argv.index("--") + 1:]
        if args:
            out = os.path.abspath(args[0])
    return out

def get_channelbag(rig):
    ad = getattr(rig, "animation_data", None)
    if not ad or not getattr(ad, "action", None):
        return None
    try:
        return animdata_get_channelbag_for_assigned_slot(ad)
    except Exception:
        return None

def get_fcurves(rig):
    bag = get_channelbag(rig)
    if bag:
        try:
            return list(bag.fcurves)
        except Exception:
            pass
    return []

def frames_for_bone(fcurves, bone_name):
    prefix = f'pose.bones["{bone_name}"]'
    frames = set()
    for fc in fcurves:
        try:
            if fc.data_path.startswith(prefix):
                for kp in fc.keyframe_points:
                    frames.add(round(float(kp.co.x), 3))
        except Exception:
            pass
    return sorted(frames)

def collection_names(pb):
    names = []
    try:
        for c in pb.bone.collections:
            names.append(c.name)
    except Exception:
        pass
    return sorted(set(names))

def constraint_summary(pb):
    rows = []
    for c in pb.constraints:
        row = {
            "name": c.name,
            "type": c.type,
            "mute": bool(c.mute),
        }
        try:
            row["influence"] = round(float(c.influence), 6)
        except Exception:
            pass
        rows.append(row)
    return rows

def score_candidate(pb):
    name = pb.name
    lower = name.lower()

    if name.startswith(HELPER_PREFIXES):
        return -999

    score = 0

    for kw in KEYWORDS:
        if kw in lower:
            score += 6

    # Prefer animator-facing naming conventions.
    if name.startswith(("MSTR-", "ACT-", "CTRL-", "FK-")):
        score += 8

    # Exact/simple head or neck controls deserve extra weight.
    if lower in ("head", "neck", "head_ctrl", "neck_ctrl", "mstr-head", "mstr-neck"):
        score += 15

    if getattr(pb, "custom_shape", None):
        score += 6

    cols = [x.lower() for x in collection_names(pb)]
    for col in cols:
        if any(k in col for k in ("main", "body", "torso", "head", "neck", "controls")):
            score += 3

    # Root/spine controls can be useful but rank below explicit head/neck.
    if "head" in lower:
        score += 12
    if "neck" in lower:
        score += 10

    return score

def vec(values):
    return [round(float(v), 6) for v in values]

out = get_output()
os.makedirs(os.path.dirname(out), exist_ok=True)

rig = bpy.data.objects.get(RIG_NAME)
if rig is None:
    raise RuntimeError(f"Rig '{RIG_NAME}' not found.")

fcurves = get_fcurves(rig)

candidates = []
for pb in rig.pose.bones:
    score = score_candidate(pb)
    if score <= 0:
        continue

    item = {
        "name": pb.name,
        "score": score,
        "parent": pb.parent.name if pb.parent else None,
        "children": [c.name for c in pb.children],
        "collections": collection_names(pb),
        "custom_shape": pb.custom_shape.name if getattr(pb, "custom_shape", None) else None,
        "rotation_mode": pb.rotation_mode,
        "lock_location": list(pb.lock_location),
        "lock_rotation": list(pb.lock_rotation),
        "lock_scale": list(pb.lock_scale),
        "location": vec(pb.location),
        "rotation_euler": vec(pb.rotation_euler),
        "rotation_quaternion": vec(pb.rotation_quaternion),
        "scale": vec(pb.scale),
        "constraints": constraint_summary(pb),
        "keyframes": frames_for_bone(fcurves, pb.name),
    }
    candidates.append(item)

candidates.sort(key=lambda x: (-x["score"], x["name"].lower()))

report = {
    "mode": "READ_ONLY_HEAD_BODY_SCAN",
    "blend_file": bpy.data.filepath,
    "rig": RIG_NAME,
    "pose_bone_count": len(rig.pose.bones),
    "candidate_count": len(candidates),
    "top_candidates": candidates[:40],
    "all_candidates": candidates,
}

with open(out, "w", encoding="utf-8") as f:
    json.dump(report, f, indent=2)

txt = os.path.splitext(out)[0] + ".txt"
with open(txt, "w", encoding="utf-8") as f:
    f.write("RAIN HEAD/BODY CONTROL CANDIDATES\n")
    f.write("=" * 72 + "\n\n")
    for i, c in enumerate(candidates[:40], start=1):
        f.write(f"{i:02d}. {c['name']}  score={c['score']}\n")
        f.write(f"    parent: {c['parent']}\n")
        f.write(f"    collections: {', '.join(c['collections']) or '-'}\n")
        f.write(f"    custom_shape: {c['custom_shape']}\n")
        f.write(f"    rotation_mode: {c['rotation_mode']}\n")
        f.write(f"    lock_rotation: {c['lock_rotation']}\n")
        f.write(f"    keyframes: {c['keyframes']}\n")
        if c["constraints"]:
            f.write("    constraints:\n")
            for row in c["constraints"]:
                f.write(
                    f"      - {row['name']} ({row['type']}), "
                    f"mute={row['mute']}, influence={row.get('influence')}\n"
                )
        f.write("\n")

print("")
print("============================================")
print("RAIN_HEAD_BODY_SCAN_OK")
print("============================================")
print("READ ONLY: YES")
print("Rig:", RIG_NAME)
print("Pose bones:", len(rig.pose.bones))
print("Candidates:", len(candidates))
print("Top 10:")
for c in candidates[:10]:
    print(
        f"  {c['name']} | score={c['score']} | "
        f"collections={','.join(c['collections']) or '-'} | "
        f"keys={c['keyframes']}"
    )
print("JSON:", out)
print("TXT:", txt)
print("============================================")
