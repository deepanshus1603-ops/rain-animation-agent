param(
    [string]$RepoRoot = (Join-Path $env:USERPROFILE "Desktop\blender\project4\rain-animation-agent")
)

$ErrorActionPreference = "Stop"
$Seed = Split-Path -Parent $MyInvocation.MyCommand.Path

if (-not (Test-Path (Join-Path $RepoRoot ".git"))) {
    throw "Rain repository not found: $RepoRoot"
}

Copy-Item `
    (Join-Path $Seed "blender_tools\scan_head_body_controls.py") `
    (Join-Path $RepoRoot "blender_tools\scan_head_body_controls.py") `
    -Force

Copy-Item `
    (Join-Path $Seed "collect-head-body-scan.ps1") `
    (Join-Path $RepoRoot "collect-head-body-scan.ps1") `
    -Force

Write-Host ""
Write-Host "Installed READ_ONLY Rain head/body control scanner."
