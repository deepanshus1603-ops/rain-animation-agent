# Rain Head / Body Control Scan

Face V2 has passed:

- balanced smile is saved
- blink is unchanged
- protected arms are unchanged
- master `.blend` is unchanged
- action now contains 92 F-curves

The next step is **not** to guess a head axis or control.

This pack performs a READ_ONLY scan of the CloudRig and finds likely animator-facing controls for:

- head
- neck
- chest
- torso
- spine
- hips / pelvis
- root / COG
- clavicle / shoulders

It excludes helper-style controls such as `DEF-`, `MCH-`, `TAN-`, `N-`, `P-BB-`, `BB-`, and `WGT-`.

For each candidate it records:

- exact control name
- parent / children
- bone collections
- custom shape
- rotation mode
- transform locks
- constraints
- existing keyframe frames

No pose or animation is modified and no `.blend` file is saved.

## GPU laptop

Install:

```powershell
powershell -ExecutionPolicy Bypass -File .\install-head-body-scan.ps1
```

Run:

```powershell
cd "$HOME\Desktop\blender\project4\rain-animation-agent"
powershell -ExecutionPolicy Bypass -File .\collect-head-body-scan.ps1
```

Expected:

```text
RAIN HEAD/BODY SCAN RESULT: PASS
Master unchanged: True
Agent unchanged: True
```

If PASS:

```powershell
powershell -ExecutionPolicy Bypass -File .\collect-head-body-scan.ps1 -Push
```

Then regenerate the usual work-laptop `RAIN_CHATGPT_HANDOFF.zip` and upload it.

ChatGPT can then choose the exact high-level head/neck control and only after that build a tiny READ_ONLY head-tilt lab.
