param(
    [switch]$Push,
    [string]$RepoRoot = ""
)

$ErrorActionPreference = "Stop"

if ([string]::IsNullOrWhiteSpace($RepoRoot)) {
    $RepoRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
}

$RepoRoot = (Resolve-Path $RepoRoot).Path
$ProjectRoot = Split-Path -Parent $RepoRoot

$MasterBlend = Join-Path $ProjectRoot "project4_rain_wave_working.blend"
$AgentBlend = Join-Path $RepoRoot "workspace\agent_working.blend"
$Script = Join-Path $RepoRoot "blender_tools\scan_head_body_controls.py"

$Latest = Join-Path $RepoRoot "handoff\latest"
$JsonOut = Join-Path $Latest "head_body_scan.json"
$TxtOut = Join-Path $Latest "head_body_scan.txt"
$Log = Join-Path $Latest "head_body_scan_log.txt"
$Report = Join-Path $Latest "head_body_scan_report.md"

if (-not (Test-Path $MasterBlend)) { throw "Missing master blend." }
if (-not (Test-Path $AgentBlend)) { throw "Missing agent blend." }
if (-not (Test-Path $Script)) { throw "Missing scan script." }

New-Item -ItemType Directory -Path $Latest -Force | Out-Null

$Blender = Get-ChildItem "C:\Program Files\Blender Foundation" -Filter blender.exe -Recurse -ErrorAction SilentlyContinue |
    Sort-Object FullName -Descending |
    Select-Object -First 1 -ExpandProperty FullName

if (-not $Blender) { throw "Blender executable not found." }

$MasterBefore = (Get-FileHash $MasterBlend -Algorithm SHA256).Hash
$AgentBefore = (Get-FileHash $AgentBlend -Algorithm SHA256).Hash

$PreviousErrorActionPreference = $ErrorActionPreference
$ErrorActionPreference = "Continue"
try {
    & $Blender --background $AgentBlend --python $Script -- $JsonOut 2>&1 |
        Tee-Object -FilePath $Log
    $ExitCode = $LASTEXITCODE
}
finally {
    $ErrorActionPreference = $PreviousErrorActionPreference
}

$MasterAfter = (Get-FileHash $MasterBlend -Algorithm SHA256).Hash
$AgentAfter = (Get-FileHash $AgentBlend -Algorithm SHA256).Hash

$MasterUnchanged = ($MasterBefore -eq $MasterAfter)
$AgentUnchanged = ($AgentBefore -eq $AgentAfter)

if (-not (Test-Path $JsonOut)) {
    throw "Head/body scan JSON was not created. Check $Log"
}

$Data = Get-Content $JsonOut -Raw | ConvertFrom-Json

$Pass = (
    $ExitCode -eq 0 -and
    $MasterUnchanged -and
    $AgentUnchanged -and
    $Data.candidate_count -gt 0
)

@"
# Rain Head/Body Scan Report

- Mode: READ_ONLY_HEAD_BODY_SCAN
- Result: $(if ($Pass) {"PASS"} else {"FAIL"})
- Blender exit code: $ExitCode
- Pose bones: $($Data.pose_bone_count)
- Candidates found: $($Data.candidate_count)
- Master blend unchanged: $MasterUnchanged
- Agent blend unchanged: $AgentUnchanged
- JSON: handoff/latest/head_body_scan.json
- TXT: handoff/latest/head_body_scan.txt
"@ | Set-Content $Report -Encoding UTF8

Write-Host ""
Write-Host "=============================================="
Write-Host "RAIN HEAD/BODY SCAN RESULT: $(if ($Pass) {'PASS'} else {'FAIL'})"
Write-Host "=============================================="
Write-Host "Candidates: $($Data.candidate_count)"
Write-Host "Master unchanged: $MasterUnchanged"
Write-Host "Agent unchanged: $AgentUnchanged"
Write-Host "Output: $JsonOut"
Write-Host "=============================================="

if (-not $Pass) {
    throw "Head/body scan failed."
}

if ($Push) {
    git -C $RepoRoot add `
        handoff/latest/head_body_scan.json `
        handoff/latest/head_body_scan.txt `
        handoff/latest/head_body_scan_log.txt `
        handoff/latest/head_body_scan_report.md

    $Staged = git -C $RepoRoot diff --cached --name-only

    if ($Staged) {
        $Timestamp = (Get-Date).ToString("s")
        git -C $RepoRoot commit -m "Add Rain head body scan $Timestamp"
        if ($LASTEXITCODE -ne 0) { throw "git commit failed" }

        git -C $RepoRoot pull --rebase origin main
        if ($LASTEXITCODE -ne 0) { throw "git rebase failed" }

        git -C $RepoRoot push origin main
        if ($LASTEXITCODE -ne 0) { throw "git push failed" }

        Write-Host "Head/body scan pushed successfully."
    }
}
