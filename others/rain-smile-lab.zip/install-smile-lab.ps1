param(
    [string]$RepoRoot = (Join-Path $env:USERPROFILE "Desktop\blender\project4\rain-animation-agent")
)

$ErrorActionPreference = "Stop"
$Seed = Split-Path -Parent $MyInvocation.MyCommand.Path

if (-not (Test-Path (Join-Path $RepoRoot ".git"))) {
    throw "Rain repository not found: $RepoRoot"
}

New-Item -ItemType Directory -Path (Join-Path $RepoRoot "blender_tools") -Force | Out-Null

Copy-Item (Join-Path $Seed "blender_tools\render_smile_lab.py") `
          (Join-Path $RepoRoot "blender_tools\render_smile_lab.py") -Force

Copy-Item (Join-Path $Seed "collect-smile-lab.ps1") `
          (Join-Path $RepoRoot "collect-smile-lab.ps1") -Force

Write-Host ""
Write-Host "Installed READ_ONLY Rain smile lab."
Write-Host ""
Write-Host "Next:"
Write-Host "  cd $RepoRoot"
Write-Host "  powershell -ExecutionPolicy Bypass -File .\collect-smile-lab.ps1"
