# Rain Smile Lab

Face V1 is technically safe and the blink works, but the current full smile looks somewhat forced/stretched in the rendered face.

This pack does **not modify or save any `.blend` file**.

It renders five close-up, neutral-material face comparisons:

- neutral
- Smile A — very subtle
- Smile B — balanced
- Smile C — more cheek involvement
- Smile D — more upward, less sideways

The renderer uses frame 96, where the arm is relaxed, applies each candidate only in memory, renders a close-up, then exits without saving.

## GPU laptop

Install:

```powershell
powershell -ExecutionPolicy Bypass -File .\install-smile-lab.ps1
```

Then:

```powershell
cd "$HOME\Desktop\blender\project4\rain-animation-agent"
powershell -ExecutionPolicy Bypass -File .\collect-smile-lab.ps1
```

If PASS:

```powershell
powershell -ExecutionPolicy Bypass -File .\collect-smile-lab.ps1 -Push
```

Then regenerate the normal work-laptop `RAIN_CHATGPT_HANDOFF.zip` and upload it to ChatGPT.

ChatGPT can compare all five clean face renders and choose/tune the best smile before we modify the actual face animation again.
