param(
    [switch]$Push,
    [string]$RepoRoot = ""
)

$ErrorActionPreference = "Stop"

if ([string]::IsNullOrWhiteSpace($RepoRoot)) {
    $RepoRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
}

$RepoRoot = (Resolve-Path $RepoRoot).Path
$ProjectRoot = Split-Path -Parent $RepoRoot

$MasterBlend = Join-Path $ProjectRoot "project4_rain_wave_working.blend"
$AgentBlend = Join-Path $RepoRoot "workspace\agent_working.blend"
$Script = Join-Path $RepoRoot "blender_tools\render_smile_lab.py"
$Output = Join-Path $RepoRoot "handoff\latest\smile_lab"
$Log = Join-Path $RepoRoot "handoff\latest\smile_lab_log.txt"

if (-not (Test-Path $MasterBlend)) { throw "Missing master blend." }
if (-not (Test-Path $AgentBlend)) { throw "Missing agent blend." }
if (-not (Test-Path $Script)) { throw "Missing smile lab script." }

New-Item -ItemType Directory -Path $Output -Force | Out-Null
Get-ChildItem $Output -Force -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force

$Blender = Get-ChildItem "C:\Program Files\Blender Foundation" -Filter blender.exe -Recurse -ErrorAction SilentlyContinue |
    Sort-Object FullName -Descending |
    Select-Object -First 1 -ExpandProperty FullName

if (-not $Blender) { throw "Blender executable not found." }

$MasterBefore = (Get-FileHash $MasterBlend -Algorithm SHA256).Hash
$AgentBefore = (Get-FileHash $AgentBlend -Algorithm SHA256).Hash

# Blender sometimes writes harmless Python/Blender warnings to STDERR.
# With Windows PowerShell + ErrorActionPreference=Stop, those warnings can
# otherwise become NativeCommandError records and terminate the script.
$PreviousErrorActionPreference = $ErrorActionPreference
$ErrorActionPreference = "Continue"
try {
    & $Blender --background $AgentBlend --python $Script -- $Output 2>&1 |
        Tee-Object -FilePath $Log
    $ExitCode = $LASTEXITCODE
}
finally {
    $ErrorActionPreference = $PreviousErrorActionPreference
}

$MasterAfter = (Get-FileHash $MasterBlend -Algorithm SHA256).Hash
$AgentAfter = (Get-FileHash $AgentBlend -Algorithm SHA256).Hash

$MasterUnchanged = ($MasterBefore -eq $MasterAfter)
$AgentUnchanged = ($AgentBefore -eq $AgentAfter)

$Images = @(Get-ChildItem $Output -Filter "*.jpg" -ErrorAction SilentlyContinue)
$Pass = ($ExitCode -eq 0 -and $Images.Count -eq 5 -and $MasterUnchanged -and $AgentUnchanged)

@"
# Rain Smile Lab Report

- Mode: READ_ONLY_SMILE_LAB
- Result: $(if ($Pass) {"PASS"} else {"FAIL"})
- Blender exit code: $ExitCode
- Images rendered: $($Images.Count)/5
- Master blend unchanged: $MasterUnchanged
- Agent blend unchanged: $AgentUnchanged
- Output: handoff/latest/smile_lab
"@ | Set-Content (Join-Path $RepoRoot "handoff\latest\smile_lab_report.md") -Encoding UTF8

Write-Host ""
Write-Host "=============================================="
Write-Host "RAIN SMILE LAB RESULT: $(if ($Pass) {'PASS'} else {'FAIL'})"
Write-Host "=============================================="
Write-Host "Blender exit code: $ExitCode"
Write-Host "Images: $($Images.Count)/5"
Write-Host "Master unchanged: $MasterUnchanged"
Write-Host "Agent unchanged: $AgentUnchanged"
Write-Host "Output: $Output"
Write-Host "=============================================="

if (-not $Pass) {
    throw "Smile lab failed. Check $Log"
}

if ($Push) {
    git -C $RepoRoot add handoff/latest/smile_lab handoff/latest/smile_lab_log.txt handoff/latest/smile_lab_report.md
    $Staged = git -C $RepoRoot diff --cached --name-only
    if ($Staged) {
        $Timestamp = (Get-Date).ToString("s")
        git -C $RepoRoot commit -m "Add Rain smile lab handoff $Timestamp"
        if ($LASTEXITCODE -ne 0) { throw "git commit failed" }
        git -C $RepoRoot pull --rebase origin main
        if ($LASTEXITCODE -ne 0) { throw "git rebase failed" }
        git -C $RepoRoot push origin main
        if ($LASTEXITCODE -ne 0) { throw "git push failed" }
        Write-Host "Smile lab pushed successfully."
    }
}
