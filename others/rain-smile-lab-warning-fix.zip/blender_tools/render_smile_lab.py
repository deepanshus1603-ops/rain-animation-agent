import bpy
import json
import os
import sys
import warnings
from mathutils import Vector

warnings.filterwarnings("ignore", category=DeprecationWarning)

RIG_NAME = "RIG-rain"
BASE_FRAME = 96

CANDIDATES = {
    "neutral": {
        "lip_l": (0.0, 0.0, 0.0),
        "lip_r": (0.0, 0.0, 0.0),
        "cheek_l": (0.0, 0.0, 0.0),
        "cheek_r": (0.0, 0.0, 0.0),
    },
    "smile_A_subtle": {
        "lip_l": (0.0035, 0.0015, 0.0100),
        "lip_r": (-0.0032, 0.0015, 0.0105),
        "cheek_l": (0.0, 0.0008, 0.0),
        "cheek_r": (0.0, 0.0008, 0.0),
    },
    "smile_B_balanced": {
        "lip_l": (0.0040, 0.0020, 0.0135),
        "lip_r": (-0.0038, 0.0020, 0.0140),
        "cheek_l": (0.0, 0.0014, 0.0),
        "cheek_r": (0.0, 0.0013, 0.0),
    },
    "smile_C_cheek": {
        "lip_l": (0.0045, 0.0025, 0.0155),
        "lip_r": (-0.0041, 0.0025, 0.0160),
        "cheek_l": (0.0, 0.0022, 0.0),
        "cheek_r": (0.0, 0.0020, 0.0),
    },
    "smile_D_upward": {
        "lip_l": (0.0035, 0.0030, 0.0170),
        "lip_r": (-0.0032, 0.0028, 0.0175),
        "cheek_l": (0.0, 0.0028, 0.0),
        "cheek_r": (0.0, 0.0025, 0.0),
    },
}

def parse_args():
    out_dir = os.path.abspath(bpy.path.abspath("//smile_lab"))
    if "--" in sys.argv:
        args = sys.argv[sys.argv.index("--") + 1:]
        if args:
            out_dir = os.path.abspath(args[0])
    return out_dir

def look_at(obj, target):
    obj.rotation_euler = (Vector(target) - obj.location).to_track_quat("-Z", "Y").to_euler()

def bounds_for_objects(objects):
    pts = []
    for obj in objects:
        try:
            pts.extend(obj.matrix_world @ Vector(c) for c in obj.bound_box)
        except Exception:
            pass
    if not pts:
        return Vector((0,0,1.6)), Vector((0.5,0.4,0.5))
    mn = Vector((min(p.x for p in pts), min(p.y for p in pts), min(p.z for p in pts)))
    mx = Vector((max(p.x for p in pts), max(p.y for p in pts), max(p.z for p in pts)))
    return (mn+mx)*0.5, mx-mn

def face_subjects():
    exact = bpy.data.objects.get("GEO-rain-head")
    if exact and exact.type == "MESH":
        objs = [exact]
        for o in bpy.context.scene.objects:
            n = o.name.lower()
            if o.type == "MESH" and "rain" in n and any(k in n for k in ("head","eye","hair","brow","lash","teeth","mouth")):
                if o not in objs:
                    objs.append(o)
        return objs
    candidates = [o for o in bpy.context.scene.objects if o.type == "MESH" and "rain" in o.name.lower()]
    return candidates if candidates else [o for o in bpy.context.scene.objects if o.type == "MESH"]

def create_camera(scene):
    center, size = bounds_for_objects(face_subjects())
    height = max(float(size.z), 0.35)
    width = max(float(size.x), 0.30)
    target = Vector((center.x, center.y, center.z))
    distance = max(height * 2.4, width * 2.7, 1.15)
    data = bpy.data.cameras.new("RAIN_SMILE_LAB_CAMERA_DATA")
    cam = bpy.data.objects.new("RAIN_SMILE_LAB_CAMERA", data)
    scene.collection.objects.link(cam)
    cam.location = Vector((target.x, target.y - distance, target.z))
    data.lens = 62
    look_at(cam, target)
    scene.camera = cam
    return cam, center, size

def create_lights(scene, center, size):
    h = max(float(size.z), 0.4)
    w = max(float(size.x), 0.3)
    lights = []
    def area(name, loc, energy, area_size):
        data = bpy.data.lights.new(name+"_DATA", "AREA")
        data.energy = energy
        data.size = area_size
        obj = bpy.data.objects.new(name, data)
        scene.collection.objects.link(obj)
        obj.location = Vector(loc)
        look_at(obj, center)
        lights.append(obj)
    area("RAIN_LAB_KEY", (center.x-w*2.0, center.y-h*2.0, center.z+h*1.1), 650, h*1.5)
    area("RAIN_LAB_FILL", (center.x+w*1.7, center.y-h*1.5, center.z+h*0.6), 350, h*1.7)
    area("RAIN_LAB_RIM", (center.x, center.y+h*1.8, center.z+h*1.0), 450, h*1.2)
    return lights

def make_override_material():
    mat = bpy.data.materials.new("RAIN_SMILE_LAB_GRAY")
    # Blender 5.2 still supports this, but emits a deprecation warning.
    # Warnings are suppressed above because this process is read-only and temporary.
    mat.use_nodes = True
    bsdf = mat.node_tree.nodes.get("Principled BSDF")
    if bsdf:
        bsdf.inputs["Base Color"].default_value = (0.38, 0.38, 0.38, 1.0)
        bsdf.inputs["Roughness"].default_value = 0.6
    return mat

def set_pose(rig, candidate):
    values = [
        ("ACT-Lips_Corner.L", candidate["lip_l"]),
        ("ACT-Lips_Corner.R", candidate["lip_r"]),
        ("ACT-Cheek_Outer.L", candidate["cheek_l"]),
        ("ACT-Cheek_Outer.R", candidate["cheek_r"]),
    ]
    for name, loc in values:
        pb = rig.pose.bones.get(name)
        if pb is None:
            raise RuntimeError(f"Missing face control: {name}")
        pb.location = loc

def set_eyes_open(rig):
    for name in (
        "ACT-Eyelid_Upper.L","ACT-Eyelid_Upper.R",
        "ACT-Eyelid_Lower.L","ACT-Eyelid_Lower.R"
    ):
        pb = rig.pose.bones.get(name)
        if pb is None:
            raise RuntimeError(f"Missing eyelid control: {name}")
        pb.location = (0.0,0.0,0.0)

out_dir = parse_args()
os.makedirs(out_dir, exist_ok=True)

scene = bpy.context.scene
rig = bpy.data.objects.get(RIG_NAME)
if rig is None:
    raise RuntimeError("RIG-rain not found.")

original = {
    "camera": scene.camera,
    "engine": scene.render.engine,
    "x": scene.render.resolution_x,
    "y": scene.render.resolution_y,
    "pct": scene.render.resolution_percentage,
    "format": scene.render.image_settings.file_format,
    "quality": scene.render.image_settings.quality,
    "filepath": scene.render.filepath,
    "frame": scene.frame_current,
    "material_override": scene.view_layers[0].material_override,
}

scene.frame_set(BASE_FRAME)
cam, center, size = create_camera(scene)
lights = create_lights(scene, center, size)
gray = make_override_material()
scene.view_layers[0].material_override = gray

try:
    try:
        scene.render.engine = "BLENDER_EEVEE_NEXT"
    except Exception:
        pass
    scene.render.resolution_x = 720
    scene.render.resolution_y = 720
    scene.render.resolution_percentage = 100
    scene.render.image_settings.file_format = "JPEG"
    scene.render.image_settings.quality = 94

    manifest = {
        "mode": "READ_ONLY_SMILE_LAB",
        "base_frame": BASE_FRAME,
        "candidates": CANDIDATES,
        "images": [],
    }

    for name, candidate in CANDIDATES.items():
        set_pose(rig, candidate)
        set_eyes_open(rig)
        bpy.context.view_layer.update()
        filename = name + ".jpg"
        filepath = os.path.join(out_dir, filename)
        scene.render.filepath = filepath
        bpy.ops.render.render(write_still=True)
        manifest["images"].append({"name": name, "file": filename})
        print("RAIN_SMILE_LAB_OK", name, filepath)

    with open(os.path.join(out_dir, "smile_lab_manifest.json"), "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2)

finally:
    scene.camera = original["camera"]
    scene.render.engine = original["engine"]
    scene.render.resolution_x = original["x"]
    scene.render.resolution_y = original["y"]
    scene.render.resolution_percentage = original["pct"]
    scene.render.image_settings.file_format = original["format"]
    scene.render.image_settings.quality = original["quality"]
    scene.render.filepath = original["filepath"]
    scene.frame_set(original["frame"])
    scene.view_layers[0].material_override = original["material_override"]

print("RAIN_SMILE_LAB_COMPLETE")
print("READ ONLY: YES")
print("Output:", out_dir)
