# Rain Smile Lab — Warning Handling Fix

Your prior run stopped on:

```text
DeprecationWarning: 'Material.use_nodes' is expected to be removed in Blender 6.0
NativeCommandError
```

That is a warning, not a Blender render failure.

Windows PowerShell was converting Blender's STDERR warning into a `NativeCommandError` because the collector used:

```powershell
$ErrorActionPreference = "Stop"
```

This patch does two things:

1. suppresses Python `DeprecationWarning` messages inside the temporary Blender smile-lab process;
2. temporarily uses `ErrorActionPreference = Continue` only around the Blender native process, then checks Blender's actual exit code.

The lab remains READ_ONLY and verifies both `.blend` file hashes stay unchanged.

## Run

```powershell
powershell -ExecutionPolicy Bypass -File .\install-smile-lab-warning-fix.ps1
```

Then:

```powershell
cd "$HOME\Desktop\blender\project4\rain-animation-agent"
powershell -ExecutionPolicy Bypass -File .\collect-smile-lab.ps1
```

If PASS:

```powershell
powershell -ExecutionPolicy Bypass -File .\collect-smile-lab.ps1 -Push
```
