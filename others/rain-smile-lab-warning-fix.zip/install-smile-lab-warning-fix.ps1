param(
    [string]$RepoRoot = (Join-Path $env:USERPROFILE "Desktop\blender\project4\rain-animation-agent")
)

$ErrorActionPreference = "Stop"
$Seed = Split-Path -Parent $MyInvocation.MyCommand.Path

if (-not (Test-Path (Join-Path $RepoRoot ".git"))) {
    throw "Rain repository not found: $RepoRoot"
}

$TargetPy = Join-Path $RepoRoot "blender_tools\render_smile_lab.py"
$TargetPs = Join-Path $RepoRoot "collect-smile-lab.ps1"

if (Test-Path $TargetPy) { Copy-Item $TargetPy "$TargetPy.bak" -Force }
if (Test-Path $TargetPs) { Copy-Item $TargetPs "$TargetPs.bak" -Force }

Copy-Item (Join-Path $Seed "blender_tools\render_smile_lab.py") $TargetPy -Force
Copy-Item (Join-Path $Seed "collect-smile-lab.ps1") $TargetPs -Force

Write-Host ""
Write-Host "Installed smile-lab warning handling fix."
Write-Host ""
Write-Host "This fixes Windows PowerShell treating harmless Blender STDERR warnings as fatal NativeCommandError records."
