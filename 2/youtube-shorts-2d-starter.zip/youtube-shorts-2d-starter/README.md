# YouTube Shorts 2D Starter

A very small Python-based 2D animation project for making 15-second vertical Shorts quickly.

## Short #1: The Second Banana

Timeline:
- 0-3s: Alex enters from the left
- 3-6s: notices the first banana
- 6-8s: steps over it
- 8-11s: slips on a second banana
- 11-13s: falls out of frame
- 13-15s: pops back up, annoyed
- Caption: "Seriously?"

## 1. Install

Windows PowerShell:

    py -m venv .venv
    .\.venv\Scripts\Activate.ps1
    python -m pip install -r requirements.txt

If `py` is unavailable, use `python` instead.

## 2. Render

    python render.py

The finished file will be:

    output/short_001.mp4

## 3. Character artwork

The included Alex images are simple generated placeholder sprites so the project runs immediately.

Replace these later with transparent PNG exports of the approved Alex design:

    assets/character/alex_neutral.png
    assets/character/alex_shocked.png
    assets/character/alex_falling.png
    assets/character/alex_annoyed.png

Keep roughly the same transparent canvas size and filenames.

## 4. Edit the story

Open:

    scene.json

Change captions/timing there. `render.py` contains the animation functions.

Canvas: 1080 x 1920
Duration: 15 seconds
FPS: 30
