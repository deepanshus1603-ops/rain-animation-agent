from pathlib import Path
import json, math
import numpy as np
from PIL import Image, ImageDraw, ImageFont
from moviepy import VideoClip

ROOT = Path(__file__).resolve().parent
CFG = json.loads((ROOT / "scene.json").read_text(encoding="utf-8"))
W, H = CFG["width"], CFG["height"]
DURATION, FPS = CFG["duration"], CFG["fps"]

BG = Image.open(ROOT/"assets/backgrounds/room.png").convert("RGB").resize((W,H))
SPRITES = {
    k: Image.open(ROOT/f"assets/character/alex_{k}.png").convert("RGBA")
    for k in ["neutral","shocked","falling","annoyed"]
}
BANANA = Image.open(ROOT/"assets/props/banana.png").convert("RGBA")

def paste_scaled(base, sprite, xy, scale=1.0, angle=0):
    nw=max(1,int(sprite.width*scale)); nh=max(1,int(sprite.height*scale))
    s=sprite.resize((nw,nh),Image.Resampling.LANCZOS)
    if angle:
        s=s.rotate(angle,resample=Image.Resampling.BICUBIC,expand=True)
    base.paste(s,(int(xy[0]),int(xy[1])),s)

def ease(a):
    a=max(0,min(1,a))
    return a*a*(3-2*a)

def frame(t):
    im=BG.copy().convert("RGBA")
    # Two banana peels
    paste_scaled(im,BANANA,(600,1325),0.62,-8)
    paste_scaled(im,BANANA,(820,1355),0.58,12)

    # Character state / movement
    if t < 3:
        p=ease(t/3)
        x=-260 + p*620
        y=650 + math.sin(t*9)*7
        sprite=SPRITES["neutral"]
        scale=.92
        angle=0
    elif t < 6:
        p=ease((t-3)/3)
        x=360 + p*120
        y=650
        sprite=SPRITES["shocked"] if t>4.5 else SPRITES["neutral"]
        scale=.92
        angle=0
    elif t < 8:
        p=ease((t-6)/2)
        x=480+p*300
        y=650 - math.sin(p*math.pi)*95
        sprite=SPRITES["neutral"]
        scale=.92
        angle=-3*math.sin(p*math.pi)
    elif t < 11:
        p=ease((t-8)/3)
        x=760-p*110
        y=650+p*420
        sprite=SPRITES["falling"]
        scale=.96
        angle=-28*p
    elif t < 13:
        x=650
        y=1200 + (t-11)*380
        sprite=SPRITES["falling"]
        scale=.96
        angle=-28
    else:
        p=ease((t-13)/1.0)
        x=290
        y=1510-p*360
        sprite=SPRITES["annoyed"]
        scale=1.05
        angle=0

    paste_scaled(im,sprite,(x,y),scale,angle)

    # Caption
    if CFG["caption_start"] <= t <= CFG["caption_end"]:
        draw=ImageDraw.Draw(im)
        text=CFG["caption"]
        try:
            font=ImageFont.truetype("arialbd.ttf",92)
        except:
            font=ImageFont.load_default()
        box=draw.textbbox((0,0),text,font=font,stroke_width=4)
        tw=box[2]-box[0]; th=box[3]-box[1]
        cx=(W-tw)//2
        cy=230
        pad=32
        draw.rounded_rectangle((cx-pad,cy-pad,cx+tw+pad,cy+th+pad),
                               radius=30,fill=(255,255,255,235))
        draw.text((cx,cy),text,font=font,fill=(25,25,25,255),
                  stroke_width=4,stroke_fill=(255,255,255,255))
    return np.array(im.convert("RGB"))

if __name__ == "__main__":
    out=ROOT/"output"/"short_001.mp4"
    out.parent.mkdir(exist_ok=True)
    clip=VideoClip(frame_function=frame,duration=DURATION)
    clip.write_videofile(str(out),fps=FPS,codec="libx264",audio=False,
                         preset="medium",pixel_format="yuv420p")
    print(f"\nDONE: {out}")
