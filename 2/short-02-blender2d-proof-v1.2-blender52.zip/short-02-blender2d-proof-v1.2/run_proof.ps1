$ErrorActionPreference = "Stop"

$project = Split-Path -Parent $MyInvocation.MyCommand.Path
$script = Join-Path $project "scripts\build_and_render_proof.py"
$outputDir = Join-Path $project "output"
$blendOut = Join-Path $outputDir "short02_blender2d_proof.blend"
$videoOut = Join-Path $outputDir "short02_blender2d_proof.mp4"

$blender = $null

$cmd = Get-Command blender -ErrorAction SilentlyContinue
if ($cmd) {
    $blender = $cmd.Source
}

if (-not $blender) {
    $known = @(
        "C:\Program Files\Blender Foundation\Blender 5.2\blender.exe",
        "C:\Program Files\Blender Foundation\Blender 5.1\blender.exe",
        "C:\Program Files\Blender Foundation\Blender 5.0\blender.exe",
        "C:\Program Files\Blender Foundation\Blender 4.5\blender.exe"
    )

    foreach ($candidate in $known) {
        if (Test-Path $candidate) {
            $blender = $candidate
            break
        }
    }
}

if (-not $blender -and (Test-Path "C:\Program Files\Blender Foundation")) {
    $found = Get-ChildItem "C:\Program Files\Blender Foundation" `
        -Filter blender.exe -Recurse -ErrorAction SilentlyContinue |
        Select-Object -First 1

    if ($found) {
        $blender = $found.FullName
    }
}

if (-not $blender) {
    Write-Host "FAILED: Blender executable not found." -ForegroundColor Red
    exit 1
}

Write-Host "Using Blender: $blender" -ForegroundColor Cyan
Write-Host "Blender 5.2 video-output compatibility patch enabled." -ForegroundColor Cyan
Write-Host "Building and rendering 3-second proof..." -ForegroundColor Cyan

New-Item -ItemType Directory -Force -Path $outputDir | Out-Null

if (Test-Path $blendOut) { Remove-Item $blendOut -Force }
if (Test-Path $videoOut) { Remove-Item $videoOut -Force }

& $blender --background --python $script

if ($LASTEXITCODE -ne 0) {
    Write-Host ""
    Write-Host "FAILED: Blender returned exit code $LASTEXITCODE." -ForegroundColor Red
    exit $LASTEXITCODE
}

if (-not (Test-Path $blendOut)) {
    Write-Host ""
    Write-Host "FAILED: .blend file was not created." -ForegroundColor Red
    Write-Host "Read the Blender Python error above." -ForegroundColor Yellow
    exit 2
}

if ((Get-Item $blendOut).Length -le 0) {
    Write-Host ""
    Write-Host "FAILED: .blend file is empty." -ForegroundColor Red
    exit 3
}

if (-not (Test-Path $videoOut)) {
    Write-Host ""
    Write-Host "FAILED: MP4 file was not created." -ForegroundColor Red
    Write-Host "Read the Blender render error above." -ForegroundColor Yellow
    exit 4
}

if ((Get-Item $videoOut).Length -le 0) {
    Write-Host ""
    Write-Host "FAILED: MP4 file is empty." -ForegroundColor Red
    exit 5
}

Write-Host ""
Write-Host "SUCCESS" -ForegroundColor Green
Write-Host "Blend: output\short02_blender2d_proof.blend"
Write-Host "Video: output\short02_blender2d_proof.mp4"
Write-Host ("Video size: {0:N2} MB" -f ((Get-Item $videoOut).Length / 1MB))
