$ErrorActionPreference = "Stop"

$project = Split-Path -Parent $MyInvocation.MyCommand.Path
$script = Join-Path $project "scripts\build_and_render_proof.py"

$blender = $null

# First try PATH.
$cmd = Get-Command blender -ErrorAction SilentlyContinue
if ($cmd) { $blender = $cmd.Source }

# Then common Blender Foundation install folders.
if (-not $blender) {
    $roots = @(
        "C:\Program Files\Blender Foundation\Blender 5.2\blender.exe",
        "C:\Program Files\Blender Foundation\Blender 5.1\blender.exe",
        "C:\Program Files\Blender Foundation\Blender 5.0\blender.exe",
        "C:\Program Files\Blender Foundation\Blender 4.5\blender.exe"
    )
    foreach ($candidate in $roots) {
        if (Test-Path $candidate) { $blender = $candidate; break }
    }
}

# Last resort: search Blender Foundation directory one level deep.
if (-not $blender -and (Test-Path "C:\Program Files\Blender Foundation")) {
    $found = Get-ChildItem "C:\Program Files\Blender Foundation" -Filter blender.exe -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($found) { $blender = $found.FullName }
}

if (-not $blender) {
    Write-Host "Blender executable was not found." -ForegroundColor Red
    Write-Host "Edit run_proof.ps1 and set `$blender to your blender.exe path." -ForegroundColor Yellow
    exit 1
}

Write-Host "Using Blender: $blender" -ForegroundColor Cyan
Write-Host "Building and rendering 3-second proof..." -ForegroundColor Cyan
& $blender --background --python $script

if ($LASTEXITCODE -ne 0) {
    Write-Host "Blender returned exit code $LASTEXITCODE" -ForegroundColor Red
    exit $LASTEXITCODE
}

Write-Host "" 
Write-Host "DONE" -ForegroundColor Green
Write-Host "Blend: output\short02_blender2d_proof.blend"
Write-Host "Video: output\short02_blender2d_proof.mp4"
