$ErrorActionPreference = "Stop"
& .\.venv\Scripts\python.exe render_v4.py
