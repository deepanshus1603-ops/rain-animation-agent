$ErrorActionPreference = "Stop"
& .\.venv\Scripts\python.exe render_v4_1_safe.py
