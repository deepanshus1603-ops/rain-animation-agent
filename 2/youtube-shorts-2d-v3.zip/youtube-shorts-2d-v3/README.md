# 2D Shorts V3 — The Second Banana

This version is based on review of the actual V2 MP4.

## What V3 fixes

- Alex is larger in frame
- walking bob is reduced
- stepping over banana no longer looks like a jump
- second banana gets a stronger delayed reveal
- slip pivots Alex backward instead of throwing him sideways off-screen
- fall stays visible longer and then drops downward
- impact gets a quick comic burst
- clean empty-room pause after the crash
- final Alex reaction rises more naturally
- removed emoji that rendered as a square on Windows
- commentary is shorter so it does not fight the action
- adds low-volume original cartoon background music
- keeps footsteps / slip / whoosh / impact SFX

## Setup

If you already have the V2 environment, you can still run setup again safely.

    .\setup.ps1

If PowerShell blocks scripts:

    python -m venv .venv
    .\.venv\Scripts\python.exe -m pip install -r requirements.txt

## Render

    .\run.ps1

or:

    .\.venv\Scripts\python.exe render_v3.py

Output:

    output\short_001_v3.mp4

The first run requires internet for Edge TTS.

## Optional QA contact sheet

After rendering:

    .\.venv\Scripts\python.exe qa_contact_sheet.py

This creates:

    output\short_001_v3_contact_sheet.jpg

You can upload either the MP4 or that contact sheet to ChatGPT for review.

## Important next milestone

V3 is still using programmatically drawn Alex sprites. Once motion/timing is locked, the next upgrade should be a proper reusable illustrated sprite pack matching the approved Alex reference sheet.
