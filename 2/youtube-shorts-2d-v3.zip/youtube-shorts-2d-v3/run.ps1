$ErrorActionPreference = "Stop"
& .\.venv\Scripts\python.exe render_v3.py
