from pathlib import Path
import json, math, asyncio, os
import numpy as np
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parent
CFG = json.loads((ROOT/"scene.json").read_text(encoding="utf-8"))
W, H = CFG["width"], CFG["height"]
DURATION, FPS = CFG["duration"], CFG["fps"]

BG = Image.open(ROOT/"assets/backgrounds/room_v2.png").convert("RGB").resize((W,H))

def load(name):
    return Image.open(ROOT/"assets/character"/f"alex_{name}.png").convert("RGBA")

SPR = {name: load(name) for name in
       ["stand","walk_a","walk_b","look_down","confident","step","shocked","slip","falling","annoyed"]}

BANANA = Image.open(ROOT/"assets/props/banana.png").convert("RGBA")
BANANA_FLAT = Image.open(ROOT/"assets/props/banana_flat.png").convert("RGBA")

def ease(x):
    x=max(0,min(1,x))
    return x*x*(3-2*x)

def ease_out_back(x):
    x=max(0,min(1,x))
    c1=1.70158
    c3=c1+1
    return 1 + c3*(x-1)**3 + c1*(x-1)**2

def paste(base, sprite, x, y, scale=1.0, angle=0, flip=False):
    s=sprite
    if flip:
        s=s.transpose(Image.Transpose.FLIP_LEFT_RIGHT)
    if scale != 1:
        s=s.resize((max(1,int(s.width*scale)), max(1,int(s.height*scale))),
                   Image.Resampling.LANCZOS)
    if angle:
        s=s.rotate(angle, resample=Image.Resampling.BICUBIC, expand=True)
    base.paste(s, (int(x),int(y)), s)

def get_font(size,bold=True):
    candidates=[
        "C:/Windows/Fonts/arialbd.ttf" if bold else "C:/Windows/Fonts/arial.ttf",
        "C:/Windows/Fonts/segoeuib.ttf" if bold else "C:/Windows/Fonts/segoeui.ttf",
    ]
    for p in candidates:
        if os.path.exists(p):
            return ImageFont.truetype(p,size)
    return ImageFont.load_default()

def caption_for(t):
    for c in CFG["captions"]:
        if c["start"] <= t <= c["end"]:
            return c["text"], c["start"]
    return None, None

def draw_caption(im, text, start, t):
    dr=ImageDraw.Draw(im)
    age=max(0,t-start)
    # tiny pop-in motion
    pop=min(1.0, age/0.12)
    y=int(190 - (1-pop)*24)
    size=90 if len(text)<15 else 74
    font=get_font(size,True)
    box=dr.textbbox((0,0),text,font=font,stroke_width=4)
    tw,th=box[2]-box[0],box[3]-box[1]
    cx=(W-tw)//2
    pad=28
    dr.rounded_rectangle((cx-pad,y-pad,cx+tw+pad,y+th+pad),
                         radius=28, fill=(255,255,255,238))
    dr.text((cx,y),text,font=font,fill=(25,25,25,255),
            stroke_width=4,stroke_fill=(255,255,255,255))

def draw_reveal_lines(im, center, strength=1.0):
    dr=ImageDraw.Draw(im)
    cx,cy=center
    for ang in np.linspace(-2.7,-0.45,6):
        r1=52
        r2=105 + 20*strength
        x1=cx+math.cos(ang)*r1
        y1=cy+math.sin(ang)*r1
        x2=cx+math.cos(ang)*r2
        y2=cy+math.sin(ang)*r2
        dr.line((x1,y1,x2,y2),fill=(242,179,25,255),width=10)

def draw_impact(im, t):
    # quick starburst at the bottom-center after the fall
    if not (9.55 <= t <= 10.12):
        return
    p=(t-9.55)/(10.12-9.55)
    dr=ImageDraw.Draw(im)
    cx,cy=650,1435
    r1=30
    r2=125*(1-min(1,p))
    pts=[]
    for i in range(16):
        ang=math.pi*2*i/16
        r=(r2 if i%2==0 else r1)
        pts.append((cx+math.cos(ang)*r,cy+math.sin(ang)*r))
    if r2>35:
        dr.polygon(pts,fill=(255,217,74,210),outline=(89,58,32,255))

def frame(t):
    im=BG.copy().convert("RGBA")

    # First banana: only enters the visual story when Alex notices it.
    if t >= 2.20:
        paste(im,BANANA,520,1328,.56,-8)

    # Second banana: delayed reveal.
    if 7.28 <= t < 8.05:
        p=ease((t-7.28)/0.77)
        paste(im,BANANA,825,1343,.53,10)
        draw_reveal_lines(im,(875,1350),p)
    elif t >= 8.05:
        paste(im,BANANA_FLAT if t>=8.20 else BANANA,825,1343,.53,8)

    # Character blocking.
    scale=.94

    if t < 2.15:
        p=ease(t/2.15)
        x=-420+p*700
        # much smaller vertical bob so it reads as walking rather than hopping
        y=530 + math.sin(t*13)*4
        pose="walk_a" if int(t*5)%2==0 else "walk_b"
        angle=0

    elif t < 3.15:
        p=ease((t-2.15)/1.0)
        x=280+p*115
        y=530
        pose="look_down"
        angle=0

    elif t < 4.25:
        x=395; y=530; pose="look_down"; angle=0

    elif t < 5.45:
        x=395; y=530; pose="confident"; angle=0

    elif t < 6.75:
        p=ease((t-5.45)/1.30)
        x=395+p*265
        # only a subtle body lift: the lifted leg sprite provides the "step"
        y=530-math.sin(p*math.pi)*28
        pose="step"
        angle=-2.5*math.sin(p*math.pi)

    elif t < 7.30:
        x=660; y=530; pose="confident"; angle=0

    elif t < 7.72:
        # brief frozen "wait..." beat
        x=660; y=530; pose="shocked"; angle=0

    elif t < 8.10:
        p=ease((t-7.72)/0.38)
        x=660+p*75
        y=530
        pose="step"
        angle=0

    elif t < 9.18:
        # Pivot back toward the left, not sideways out of frame.
        p=ease((t-8.10)/1.08)
        x=735-p*110
        y=530+p*110
        pose="slip"
        angle=58*p

    elif t < 9.82:
        # Drop mainly DOWN while remaining visible.
        p=ease((t-9.18)/0.64)
        x=625-p*30
        y=640+p*510
        pose="falling"
        angle=58+20*p

    elif t < 12.00:
        # Clean empty-room comedy pause after the impact.
        x=0; y=2300; pose="stand"; angle=0

    else:
        # Slow, slightly overshooting pop-up reaction.
        p=ease_out_back((t-12.00)/0.95)
        p=max(0,min(1.08,p))
        x=250
        y=1500-p*570
        pose="annoyed"
        angle=0

    paste(im,SPR[pose],x,y,scale,angle)

    draw_impact(im,t)

    cap,start=caption_for(t)
    if cap:
        draw_caption(im,cap,start,t)

    return np.array(im.convert("RGB"))

async def ensure_tts():
    try:
        import edge_tts
    except Exception:
        print("edge-tts not installed; narration will be skipped.")
        return []
    outdir=ROOT/"cache"/"tts"
    outdir.mkdir(parents=True,exist_ok=True)
    tracks=[]
    for i,line in enumerate(CFG["dialogue"]):
        p=outdir/f"{i:02d}_{line['speaker']}.mp3"
        if not p.exists():
            voice=CFG["voice"][line["speaker"]]
            rate="+5%" if line["speaker"]=="narrator" else "+2%"
            communicate=edge_tts.Communicate(line["text"],voice,rate=rate)
            await communicate.save(str(p))
        tracks.append((p,float(line["start"])))
    return tracks

def main():
    from moviepy import VideoClip, AudioFileClip, CompositeAudioClip

    levels=CFG.get("audio_levels",{})
    tts_tracks=asyncio.run(ensure_tts())
    audio=[]

    for p,start in tts_tracks:
        try:
            a=AudioFileClip(str(p)).with_start(start)
            try:
                a=a.with_volume_scaled(float(levels.get("voice",1.0)))
            except Exception:
                pass
            audio.append(a)
        except Exception as e:
            print("Voice warning:",e)

    sfx=[
        ("footstep_1.wav",0.55,0.50),
        ("footstep_2.wav",0.98,0.50),
        ("footstep_3.wav",1.41,0.50),
        ("footstep_4.wav",1.84,0.50),
        ("sting.wav",7.30,0.56),
        ("slip.wav",8.08,0.90),
        ("whoosh.wav",8.18,0.72),
        ("impact.wav",9.67,1.00),
    ]
    master_sfx=float(levels.get("sfx",0.85))
    for fname,start,vol in sfx:
        p=ROOT/"assets"/"audio"/fname
        a=AudioFileClip(str(p)).with_start(start)
        try:
            a=a.with_volume_scaled(vol*master_sfx)
        except Exception:
            pass
        audio.append(a)

    music_path=ROOT/"assets"/"audio"/"cartoon_bed.wav"
    if music_path.exists():
        m=AudioFileClip(str(music_path)).with_start(0)
        try:
            m=m.with_volume_scaled(float(levels.get("music",0.075)))
        except Exception:
            pass
        audio.append(m)

    clip=VideoClip(frame_function=frame,duration=DURATION)
    if audio:
        clip=clip.with_audio(CompositeAudioClip(audio))

    out=ROOT/"output"/"short_001_v3.mp4"
    out.parent.mkdir(exist_ok=True)
    clip.write_videofile(str(out),fps=FPS,codec="libx264",audio_codec="aac",
                         preset="medium",pixel_format="yuv420p",threads=4)
    print("\nDONE:",out)

if __name__=="__main__":
    main()
