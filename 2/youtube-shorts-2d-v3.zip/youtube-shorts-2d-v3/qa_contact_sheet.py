from pathlib import Path
import cv2
from PIL import Image, ImageDraw, ImageFont

ROOT=Path(__file__).resolve().parent
VIDEO=ROOT/"output"/"short_001_v3.mp4"
OUT=ROOT/"output"/"short_001_v3_contact_sheet.jpg"

times=[0.5,1.5,2.6,3.5,4.8,6.2,7.5,8.2,8.8,9.5,10.5,11.5,12.6,13.5,14.5]
cap=cv2.VideoCapture(str(VIDEO))
thumbs=[]
for t in times:
    cap.set(cv2.CAP_PROP_POS_MSEC,t*1000)
    ok,fr=cap.read()
    if not ok:
        continue
    fr=cv2.cvtColor(fr,cv2.COLOR_BGR2RGB)
    img=Image.fromarray(fr)
    img.thumbnail((216,384))
    thumbs.append((t,img.copy()))
cap.release()

sheet=Image.new("RGB",(216*5,430*3),"white")
draw=ImageDraw.Draw(sheet)
for i,(t,img) in enumerate(thumbs):
    x=(i%5)*216
    y=(i//5)*430
    sheet.paste(img,(x,y+25))
    draw.text((x+6,y+4),f"{t:.1f}s",fill="black")
sheet.save(OUT,quality=92)
print("DONE:",OUT)
