from pathlib import Path
import json, math, os
import numpy as np
from PIL import Image, ImageDraw, ImageFont
from moviepy import VideoClip

ROOT=Path(__file__).resolve().parent
CFG=json.loads((ROOT/"scene.json").read_text(encoding="utf-8"))
W,H=CFG["width"],CFG["height"]
DURATION,FPS=CFG["duration"],CFG["fps"]

BG=Image.open(ROOT/"assets/backgrounds/bangalore_traffic_placeholder.png").convert("RGB").resize((W,H))
PHONE=Image.open(ROOT/"assets/props/phone.png").convert("RGBA")
COFFEE=Image.open(ROOT/"assets/props/coffee.png").convert("RGBA")
LAPTOP=Image.open(ROOT/"assets/props/laptop.png").convert("RGBA")
N_MEETING=Image.open(ROOT/"assets/ui/meeting_5_min.png").convert("RGBA")
N_MANAGER=Image.open(ROOT/"assets/ui/manager_office.png").convert("RGBA")

# Reuse existing Alex sprites as fallback until real Cartoon Animator export is ready.
def load_sprite(name, fallback="alex_idle.png"):
    p=ROOT/"assets/character"/name
    if not p.exists():
        p=ROOT/"assets/character"/fallback
    return Image.open(p).convert("RGBA")

ALEX_IDLE=load_sprite("alex_idle.png")
ALEX_NOTICE=load_sprite("alex_notice.png")
ALEX_SHOCK=load_sprite("alex_shocked.png")
ALEX_ANNOYED=load_sprite("alex_annoyed.png")

def resize(im,scale):
    return im.resize((int(im.width*scale),int(im.height*scale)),Image.Resampling.LANCZOS)

def paste(base,im,x,y,scale=1,angle=0):
    s=resize(im,scale)
    if angle:
        s=s.rotate(angle,resample=Image.Resampling.BICUBIC,expand=True)
    base.paste(s,(int(x),int(y)),s)

def font(size,bold=True):
    for p in [
        "C:/Windows/Fonts/arialbd.ttf" if bold else "C:/Windows/Fonts/arial.ttf",
        "C:/Windows/Fonts/segoeuib.ttf" if bold else "C:/Windows/Fonts/segoeui.ttf",
    ]:
        if os.path.exists(p):
            return ImageFont.truetype(p,size)
    return ImageFont.load_default()

def caption_for(t):
    for c in CFG["captions"]:
        if c["start"]<=t<=c["end"]:
            return c
    return None

def draw_caption(im,c):
    d=ImageDraw.Draw(im)
    f=font(72 if len(c["text"])>18 else 86,True)
    box=d.textbbox((0,0),c["text"],font=f,stroke_width=4)
    tw=box[2]-box[0]; th=box[3]-box[1]
    x=(W-tw)//2; y=120
    pad=24
    d.rounded_rectangle((x-pad,y-pad,x+tw+pad,y+th+pad),30,fill=(255,255,255,235))
    d.text((x,y),c["text"],font=f,fill=(20,20,20),stroke_width=4,stroke_fill=(255,255,255))

def frame(t):
    im=BG.copy().convert("RGBA")

    # choose a fallback pose
    if t<2.6:
        alex=ALEX_IDLE
    elif t<5.0:
        alex=ALEX_NOTICE
    elif t<7.5:
        alex=ALEX_SHOCK
    elif t<12.5:
        alex=ALEX_IDLE
    else:
        alex=ALEX_ANNOYED

    # seated upper-body approximation
    paste(im,alex,90,780,.80)

    # Props
    if 5.0<=t<7.5:
        paste(im,PHONE,650,880,.48,-5)
        n=N_MEETING.copy()
        n.thumbnail((860,240))
        im.paste(n,(110,400),n)

    if 7.3<=t<12.4:
        wobble=0
        if 10.0<=t<11.0:
            wobble=4*math.sin((t-10.0)*24)
        paste(im,LAPTOP,430,1270,.72,wobble)
        paste(im,COFFEE,785,1265,.60,-wobble)

    if t>=12.4:
        n=N_MANAGER.copy()
        n.thumbnail((860,240))
        im.paste(n,(110,400),n)

    c=caption_for(t)
    if c:
        draw_caption(im,c)

    return np.array(im.convert("RGB"))

if __name__=="__main__":
    out=ROOT/"output"/"short_02_preview.mp4"
    out.parent.mkdir(exist_ok=True)
    clip=VideoClip(frame_function=frame,duration=DURATION)
    clip.write_videofile(str(out),fps=FPS,codec="libx264",audio=False,
                         preset="medium",pixel_format="yuv420p")
    print("DONE:",out)
