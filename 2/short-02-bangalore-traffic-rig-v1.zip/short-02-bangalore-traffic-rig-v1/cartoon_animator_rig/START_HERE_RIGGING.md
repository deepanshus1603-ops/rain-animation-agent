# Alex Sitting Rig V1

This package moves Short #2 beyond full-body PNG swapping.

## What was extracted

### Face
`cartoon_animator_rig/face/`

- neutral / happy / surprised / frustrated / tired heads
- eyes open
- blink
- look left
- look right
- look up
- look down
- mouth closed
- smile
- talking A
- talking O
- surprised
- sad

### Body parts
`cartoon_animator_rig/parts/`

- torso with seatbelt
- upper/lower left arm
- upper/lower right arm
- open hands
- phone-grip hand
- laptop/typing hand
- coffee-grip hand
- hair front/back
- ears
- eyebrows
- nose
- glasses

### Pose references
`cartoon_animator_rig/pose_references/`

Seven seated reference poses:

1. idle
2. look at traffic
3. look at phone
4. work on laptop
5. shocked
6. facepalm
7. look at camera

These pose images are references; the separated parts are what we want to rig.

---

# First Cartoon Animator test

Do NOT animate the full 15 seconds immediately.

Create one 3-second test:

### 0.0 sec
Alex seated neutral.

### 0.5 sec
Blink.

### 1.0 sec
Turn head slightly toward traffic.

### 1.8 sec
Eyes return forward.

### 2.2 sec
Look down toward phone.

### 3.0 sec
Hold.

If this looks smooth, the rig is working.

Then create the other reusable actions.

---

# Suggested pivots

- Head: base of neck
- Upper arms: shoulders
- Forearms: elbows
- Hands: wrists
- Hair: head center / scalp
- Eyes: keep centered inside head
- Eyebrows: independent above each eye

The torso should remain the main seated anchor.

---

# Important limitation

These layers were extracted from a generated asset sheet. They are a very good
starting pack for learning and testing the rig, but some joints may need small
cleanup or overlap painting in Cartoon Animator.

For production quality later, we can regenerate individual limbs at larger
resolution once the rig workflow is proven.
