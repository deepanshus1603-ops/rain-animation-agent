@echo off
".venv\Scripts\python.exe" preview_short_02.py
pause
