# Short #2 — Bangalore Traffic

This ZIP is the complete STARTER package for our second 15-second YouTube Short.

## Story

Alex is a frustrated IT employee stuck in Bangalore traffic.

Final joke:

    Manager: "Are you in office?"
    Alex: "Define office."

## What is included

### Story
- `scene.json`
- exact 15-second timing
- narration
- Alex dialogue
- captions
- action beats

### Current reusable Alex assets
- copied from the final Short #1 project
- used only as fallback preview sprites

### Bangalore traffic starter scene
- `assets/backgrounds/bangalore_traffic_placeholder.png`

This is intentionally a placeholder. Our final version should use a proper illustrated/AI-generated Bangalore traffic scene.

### Props
- phone
- laptop
- coffee cup
- meeting notification
- manager notification

### Cartoon Animator rig prep
Open:

    cartoon_animator_rig/RIG_PLAN.txt

and:

    cartoon_animator_rig/layer_manifest.csv

This tells us exactly which Alex body parts to separate and which movements to build.

### Preview renderer
Run:

    python preview_short_02.py

Output:

    output/short_02_preview.mp4

This is NOT the final animation. It lets us verify story timing before rigging Alex.

---

# New workflow for Short #2

    SCRIPT
      ↓
    illustrated Bangalore traffic background
      ↓
    Cartoon Animator
      ↓
    real Alex head/arm/face movement
      ↓
    transparent animation export
      ↓
    Python compositor
      ↓
    TTS + notifications + traffic + captions + SFX + music
      ↓
    FFmpeg
      ↓
    final Short

## Software

### Cartoon Animator
Used for Alex's real body/face movement.

### Python + Pillow
Scene composition, overlays, props, captions, notifications.

### Edge TTS
Narrator + Alex voice.

### MoviePy
Timeline assembly.

### FFmpeg
Final MP4 encoding.

### ChatGPT
Script, visual planning, rig planning, debugging, and iteration.

---

# First milestone

Do NOT build the whole Short immediately.

First make Alex do only:

1. blink
2. breathe
3. turn head toward traffic
4. look down at phone
5. raise phone
6. frustrated face
7. look at camera

Once those movements work, we plug them into this project.
