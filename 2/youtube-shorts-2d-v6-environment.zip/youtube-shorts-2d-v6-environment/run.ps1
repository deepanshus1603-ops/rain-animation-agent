$ErrorActionPreference = "Stop"
& .\.venv\Scripts\python.exe render_v6_safe.py
