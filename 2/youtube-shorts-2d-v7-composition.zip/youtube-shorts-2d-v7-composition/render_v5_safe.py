from pathlib import Path
import asyncio
import json
import subprocess

from moviepy import VideoClip, AudioFileClip, CompositeAudioClip
from imageio_ffmpeg import get_ffmpeg_exe

import render_v5 as v5

ROOT = Path(__file__).resolve().parent
CFG = json.loads((ROOT / "scene.json").read_text(encoding="utf-8"))
DURATION = float(CFG["duration"])
FPS = int(CFG["fps"])

TEMP_DIR = ROOT / "output" / "_temp_v5"
VIDEO_ONLY = TEMP_DIR / "video_only.mp4"
AUDIO_ONLY = TEMP_DIR / "audio_mix.wav"
FINAL = ROOT / "output" / "short_001_v5.mp4"

def remove_if_exists(path):
    try:
        if path.exists():
            path.unlink()
    except Exception:
        pass

async def ensure_tts():
    try:
        import edge_tts
    except Exception:
        print("WARNING: edge-tts unavailable. Speech will be skipped.")
        return []

    outdir = ROOT / "cache" / "tts"
    outdir.mkdir(parents=True, exist_ok=True)
    tracks = []

    for i, line in enumerate(CFG["dialogue"]):
        out = outdir / f"{i:02d}_{line['speaker']}.mp3"

        if not out.exists():
            voice = CFG["voices"][line["speaker"]]
            rate = "+5%" if line["speaker"] == "narrator" else "+2%"
            print(f"TTS {i+1}/{len(CFG['dialogue'])}: {line['text']}")
            await edge_tts.Communicate(
                line["text"], voice, rate=rate
            ).save(str(out))

        tracks.append((out, float(line["start"])))

    return tracks

def build_audio():
    clips = []

    for p, start in asyncio.run(ensure_tts()):
        try:
            clips.append(AudioFileClip(str(p)).with_start(start))
        except Exception as exc:
            print("Voice warning:", exc)

    sfx = [
        ("footstep_1.wav", 0.50, 0.45),
        ("footstep_2.wav", 0.93, 0.45),
        ("footstep_3.wav", 1.36, 0.45),
        ("footstep_4.wav", 1.79, 0.45),
        ("sting.wav", 7.20, 0.60),
        ("slip.wav", 8.03, 0.90),
        ("whoosh.wav", 8.15, 0.72),
        ("impact.wav", 9.53, 0.98),
    ]

    for filename, start, volume in sfx:
        c = AudioFileClip(str(ROOT / "assets" / "audio" / filename)).with_start(start)
        try:
            c = c.with_volume_scaled(volume)
        except Exception:
            pass
        clips.append(c)

    music = AudioFileClip(str(ROOT / "assets/audio/cartoon_bed.wav")).with_start(0)
    try:
        music = music.with_volume_scaled(0.07)
    except Exception:
        pass
    clips.append(music)

    mix = CompositeAudioClip(clips)
    try:
        mix = mix.with_duration(DURATION)
    except Exception:
        pass

    return mix, clips

def render_video():
    print("\n" + "=" * 60)
    print("PASS 1/3 - VIDEO")
    print("=" * 60)
    remove_if_exists(VIDEO_ONLY)

    clip = VideoClip(frame_function=v5.frame, duration=DURATION)
    clip.write_videofile(
        str(VIDEO_ONLY),
        fps=FPS,
        codec="libx264",
        audio=False,
        preset="medium",
        threads=2,
        ffmpeg_params=["-pix_fmt", "yuv420p"],
    )
    clip.close()

def render_audio():
    print("\n" + "=" * 60)
    print("PASS 2/3 - AUDIO")
    print("=" * 60)
    remove_if_exists(AUDIO_ONLY)

    mix, clips = build_audio()
    mix.write_audiofile(
        str(AUDIO_ONLY),
        fps=44100,
        nbytes=2,
        codec="pcm_s16le",
    )

    try:
        mix.close()
    except Exception:
        pass

    for c in clips:
        try:
            c.close()
        except Exception:
            pass

def mux():
    print("\n" + "=" * 60)
    print("PASS 3/3 - FINAL MP4")
    print("=" * 60)
    remove_if_exists(FINAL)

    ffmpeg = get_ffmpeg_exe()
    result = subprocess.run([
        ffmpeg, "-y",
        "-i", str(VIDEO_ONLY),
        "-i", str(AUDIO_ONLY),
        "-c:v", "copy",
        "-c:a", "aac",
        "-b:a", "192k",
        "-t", str(DURATION),
        "-movflags", "+faststart",
        str(FINAL),
    ])

    if result.returncode != 0:
        raise RuntimeError(f"FFmpeg mux failed: {result.returncode}")

def main():
    (ROOT / "output").mkdir(exist_ok=True)
    TEMP_DIR.mkdir(parents=True, exist_ok=True)

    print("\nV5 FINAL POLISH - SAFE 3-PASS RENDER\n")
    render_video()
    render_audio()
    mux()

    print("\n" + "=" * 60)
    print("SUCCESS")
    print("=" * 60)
    print(FINAL)

if __name__ == "__main__":
    main()
