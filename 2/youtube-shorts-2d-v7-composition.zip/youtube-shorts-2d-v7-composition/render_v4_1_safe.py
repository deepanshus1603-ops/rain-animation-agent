from pathlib import Path
import asyncio
import json
import os
import shutil
import subprocess
import sys

from moviepy import VideoClip, AudioFileClip, CompositeAudioClip
from imageio_ffmpeg import get_ffmpeg_exe

# Reuse all animation/frame logic from the V4 renderer.
import render_v4 as v4

ROOT = Path(__file__).resolve().parent
CFG = json.loads((ROOT / "scene.json").read_text(encoding="utf-8"))
DURATION = float(CFG["duration"])
FPS = int(CFG["fps"])

TEMP_DIR = ROOT / "output" / "_temp_v41"
VIDEO_ONLY = TEMP_DIR / "video_only.mp4"
AUDIO_ONLY = TEMP_DIR / "audio_mix.wav"
FINAL = ROOT / "output" / "short_001_v4_1.mp4"


def remove_if_exists(path: Path):
    try:
        if path.exists():
            path.unlink()
    except Exception:
        pass


async def ensure_tts():
    try:
        import edge_tts
    except Exception:
        print("WARNING: edge-tts is not installed. Rendering without spoken dialogue.")
        return []

    outdir = ROOT / "cache" / "tts"
    outdir.mkdir(parents=True, exist_ok=True)

    tracks = []

    for i, line in enumerate(CFG["dialogue"]):
        out = outdir / f"{i:02d}_{line['speaker']}.mp3"

        if not out.exists():
            voice = CFG["voices"][line["speaker"]]
            rate = "+5%" if line["speaker"] == "narrator" else "+2%"

            print(f"TTS {i+1}/{len(CFG['dialogue'])}: {line['text']}")
            communicate = edge_tts.Communicate(
                line["text"],
                voice,
                rate=rate,
            )
            await communicate.save(str(out))

        tracks.append((out, float(line["start"])))

    return tracks


def build_audio():
    audio_clips = []

    # Dialogue
    for path, start in asyncio.run(ensure_tts()):
        try:
            clip = AudioFileClip(str(path)).with_start(start)
            audio_clips.append(clip)
        except Exception as exc:
            print("Voice warning:", exc)

    # SFX
    sfx = [
        ("footstep_1.wav", 0.50, 0.45),
        ("footstep_2.wav", 0.93, 0.45),
        ("footstep_3.wav", 1.36, 0.45),
        ("footstep_4.wav", 1.79, 0.45),
        ("sting.wav", 7.25, 0.52),
        ("slip.wav", 8.07, 0.88),
        ("whoosh.wav", 8.18, 0.70),
        ("impact.wav", 9.65, 0.95),
    ]

    for filename, start, volume in sfx:
        path = ROOT / "assets" / "audio" / filename
        clip = AudioFileClip(str(path)).with_start(start)
        try:
            clip = clip.with_volume_scaled(volume)
        except Exception:
            pass
        audio_clips.append(clip)

    # Music
    music_path = ROOT / "assets" / "audio" / "cartoon_bed.wav"
    music = AudioFileClip(str(music_path)).with_start(0)

    try:
        music = music.with_volume_scaled(0.075)
    except Exception:
        pass

    audio_clips.append(music)

    mix = CompositeAudioClip(audio_clips)

    try:
        mix = mix.with_duration(DURATION)
    except Exception:
        pass

    return mix, audio_clips


def render_video_only():
    print("")
    print("=" * 60)
    print("PASS 1/3 - Rendering VIDEO ONLY")
    print("=" * 60)

    remove_if_exists(VIDEO_ONLY)

    clip = VideoClip(
        frame_function=v4.frame,
        duration=DURATION,
    )

    # Keep this pass deliberately simple.
    # No audio input is attached to the FFmpeg video-writing process.
    clip.write_videofile(
        str(VIDEO_ONLY),
        fps=FPS,
        codec="libx264",
        audio=False,
        preset="medium",
        threads=2,
        ffmpeg_params=["-pix_fmt", "yuv420p"],
    )

    clip.close()

    if not VIDEO_ONLY.exists() or VIDEO_ONLY.stat().st_size == 0:
        raise RuntimeError("Video-only pass did not produce a valid file.")


def render_audio_only():
    print("")
    print("=" * 60)
    print("PASS 2/3 - Rendering AUDIO ONLY")
    print("=" * 60)

    remove_if_exists(AUDIO_ONLY)

    mix, source_clips = build_audio()

    mix.write_audiofile(
        str(AUDIO_ONLY),
        fps=44100,
        nbytes=2,
        codec="pcm_s16le",
    )

    try:
        mix.close()
    except Exception:
        pass

    for c in source_clips:
        try:
            c.close()
        except Exception:
            pass

    if not AUDIO_ONLY.exists() or AUDIO_ONLY.stat().st_size == 0:
        raise RuntimeError("Audio-only pass did not produce a valid file.")


def mux():
    print("")
    print("=" * 60)
    print("PASS 3/3 - Combining VIDEO + AUDIO")
    print("=" * 60)

    remove_if_exists(FINAL)

    ffmpeg = get_ffmpeg_exe()

    cmd = [
        ffmpeg,
        "-y",
        "-i", str(VIDEO_ONLY),
        "-i", str(AUDIO_ONLY),
        "-c:v", "copy",
        "-c:a", "aac",
        "-b:a", "192k",
        "-t", str(DURATION),
        "-movflags", "+faststart",
        str(FINAL),
    ]

    print("Using FFmpeg:")
    print(ffmpeg)

    result = subprocess.run(cmd)

    if result.returncode != 0:
        raise RuntimeError(
            f"Final FFmpeg mux failed with exit code {result.returncode}."
        )

    if not FINAL.exists() or FINAL.stat().st_size == 0:
        raise RuntimeError("Final MP4 was not created.")


def main():
    (ROOT / "output").mkdir(exist_ok=True)
    TEMP_DIR.mkdir(parents=True, exist_ok=True)

    print("")
    print("V4.1 SAFE RENDER")
    print("MoviePy renders picture and sound separately.")
    print("FFmpeg only combines finished files at the end.")
    print("")

    render_video_only()
    render_audio_only()
    mux()

    print("")
    print("=" * 60)
    print("SUCCESS")
    print("=" * 60)
    print(FINAL)
    print("")
    print("You can upload short_001_v4_1.mp4 to ChatGPT for review.")


if __name__ == "__main__":
    main()
