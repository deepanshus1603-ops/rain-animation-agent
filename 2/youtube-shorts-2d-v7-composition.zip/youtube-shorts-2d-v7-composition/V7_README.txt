YOUTUBE SHORTS 2D - V7 COMPOSITION POLISH
=========================================

What changed from V6
--------------------
- Alex moved farther onto the left sidewalk
- Alex is about 12% larger
- both bananas are larger
- soft contact shadow added under Alex
- slip/fall shifted left and kept away from bus/road detail
- final annoyed reaction raised slightly
- same illustrated street environment
- same story / narration / captions / SFX / music
- same stable 3-pass Windows renderer

Run
---
    .\setup.ps1
    .\run.ps1

or double-click:
    run_v7.bat

Final output
------------
    output\short_001_v7_composition.mp4

After this version, the banana Short should be considered frozen.
The next useful milestone is Short #2 using a new story/background with the same engine.
