from pathlib import Path
import asyncio, json, subprocess
from moviepy import VideoClip, AudioFileClip, CompositeAudioClip
from imageio_ffmpeg import get_ffmpeg_exe
import render_v6 as v6

ROOT=Path(__file__).resolve().parent
CFG=json.loads((ROOT/"scene.json").read_text(encoding="utf-8"))
DURATION=float(CFG["duration"])
FPS=int(CFG["fps"])

TEMP=ROOT/"output"/"_temp_v6"
VIDEO=TEMP/"video_only.mp4"
AUDIO=TEMP/"audio_mix.wav"
FINAL=ROOT/"output"/"short_001_v6_environment.mp4"

def rm(p):
    try:
        if p.exists(): p.unlink()
    except Exception:
        pass

async def ensure_tts():
    try:
        import edge_tts
    except Exception:
        print("WARNING: edge-tts unavailable; speech will be skipped.")
        return []

    outdir=ROOT/"cache"/"tts"
    outdir.mkdir(parents=True,exist_ok=True)
    tracks=[]

    for i,line in enumerate(CFG["dialogue"]):
        p=outdir/f"{i:02d}_{line['speaker']}.mp3"
        if not p.exists():
            voice=CFG["voices"][line["speaker"]]
            rate="+5%" if line["speaker"]=="narrator" else "+2%"
            print(f"TTS {i+1}/{len(CFG['dialogue'])}: {line['text']}")
            await edge_tts.Communicate(
                line["text"],voice,rate=rate
            ).save(str(p))
        tracks.append((p,float(line["start"])))
    return tracks

def audio_mix():
    clips=[]

    for p,start in asyncio.run(ensure_tts()):
        clips.append(AudioFileClip(str(p)).with_start(start))

    sfx=[
        ("footstep_1.wav",.50,.45),
        ("footstep_2.wav",.93,.45),
        ("footstep_3.wav",1.36,.45),
        ("footstep_4.wav",1.79,.45),
        ("sting.wav",7.20,.60),
        ("slip.wav",8.03,.90),
        ("whoosh.wav",8.15,.72),
        ("impact.wav",9.53,.98),
    ]

    for f,start,vol in sfx:
        c=AudioFileClip(str(ROOT/"assets"/"audio"/f)).with_start(start)
        try: c=c.with_volume_scaled(vol)
        except Exception: pass
        clips.append(c)

    music=AudioFileClip(str(ROOT/"assets"/"audio"/"cartoon_bed.wav")).with_start(0)
    try: music=music.with_volume_scaled(.07)
    except Exception: pass
    clips.append(music)

    mix=CompositeAudioClip(clips)
    try: mix=mix.with_duration(DURATION)
    except Exception: pass

    return mix,clips

def pass1():
    print("\nPASS 1/3 - VIDEO")
    rm(VIDEO)
    clip=VideoClip(frame_function=v6.frame,duration=DURATION)
    clip.write_videofile(
        str(VIDEO),fps=FPS,codec="libx264",audio=False,
        preset="medium",threads=2,
        ffmpeg_params=["-pix_fmt","yuv420p"]
    )
    clip.close()

def pass2():
    print("\nPASS 2/3 - AUDIO")
    rm(AUDIO)
    mix,clips=audio_mix()
    mix.write_audiofile(str(AUDIO),fps=44100,nbytes=2,codec="pcm_s16le")
    try: mix.close()
    except Exception: pass
    for c in clips:
        try: c.close()
        except Exception: pass

def pass3():
    print("\nPASS 3/3 - FINAL MP4")
    rm(FINAL)
    ffmpeg=get_ffmpeg_exe()
    result=subprocess.run([
        ffmpeg,"-y",
        "-i",str(VIDEO),
        "-i",str(AUDIO),
        "-c:v","copy",
        "-c:a","aac",
        "-b:a","192k",
        "-t",str(DURATION),
        "-movflags","+faststart",
        str(FINAL)
    ])
    if result.returncode!=0:
        raise RuntimeError(f"FFmpeg mux failed: {result.returncode}")

def main():
    (ROOT/"output").mkdir(exist_ok=True)
    TEMP.mkdir(parents=True,exist_ok=True)

    print("\nV6 ILLUSTRATED ENVIRONMENT - SAFE 3-PASS RENDER")
    pass1()
    pass2()
    pass3()

    print("\nSUCCESS")
    print(FINAL)

if __name__=="__main__":
    main()
