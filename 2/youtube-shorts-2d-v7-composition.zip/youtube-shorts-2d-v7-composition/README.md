# YouTube Shorts 2D — V4 Illustrated

V4 upgrades the visual quality by using transparent sprites extracted from the approved Alex character reference sheet instead of the programmatically drawn placeholder character.

## What changed in V4

- illustrated Alex sprite pack based on the approved design
- normalized transparent 800x820 sprite canvases
- cleaner background with no table in the action area
- larger first and second banana props
- clearer second-banana reveal
- fall kept near the middle of the frame
- V3 narration, captions, sound effects and music retained
- 1080x1920 vertical output
- 15 seconds
- 30 FPS

## Sprite pack

Inside:

    assets\character\

you will find:

    alex_idle.png
    alex_walk_1.png
    alex_walk_2.png
    alex_notice.png
    alex_confident.png
    alex_step.png
    alex_shocked.png
    alex_slip.png
    alex_falling.png
    alex_annoyed.png

There is also:

    sprite_pack_contact_sheet.jpg

for a quick visual review.

## Run

First time:

    .\setup.ps1

Then:

    .\run.ps1

If PowerShell blocks scripts:

    python -m venv .venv
    .\.venv\Scripts\python.exe -m pip install -r requirements.txt
    .\.venv\Scripts\python.exe render_v4.py

Output:

    output\short_001_v4.mp4

The first full render needs internet access for Edge TTS voice generation.

---

# Tools used

## Python
The controller/orchestrator. It reads the story timing, moves sprites, swaps poses, schedules captions and combines everything into a final video.

## Pillow
Used for 2D image processing:
- transparent PNG sprites
- extracting Alex from the character sheet
- resizing and rotating sprites
- drawing backgrounds
- drawing captions and comic effects

## MoviePy
Builds the actual 15-second timeline:
- one frame at a time
- adds audio clips
- mixes narration, SFX and music
- sends the completed timeline to the video encoder

## FFmpeg / imageio-ffmpeg
The video encoder underneath MoviePy. It produces the final MP4 using:
- H.264 video
- AAC audio
- 1080x1920 resolution
- 30 FPS

You do not need to manually operate FFmpeg for this project.

## Edge TTS
Generates the spoken voices:
- narrator
- Alex

Dialogue lives in `scene.json`.

## JSON
`scene.json` is the story/configuration file. This is important for the future because we can make new Shorts mainly by changing:
- dialogue
- captions
- timings
- characters / scenes

without rewriting the entire renderer.

## PowerShell
Only used as a convenient Windows launcher:
- `setup.ps1`
- `run.ps1`

It is not part of the animation engine itself.

## ChatGPT
Used for:
- story ideas
- script writing
- timing
- animation planning
- debugging
- reviewing rendered videos
- generating/upgrading project ZIPs

## Character image generation
The approved Alex reference design was generated as the visual source of truth. V4 extracts and reuses poses from that approved artwork so the rendered character looks much closer to the original concept.

---

# Long-term target

We are moving toward:

    idea
      -> script
      -> scene.json
      -> sprites/backgrounds
      -> automatic voice
      -> automatic animation
      -> captions/SFX/music
      -> MP4

Eventually a new 15-second Short should require very little manual animation work.
