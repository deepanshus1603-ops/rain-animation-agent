@echo off
".venv\Scripts\python.exe" render_v6_safe.py
pause
