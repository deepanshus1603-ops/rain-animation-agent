@echo off
if not exist ".venv\Scripts\python.exe" (
    echo Virtual environment not found.
    echo Run setup.ps1 first, or create the environment manually.
    pause
    exit /b 1
)

".venv\Scripts\python.exe" render_v4_1_safe.py
pause
