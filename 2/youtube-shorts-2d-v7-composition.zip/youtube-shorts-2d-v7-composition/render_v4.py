from pathlib import Path
import json, math, asyncio, os
import numpy as np
from PIL import Image, ImageDraw, ImageFont

ROOT=Path(__file__).resolve().parent
CFG=json.loads((ROOT/"scene.json").read_text(encoding="utf-8"))

W,H=CFG["width"],CFG["height"]
DURATION,FPS=CFG["duration"],CFG["fps"]

BG=Image.open(ROOT/"assets/backgrounds/room_v4.png").convert("RGB").resize((W,H))
BANANA=Image.open(ROOT/"assets/props/banana.png").convert("RGBA")
BANANA_FLAT=Image.open(ROOT/"assets/props/banana_flat.png").convert("RGBA")

SPRITES={}
for name in ["idle","walk_1","walk_2","notice","confident","step","shocked","slip","falling","annoyed"]:
    SPRITES[name]=Image.open(ROOT/"assets/character"/f"alex_{name}.png").convert("RGBA")

def ease(x):
    x=max(0,min(1,x))
    return x*x*(3-2*x)

def ease_out_back(x):
    x=max(0,min(1,x))
    c1=1.70158
    c3=c1+1
    return 1+c3*(x-1)**3+c1*(x-1)**2

def paste_center(base,sprite,cx,top,scale=1.0,angle=0):
    s=sprite
    if scale!=1:
        s=s.resize((max(1,int(s.width*scale)),max(1,int(s.height*scale))),Image.Resampling.LANCZOS)
    if angle:
        s=s.rotate(angle,resample=Image.Resampling.BICUBIC,expand=True)
    x=int(cx-s.width/2)
    y=int(top)
    base.paste(s,(x,y),s)

def paste_prop(base,sprite,cx,y,scale=1.0,angle=0):
    s=sprite.resize((int(sprite.width*scale),int(sprite.height*scale)),Image.Resampling.LANCZOS)
    if angle:
        s=s.rotate(angle,resample=Image.Resampling.BICUBIC,expand=True)
    base.paste(s,(int(cx-s.width/2),int(y)),s)

def font(size,bold=True):
    candidates=[
        "C:/Windows/Fonts/arialbd.ttf" if bold else "C:/Windows/Fonts/arial.ttf",
        "C:/Windows/Fonts/segoeuib.ttf" if bold else "C:/Windows/Fonts/segoeui.ttf",
    ]
    for p in candidates:
        if os.path.exists(p):
            return ImageFont.truetype(p,size)
    return ImageFont.load_default()

def get_caption(t):
    for c in CFG["captions"]:
        if c["start"]<=t<=c["end"]:
            return c
    return None

def draw_caption(im,c,t):
    dr=ImageDraw.Draw(im)
    f=font(86 if len(c["text"])<16 else 72,True)
    box=dr.textbbox((0,0),c["text"],font=f,stroke_width=4)
    tw=box[2]-box[0]
    th=box[3]-box[1]
    age=max(0,t-c["start"])
    pop=min(1,age/.12)
    y=int(185-(1-pop)*24)
    x=(W-tw)//2
    pad=28
    dr.rounded_rectangle((x-pad,y-pad,x+tw+pad,y+th+pad),radius=28,fill=(255,255,255,238))
    dr.text((x,y),c["text"],font=f,fill=(24,24,24,255),
            stroke_width=4,stroke_fill=(255,255,255,255))

def reveal_lines(im,cx,cy,p):
    dr=ImageDraw.Draw(im)
    for a in np.linspace(-2.7,-.45,7):
        r1=52
        r2=95+35*p
        dr.line((
            cx+math.cos(a)*r1,cy+math.sin(a)*r1,
            cx+math.cos(a)*r2,cy+math.sin(a)*r2
        ),fill=(244,181,27,255),width=10)

def impact_star(im,t):
    if not (9.55<=t<=10.05):
        return
    p=(t-9.55)/.50
    r2=140*(1-p)
    if r2<35:
        return
    cx,cy=650,1430
    pts=[]
    for i in range(16):
        a=2*math.pi*i/16
        r=r2 if i%2==0 else 35
        pts.append((cx+math.cos(a)*r,cy+math.sin(a)*r))
    ImageDraw.Draw(im).polygon(pts,fill=(255,217,75,220),outline=(88,56,30,255))

def frame(t):
    im=BG.copy().convert("RGBA")

    # First banana appears when Alex notices it.
    if t>=2.15:
        paste_prop(im,BANANA,555,1328,.62,-8)

    # Second banana reveal — larger and visually separated.
    if 7.25<=t<8.05:
        p=ease((t-7.25)/.80)
        paste_prop(im,BANANA,805,1325,.68,10)
        reveal_lines(im,805,1370,p)
    elif t>=8.05:
        paste_prop(im,BANANA_FLAT if t>=8.25 else BANANA,805,1325,.68,8)

    # Character timeline.
    if t<2.10:
        p=ease(t/2.10)
        cx=-220+p*650
        top=545+math.sin(t*13)*3
        pose="walk_1" if int(t*5)%2==0 else "walk_2"
        angle=0

    elif t<3.25:
        p=ease((t-2.10)/1.15)
        cx=430+p*70
        top=545
        pose="notice"
        angle=0

    elif t<4.20:
        cx=500;top=545;pose="notice";angle=0

    elif t<5.40:
        cx=500;top=545;pose="confident";angle=0

    elif t<6.70:
        p=ease((t-5.40)/1.30)
        cx=500+p*230
        top=545-math.sin(p*math.pi)*20
        pose="step"
        angle=-2*math.sin(p*math.pi)

    elif t<7.25:
        cx=730;top=545;pose="idle";angle=0

    elif t<7.75:
        cx=730;top=545;pose="shocked";angle=0

    elif t<8.10:
        p=ease((t-7.75)/.35)
        cx=730+p*45
        top=545
        pose="step"
        angle=0

    elif t<9.15:
        p=ease((t-8.10)/1.05)
        cx=775-p*120
        top=545+p*95
        pose="slip"
        angle=55*p

    elif t<9.80:
        p=ease((t-9.15)/.65)
        cx=655
        top=640+p*540
        pose="falling"
        angle=55+22*p

    elif t<12.00:
        # Empty-frame comedy pause.
        cx=540;top=2200;pose="idle";angle=0

    else:
        p=ease_out_back((t-12.0)/1.0)
        p=max(0,min(1.08,p))
        cx=540
        top=1510-p*555
        pose="annoyed"
        angle=0

    paste_center(im,SPRITES[pose],cx,top,.84,angle)

    impact_star(im,t)

    c=get_caption(t)
    if c:
        draw_caption(im,c,t)

    return np.array(im.convert("RGB"))

async def ensure_tts():
    try:
        import edge_tts
    except Exception:
        print("edge-tts not installed; rendering without speech.")
        return []

    outdir=ROOT/"cache"/"tts"
    outdir.mkdir(parents=True,exist_ok=True)
    tracks=[]

    for i,line in enumerate(CFG["dialogue"]):
        p=outdir/f"{i:02d}_{line['speaker']}.mp3"
        if not p.exists():
            voice=CFG["voices"][line["speaker"]]
            rate="+5%" if line["speaker"]=="narrator" else "+2%"
            await edge_tts.Communicate(line["text"],voice,rate=rate).save(str(p))
        tracks.append((p,float(line["start"])))

    return tracks

def main():
    from moviepy import VideoClip, AudioFileClip, CompositeAudioClip

    audio=[]

    # speech
    for p,start in asyncio.run(ensure_tts()):
        try:
            audio.append(AudioFileClip(str(p)).with_start(start))
        except Exception as e:
            print("Voice warning:",e)

    # sound effects
    sfx=[
        ("footstep_1.wav",.50,.45),
        ("footstep_2.wav",.93,.45),
        ("footstep_3.wav",1.36,.45),
        ("footstep_4.wav",1.79,.45),
        ("sting.wav",7.25,.52),
        ("slip.wav",8.07,.88),
        ("whoosh.wav",8.18,.70),
        ("impact.wav",9.65,.95),
    ]

    for fname,start,vol in sfx:
        a=AudioFileClip(str(ROOT/"assets"/"audio"/fname)).with_start(start)
        try:
            a=a.with_volume_scaled(vol)
        except Exception:
            pass
        audio.append(a)

    # background music
    music=AudioFileClip(str(ROOT/"assets"/"audio"/"cartoon_bed.wav")).with_start(0)
    try:
        music=music.with_volume_scaled(.075)
    except Exception:
        pass
    audio.append(music)

    clip=VideoClip(frame_function=frame,duration=DURATION)
    clip=clip.with_audio(CompositeAudioClip(audio))

    out=ROOT/"output"/"short_001_v4.mp4"
    clip.write_videofile(
        str(out),
        fps=FPS,
        codec="libx264",
        audio_codec="aac",
        preset="medium",
        pixel_format="yuv420p",
        threads=4
    )
    print("\nDONE:",out)

if __name__=="__main__":
    main()
