V4.1 SAFE RENDER FIX
====================

Why this patch exists
---------------------
V4 failed at frame 0 with:

    OSError: [Errno 22] Invalid argument

while MoviePy was piping video frames into FFmpeg.

The animation frames themselves are valid. V4.1 avoids the combined
MoviePy video+audio FFmpeg writer.

New rendering flow
------------------
PASS 1: MoviePy renders video only
PASS 2: MoviePy renders the mixed audio to WAV
PASS 3: FFmpeg muxes the finished MP4 + WAV

This is easier to debug and substantially more robust on Windows.

Run
---
    .\run.ps1

or double click:

    run_v4_1.bat

Final output
------------
    output\short_001_v4_1.mp4

Temporary files
---------------
    output\_temp_v41\video_only.mp4
    output\_temp_v41\audio_mix.wav

If something still fails, the terminal will now clearly show whether
PASS 1, PASS 2, or PASS 3 is the problem.
