YOUTUBE SHORTS 2D - V6 ILLUSTRATED ENVIRONMENT
==============================================

What changed
------------
V6 keeps the illustrated Alex character but replaces the simple generated
room/floor with the new environment artwork.

The main Short now uses:
- illustrated green trees
- blue sky/clouds
- city skyline
- street lights
- sidewalk
- proper road markings
- bus / city depth

Alex and both banana peels are staged on the LEFT SIDEWALK so they do not
look like they are standing in the traffic lane.

Environment assets included
---------------------------
assets\environment\environment_asset_sheet.png

assets\backgrounds\street_vertical.png
assets\backgrounds\park_scene.png
assets\backgrounds\office_scene.png
assets\backgrounds\cafe_scene.png

The full environment sheet is intentionally kept in the project so we can
keep extracting reusable trees, benches, roads, lamps, bushes and other
objects for future Shorts.

Run
---
First time:

    .\setup.ps1

Then:

    .\run.ps1

or double-click:

    run_v6.bat

Final video
-----------
    output\short_001_v6_environment.mp4

Rendering still uses the stable 3-pass Windows pipeline:
1. video
2. audio
3. FFmpeg combines them

Future plan
-----------
For new Shorts, use the same approach:
- illustrated character assets
- illustrated background assets
- separate illustrated props
- Python only handles motion/timing
- TTS handles voices
- FFmpeg creates the final MP4
