$ErrorActionPreference = "Stop"
& .\.venv\Scripts\python.exe render_v7_safe.py
