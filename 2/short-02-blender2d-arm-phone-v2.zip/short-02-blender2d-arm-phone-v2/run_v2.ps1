$ErrorActionPreference = "Stop"
$project = Split-Path -Parent $MyInvocation.MyCommand.Path
$script = Join-Path $project "scripts\build_and_render_v2.py"
$outputDir = Join-Path $project "output"
$blendOut = Join-Path $outputDir "short02_blender2d_arm_phone_v2.blend"
$videoOut = Join-Path $outputDir "short02_blender2d_arm_phone_v2.mp4"

$blender = $null
$cmd = Get-Command blender -ErrorAction SilentlyContinue
if ($cmd) { $blender = $cmd.Source }
if (-not $blender) {
    $known = @(
        "C:\Program Files\Blender Foundation\Blender 5.2\blender.exe",
        "C:\Program Files\Blender Foundation\Blender 5.1\blender.exe",
        "C:\Program Files\Blender Foundation\Blender 5.0\blender.exe",
        "C:\Program Files\Blender Foundation\Blender 4.5\blender.exe"
    )
    foreach ($candidate in $known) {
        if (Test-Path $candidate) { $blender = $candidate; break }
    }
}
if (-not $blender -and (Test-Path "C:\Program Files\Blender Foundation")) {
    $found = Get-ChildItem "C:\Program Files\Blender Foundation" -Filter blender.exe -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($found) { $blender = $found.FullName }
}
if (-not $blender) {
    Write-Host "FAILED: Blender executable not found." -ForegroundColor Red
    exit 1
}

Write-Host "Using Blender: $blender" -ForegroundColor Cyan
Write-Host "Building 5-second articulated arm + phone proof..." -ForegroundColor Cyan
New-Item -ItemType Directory -Force -Path $outputDir | Out-Null
if (Test-Path $blendOut) { Remove-Item $blendOut -Force }
if (Test-Path $videoOut) { Remove-Item $videoOut -Force }

& $blender --background --python $script
if ($LASTEXITCODE -ne 0) {
    Write-Host "FAILED: Blender returned exit code $LASTEXITCODE." -ForegroundColor Red
    exit $LASTEXITCODE
}
if (-not (Test-Path $blendOut) -or (Get-Item $blendOut).Length -le 0) {
    Write-Host "FAILED: valid .blend file was not created." -ForegroundColor Red
    exit 2
}
if (-not (Test-Path $videoOut) -or (Get-Item $videoOut).Length -le 0) {
    Write-Host "FAILED: valid MP4 file was not created." -ForegroundColor Red
    exit 3
}
Write-Host "" 
Write-Host "SUCCESS" -ForegroundColor Green
Write-Host "Blend: output\short02_blender2d_arm_phone_v2.blend"
Write-Host "Video: output\short02_blender2d_arm_phone_v2.mp4"
Write-Host ("Video size: {0:N2} MB" -f ((Get-Item $videoOut).Length / 1MB))
