@echo off
powershell -ExecutionPolicy Bypass -File "%~dp0run_v2.ps1"
pause
