import bpy
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / 'assets'
OUTPUT = ROOT / 'output'
OUTPUT.mkdir(parents=True, exist_ok=True)

# ------------------------------------------------------------
# Short #2 - Blender 2D Proof V2: articulated arm + phone raise
# Blender 5.2.x target, 5 seconds / 150 frames / 30 FPS
# ------------------------------------------------------------

def clear_scene():
    bpy.ops.object.select_all(action='SELECT')
    bpy.ops.object.delete(use_global=False)


def make_image_material(name, image_path):
    img = bpy.data.images.load(str(image_path), check_existing=True)
    mat = bpy.data.materials.new(name=name)
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()
    out = nodes.new('ShaderNodeOutputMaterial')
    transparent = nodes.new('ShaderNodeBsdfTransparent')
    emission = nodes.new('ShaderNodeEmission')
    tex = nodes.new('ShaderNodeTexImage')
    mix = nodes.new('ShaderNodeMixShader')
    tex.image = img
    tex.interpolation = 'Linear'
    emission.inputs['Strength'].default_value = 1.0
    links.new(tex.outputs['Color'], emission.inputs['Color'])
    links.new(tex.outputs['Alpha'], mix.inputs[0])
    links.new(transparent.outputs[0], mix.inputs[1])
    links.new(emission.outputs[0], mix.inputs[2])
    links.new(mix.outputs[0], out.inputs['Surface'])
    try:
        mat.surface_render_method = 'DITHERED'
    except Exception:
        try:
            mat.blend_method = 'BLEND'
        except Exception:
            pass
    return mat, img


def make_plane(name, image_path, width, parent=None, local_location=(0,0,0)):
    mat, img = make_image_material(name + '_MAT', image_path)
    height = width * img.size[1] / img.size[0]
    verts=[(-width/2,-height/2,0),(width/2,-height/2,0),(width/2,height/2,0),(-width/2,height/2,0)]
    mesh=bpy.data.meshes.new(name+'_MESH')
    mesh.from_pydata(verts,[],[(0,1,2,3)])
    mesh.update()
    obj=bpy.data.objects.new(name,mesh)
    bpy.context.collection.objects.link(obj)
    obj.data.materials.append(mat)
    obj.location=local_location
    if parent:
        obj.parent=parent
    uv=mesh.uv_layers.new(name='UVMap')
    coords=[(0,0),(1,0),(1,1),(0,1)]
    for poly in mesh.polygons:
        for li in poly.loop_indices:
            vi=mesh.loops[li].vertex_index
            uv.data[li].uv=coords[vi]
    return obj,height


def make_fixed_plane(name,image_path,width,height,z=-5):
    mat,_=make_image_material(name+'_MAT',image_path)
    verts=[(-width/2,-height/2,0),(width/2,-height/2,0),(width/2,height/2,0),(-width/2,height/2,0)]
    mesh=bpy.data.meshes.new(name+'_MESH')
    mesh.from_pydata(verts,[],[(0,1,2,3)])
    mesh.update()
    obj=bpy.data.objects.new(name,mesh)
    bpy.context.collection.objects.link(obj)
    obj.data.materials.append(mat)
    obj.location=(0,0,z)
    uv=mesh.uv_layers.new(name='UVMap')
    coords=[(0,0),(1,0),(1,1),(0,1)]
    for poly in mesh.polygons:
        for li in poly.loop_indices:
            vi=mesh.loops[li].vertex_index
            uv.data[li].uv=coords[vi]
    return obj


def empty(name,location=(0,0,0),parent=None,size=.28):
    obj=bpy.data.objects.new(name,None)
    bpy.context.collection.objects.link(obj)
    obj.empty_display_type='PLAIN_AXES'
    obj.empty_display_size=size
    obj.location=location
    if parent:
        obj.parent=parent
    return obj


def key(obj,frame,location=None,rotation_z=None,scale=None):
    if location is not None:
        obj.location=location
        obj.keyframe_insert('location',frame=frame)
    if rotation_z is not None:
        obj.rotation_euler[2]=math.radians(rotation_z)
        obj.keyframe_insert('rotation_euler',index=2,frame=frame)
    if scale is not None:
        obj.scale=scale
        obj.keyframe_insert('scale',frame=frame)


def key_visibility(obj,frame,visible):
    obj.hide_render=not visible
    obj.hide_viewport=not visible
    obj.keyframe_insert('hide_render',frame=frame)
    obj.keyframe_insert('hide_viewport',frame=frame)


def set_interpolation(obj,mode='BEZIER',paths=None):
    if not obj.animation_data or not obj.animation_data.action:
        return
    try:
        curves=obj.animation_data.action.fcurves
    except Exception:
        return
    for fc in curves:
        if paths is not None and fc.data_path not in paths:
            continue
        for kp in fc.keyframe_points:
            kp.interpolation=mode


def enum_values(obj,prop_name):
    try:
        return [i.identifier for i in obj.bl_rna.properties[prop_name].enum_items]
    except Exception:
        return []


def set_first_supported(obj,prop_name,choices):
    available=enum_values(obj,prop_name)
    for c in choices:
        if not available or c in available:
            try:
                setattr(obj,prop_name,c)
                print(prop_name+':',c)
                return c
            except Exception:
                pass
    raise RuntimeError(f'Unsupported {prop_name}; available={available}')


clear_scene()
scene=bpy.context.scene
print('Blender version:',bpy.app.version_string)
scene.frame_start=1
scene.frame_end=150
scene.render.fps=30
try:
    scene.render.engine='BLENDER_EEVEE'
except TypeError:
    try:
        scene.render.engine='BLENDER_EEVEE_NEXT'
    except TypeError:
        scene.render.engine='BLENDER_WORKBENCH'
scene.render.resolution_x=1080
scene.render.resolution_y=1920
scene.render.resolution_percentage=50
scene.render.film_transparent=False
scene.world.color=(0.02,0.025,0.035)

image_settings=scene.render.image_settings
if hasattr(image_settings,'media_type'):
    image_settings.media_type='VIDEO'
else:
    image_settings.file_format='FFMPEG'
set_first_supported(scene.render.ffmpeg,'format',['MPEG4','MATROSKA'])
set_first_supported(scene.render.ffmpeg,'codec',['H264','MPEG4'])
try:
    if 'MEDIUM' in enum_values(scene.render.ffmpeg,'constant_rate_factor'):
        scene.render.ffmpeg.constant_rate_factor='MEDIUM'
except Exception:
    pass
scene.render.filepath=str(OUTPUT/'short02_blender2d_arm_phone_v2.mp4')

cam_data=bpy.data.cameras.new('Camera')
cam=bpy.data.objects.new('Camera',cam_data)
bpy.context.collection.objects.link(cam)
cam.location=(0,0,20)
cam.rotation_euler=(0,0,0)
cam_data.type='ORTHO'
cam_data.ortho_scale=19.2
scene.camera=cam

# Full portrait background; no black bars.
make_fixed_plane('CAB_BG',ASSETS/'cab_background_portrait.png',10.8,19.2,-5)

# Character hierarchy.
root=empty('ALEX_ROOT',location=(-0.10,-2.55,0),size=.45)
torso_ctrl=empty('TORSO_CTRL',location=(0,0,0),parent=root,size=.35)
torso,_=make_plane('TORSO',ASSETS/'torso_seatbelt.png',4.75,parent=torso_ctrl,local_location=(0,-.30,0.0))

head_ctrl=empty('HEAD_CTRL',location=(0,2.50,.55),parent=torso_ctrl,size=.28)
head_neutral,_=make_plane('HEAD_NEUTRAL',ASSETS/'head_neutral.png',3.45,parent=head_ctrl,local_location=(0,1.00,.30))
head_blink,_=make_plane('HEAD_BLINK',ASSETS/'head_blink.png',3.45,parent=head_ctrl,local_location=(0,1.00,.33))
head_surprised,_=make_plane('HEAD_SURPRISED',ASSETS/'head_surprised.png',3.45,parent=head_ctrl,local_location=(0,1.00,.36))

# Articulated phone arm (viewer's right / Alex's left).
arm_root=empty('PHONE_ARM_ROOT',location=(1.58,.36,.16),parent=torso_ctrl,size=.24)
upper_arm,_=make_plane('UPPER_ARM_PHONE',ASSETS/'upper_arm_phone.png',1.02,parent=arm_root,local_location=(0,-.72,.02))
elbow_ctrl=empty('ELBOW_CTRL',location=(0,-1.42,.05),parent=arm_root,size=.22)
lower_arm,_=make_plane('LOWER_ARM_PHONE',ASSETS/'lower_arm_phone.png',1.45,parent=elbow_ctrl,local_location=(.34,-.42,.03))
wrist_ctrl=empty('WRIST_PHONE_CTRL',location=(.86,-.82,.05),parent=elbow_ctrl,size=.20)
hand_phone,_=make_plane('HAND_PHONE',ASSETS/'hand_phone.png',1.82,parent=wrist_ctrl,local_location=(.10,-.34,.05))
phone_notice,_=make_plane('PHONE_NOTICE',ASSETS/'phone_notice.png',.88,parent=wrist_ctrl,local_location=(.22,-.20,.08))

# Animation helpers represent reusable code-driven actions.
def blink(frame):
    key_visibility(head_neutral,frame-2,True)
    key_visibility(head_blink,frame-2,False)
    key_visibility(head_neutral,frame,False)
    key_visibility(head_blink,frame,True)
    key_visibility(head_neutral,frame+2,True)
    key_visibility(head_blink,frame+2,False)


def raise_phone(start,end):
    # Rest pose.
    key(arm_root,start,location=(1.58,.36,.16),rotation_z=4)
    key(elbow_ctrl,start,rotation_z=-8)
    key(wrist_ctrl,start,rotation_z=-5,scale=(.94,.94,1))
    # Anticipation.
    mid=start+int((end-start)*.42)
    key(arm_root,mid,location=(1.48,.42,.16),rotation_z=-12)
    key(elbow_ctrl,mid,rotation_z=24)
    key(wrist_ctrl,mid,rotation_z=-12,scale=(.98,.98,1))
    # Phone near face.
    key(arm_root,end,location=(1.30,.56,.16),rotation_z=-28)
    key(elbow_ctrl,end,rotation_z=63)
    key(wrist_ctrl,end,rotation_z=-22,scale=(1.04,1.04,1))

# Breathing, slightly stronger than V1.
key(torso_ctrl,1,location=(0,0,0),scale=(1,1,1))
key(torso_ctrl,24,location=(0,.035,0),scale=(1.010,1.024,1))
key(torso_ctrl,48,location=(0,0,0),scale=(1,1,1))
key(torso_ctrl,72,location=(0,.035,0),scale=(1.010,1.024,1))
key(torso_ctrl,96,location=(0,0,0),scale=(1,1,1))
key(torso_ctrl,120,location=(0,.035,0),scale=(1.010,1.024,1))
key(torso_ctrl,150,location=(0,0,0),scale=(1,1,1))

# Head timeline.
key(head_ctrl,1,location=(0,2.50,.55),rotation_z=0,scale=(1,1,1))
blink(15)
key(head_ctrl,30,location=(-.18,2.50,.55),rotation_z=-5.5,scale=(.93,1,1))
key(head_ctrl,42,location=(-.18,2.50,.55),rotation_z=-5.5,scale=(.93,1,1))
key(head_ctrl,54,location=(0,2.50,.55),rotation_z=0,scale=(1,1,1))
key(head_ctrl,66,location=(0,2.50,.55),rotation_z=0,scale=(1,1,1))
key(head_ctrl,82,location=(.12,2.23,.55),rotation_z=5.0,scale=(.975,.965,1))
key(head_ctrl,112,location=(.12,2.23,.55),rotation_z=5.0,scale=(.975,.965,1))
blink(118)

# Arm/phone motion.
raise_phone(74,108)
key(arm_root,128,location=(1.30,.56,.16),rotation_z=-28)
key(elbow_ctrl,128,rotation_z=63)
key(wrist_ctrl,128,rotation_z=-22,scale=(1.04,1.04,1))

# Expression change after reading the screen.
key_visibility(head_surprised,1,False)
key_visibility(head_surprised,126,False)
key_visibility(head_neutral,126,True)
key_visibility(head_neutral,130,False)
key_visibility(head_blink,130,False)
key_visibility(head_surprised,130,True)
key_visibility(head_surprised,150,True)

# Default visibility for neutral/blink.
key_visibility(head_neutral,1,True)
key_visibility(head_blink,1,False)
key_visibility(head_neutral,125,True)
key_visibility(head_blink,125,False)

for obj in [torso_ctrl,head_ctrl,arm_root,elbow_ctrl,wrist_ctrl]:
    set_interpolation(obj,'BEZIER')
for obj in [head_neutral,head_blink,head_surprised]:
    set_interpolation(obj,'CONSTANT',{'hide_render','hide_viewport'})

# Save before rendering.
blend_path=OUTPUT/'short02_blender2d_arm_phone_v2.blend'
bpy.ops.wm.save_as_mainfile(filepath=str(blend_path))
scene.frame_set(1)
bpy.ops.render.render(animation=True)
print('BLENDER2D_ARM_PHONE_V2_DONE')
print('Blend:',blend_path)
print('Video:',scene.render.filepath)
