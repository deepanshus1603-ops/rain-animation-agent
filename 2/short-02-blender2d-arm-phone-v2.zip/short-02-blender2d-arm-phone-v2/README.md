# Short #2 — Blender 2D Proof V2: Arm + Phone

This is the next controlled step after the successful 3-second proof.
It is **not yet the full 15-second Bangalore Traffic Short**.

## What V2 adds

- full 9:16 background with no black bars
- Alex positioned larger and lower in the cab seat
- slightly stronger breathing
- clearer head turn and look-down motion
- a real parented arm hierarchy:

```text
PHONE_ARM_ROOT (shoulder)
  ├─ UPPER_ARM_PHONE
  └─ ELBOW_CTRL
       ├─ LOWER_ARM_PHONE
       └─ WRIST_PHONE_CTRL
            ├─ HAND_PHONE
            └─ PHONE_NOTICE
```

- the arm raises the phone over several keyframes
- the phone/hand follow the elbow and shoulder automatically
- Alex changes to a surprised expression after reading the screen
- all animation is generated from Blender Python

## Run

In PowerShell inside the extracted folder:

```powershell
.\run_v2.ps1
```

Or double-click:

```text
run_v2.bat
```

## Outputs

```text
output\short02_blender2d_arm_phone_v2.blend
output\short02_blender2d_arm_phone_v2.mp4
```

The proof is 5 seconds / 150 frames / 30 FPS. It renders at 50% resolution for speed.

## What to review

1. Does the arm feel attached to the shoulder?
2. Does the elbow bend in the right direction?
3. Does the phone finish near Alex's face?
4. Is the phone readable rather than covering his entire face?
5. Does the surprised expression change feel clean?
6. Is the full vertical frame filled correctly?

## Important

The extracted arm artwork is still an early rig asset. Small joint gaps or overlap are expected. The goal of V2 is to prove the **hierarchy and coded motion**, not final illustration polish.

## Next after approval

V3 will add:

- more natural elbow/wrist arcs
- screen gaze timing
- subtle torso lean toward phone
- traffic movement/parallax
- optional camera push-in
