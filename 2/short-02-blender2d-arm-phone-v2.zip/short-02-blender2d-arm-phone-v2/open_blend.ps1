$project = Split-Path -Parent $MyInvocation.MyCommand.Path
$blend = Join-Path $project "output\short02_blender2d_arm_phone_v2.blend"
if (-not (Test-Path $blend)) { Write-Host "Render V2 first."; exit 1 }
$exe = "C:\Program Files\Blender Foundation\Blender 5.2\blender.exe"
if (-not (Test-Path $exe)) { $exe = (Get-ChildItem "C:\Program Files\Blender Foundation" -Filter blender.exe -Recurse | Select-Object -First 1).FullName }
& $exe $blend
