@echo off
powershell -ExecutionPolicy Bypass -File "%~dp0run_proof.ps1"
pause
