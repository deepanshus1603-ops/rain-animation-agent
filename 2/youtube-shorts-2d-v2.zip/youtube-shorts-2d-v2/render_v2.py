from pathlib import Path
import json, math, asyncio, os, sys
import numpy as np
from PIL import Image, ImageDraw, ImageFont

ROOT=Path(__file__).resolve().parent
CFG=json.loads((ROOT/"scene.json").read_text(encoding="utf-8"))
W,H=CFG["width"],CFG["height"]
DURATION,FPS=CFG["duration"],CFG["fps"]

BG=Image.open(ROOT/"assets/backgrounds/room_v2.png").convert("RGB").resize((W,H))
def load(name):
    return Image.open(ROOT/"assets/character"/f"alex_{name}.png").convert("RGBA")
SPR={name:load(name) for name in ["stand","walk_a","walk_b","look_down","confident","step","shocked","slip","falling","annoyed"]}
BANANA=Image.open(ROOT/"assets/props/banana.png").convert("RGBA")
BANANA_FLAT=Image.open(ROOT/"assets/props/banana_flat.png").convert("RGBA")

def ease(x):
    x=max(0,min(1,x))
    return x*x*(3-2*x)

def paste(base,sprite,x,y,scale=1,angle=0,flip=False):
    s=sprite
    if flip:
        s=s.transpose(Image.Transpose.FLIP_LEFT_RIGHT)
    if scale!=1:
        s=s.resize((max(1,int(s.width*scale)),max(1,int(s.height*scale))),Image.Resampling.LANCZOS)
    if angle:
        s=s.rotate(angle,resample=Image.Resampling.BICUBIC,expand=True)
    base.paste(s,(int(x),int(y)),s)

def get_font(size,bold=True):
    candidates=[
        "C:/Windows/Fonts/arialbd.ttf" if bold else "C:/Windows/Fonts/arial.ttf",
        "C:/Windows/Fonts/segoeuib.ttf" if bold else "C:/Windows/Fonts/segoeui.ttf",
    ]
    for p in candidates:
        if os.path.exists(p):
            return ImageFont.truetype(p,size)
    return ImageFont.load_default()

def caption_for(t):
    for c in CFG["captions"]:
        if c["start"]<=t<=c["end"]:
            return c["text"]
    return None

def draw_caption(im,text,t):
    dr=ImageDraw.Draw(im)
    size=84 if len(text)<20 else 70
    font=get_font(size,True)
    box=dr.textbbox((0,0),text,font=font,stroke_width=4)
    tw,th=box[2]-box[0],box[3]-box[1]
    cx=(W-tw)//2
    # little pop on first 0.2 sec handled via mild scale illusion using y
    y=185
    pad=30
    dr.rounded_rectangle((cx-pad,y-pad,cx+tw+pad,y+th+pad),radius=28,fill=(255,255,255,235))
    dr.text((cx,y),text,font=font,fill=(25,25,25,255),stroke_width=4,stroke_fill=(255,255,255,255))

def frame(t):
    im=BG.copy().convert("RGBA")
    # first banana visible from 2.4 onward
    if t>=2.4:
        paste(im,BANANA,520,1328,.56,-8)
    # second banana hidden by table until reveal
    if t>=7.35 and t<8.15:
        p=ease((t-7.35)/.8)
        paste(im,BANANA,840,1345,.52,12)
        # reveal indicator
        dr=ImageDraw.Draw(im)
        r=int(26+28*p)
        dr.ellipse((880-r,1295-r,880+r,1295+r),outline=(255,205,40,255),width=8)
    elif t>=8.15:
        paste(im,BANANA_FLAT if t>=8.45 else BANANA,840,1345,.52,8)

    # character
    if t<2.4:
        p=ease(t/2.4)
        x=-390+p*700
        y=625+math.sin(t*12)*8
        pose="walk_a" if int(t*4)%2==0 else "walk_b"
        angle=0
    elif t<3.4:
        p=ease((t-2.4)/1.0)
        x=310+p*90
        y=625
        pose="look_down"
        angle=0
    elif t<4.45:
        x=400;y=625;pose="look_down";angle=0
    elif t<5.65:
        x=400;y=625;pose="confident";angle=0
    elif t<7.0:
        p=ease((t-5.65)/1.35)
        x=400+p*270
        y=625-math.sin(p*math.pi)*95
        pose="step"
        angle=-4*math.sin(p*math.pi)
    elif t<7.55:
        x=670;y=625;pose="confident";angle=0
    elif t<8.0:
        x=670;y=625;pose="shocked";angle=0
    elif t<9.6:
        p=ease((t-8.0)/1.6)
        x=670+p*80
        y=625+p*100
        pose="slip"
        angle=-65*p
    elif t<10.6:
        p=ease((t-9.6)/1.0)
        x=750-p*20
        y=725+p*650
        pose="falling"
        angle=-65-25*p
    elif t<12.3:
        # empty frame pause
        x=0;y=2200;pose="stand";angle=0
    else:
        p=ease((t-12.3)/1.15)
        x=245
        y=1500-p*560
        pose="annoyed"
        angle=0

    paste(im,SPR[pose],x,y,.86,angle)

    cap=caption_for(t)
    if cap:
        draw_caption(im,cap,t)
    return np.array(im.convert("RGB"))

async def ensure_tts():
    try:
        import edge_tts
    except Exception:
        print("edge-tts not installed; narration will be skipped.")
        return []
    outdir=ROOT/"cache"/"tts"
    outdir.mkdir(parents=True,exist_ok=True)
    tracks=[]
    for i,line in enumerate(CFG["dialogue"]):
        p=outdir/f"{i:02d}_{line['speaker']}.mp3"
        if not p.exists():
            voice=CFG["voice"][line["speaker"]]
            communicate=edge_tts.Communicate(line["text"],voice,rate="+4%")
            await communicate.save(str(p))
        tracks.append((p,float(line["start"])))
    return tracks

def main():
    from moviepy import VideoClip, AudioFileClip, CompositeAudioClip
    tts_tracks=asyncio.run(ensure_tts())
    audio=[]
    # voice tracks
    for p,start in tts_tracks:
        try:
            a=AudioFileClip(str(p)).with_start(start)
            audio.append(a)
        except Exception as e:
            print("Voice load warning:",e)
    # SFX
    sfx=[
        ("footstep_1.wav",0.55,0.65),
        ("footstep_2.wav",1.05,0.65),
        ("footstep_3.wav",1.55,0.65),
        ("footstep_4.wav",2.05,0.65),
        ("sting.wav",7.38,0.55),
        ("slip.wav",8.1,0.9),
        ("whoosh.wav",8.25,0.9),
        ("impact.wav",10.15,1.0),
    ]
    for fname,start,vol in sfx:
        p=ROOT/"assets"/"audio"/fname
        a=AudioFileClip(str(p)).with_start(start)
        try:
            a=a.with_volume_scaled(vol)
        except Exception:
            pass
        audio.append(a)

    clip=VideoClip(frame_function=frame,duration=DURATION)
    if audio:
        mix=CompositeAudioClip(audio)
        clip=clip.with_audio(mix)
    out=ROOT/"output"/"short_001_v2.mp4"
    out.parent.mkdir(exist_ok=True)
    clip.write_videofile(str(out),fps=FPS,codec="libx264",audio_codec="aac",
                         preset="medium",pixel_format="yuv420p",threads=4)
    print("\nDONE:",out)

if __name__=="__main__":
    main()
