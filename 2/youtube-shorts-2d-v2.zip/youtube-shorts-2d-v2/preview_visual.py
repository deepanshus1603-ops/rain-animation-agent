from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from render_v2 import frame, DURATION, FPS
from moviepy import VideoClip
out=ROOT/"output"/"short_001_v2_visual_preview.mp4"
clip=VideoClip(frame_function=frame,duration=DURATION)
clip.write_videofile(str(out),fps=FPS,codec="libx264",audio=False,preset="ultrafast",pixel_format="yuv420p")
print("DONE:",out)
