$ErrorActionPreference = "Stop"
& .\.venv\Scripts\python.exe render_v2.py
