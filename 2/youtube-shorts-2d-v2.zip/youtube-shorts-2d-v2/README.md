# 2D Shorts V2 - The Second Banana

This version upgrades the first prototype into a more complete 15-second Short.

## Improvements in V2
- Better, consistent Alex sprites
- Actual walk-cycle switching
- First banana appears only when Alex notices it
- Second banana is revealed later for the joke
- More readable slip/fall motion
- Empty-frame comedy pause after the impact
- Annoyed end reaction
- Narrator + Alex voice generation using Microsoft Edge TTS
- Timed captions
- Generated footsteps, slip, whoosh, impact, and sting SFX
- 1080x1920 / 30 FPS / 15 seconds

## Run on Windows

### First time
    .\setup.ps1

If PowerShell blocks scripts, run these commands instead:

    python -m venv .venv
    .\.venv\Scripts\python.exe -m pip install -r requirements.txt

### Render full V2
    .\run.ps1

Or directly:

    .\.venv\Scripts\python.exe render_v2.py

The first run needs internet access because Edge TTS generates the voices.

Output:
    output\short_001_v2.mp4

## Visual-only test
If you want to test the animation without TTS:

    .\.venv\Scripts\python.exe preview_visual.py

Output:
    output\short_001_v2_visual_preview.mp4

## Change voices
Edit `scene.json`.

Default voices:
- Narrator: en-US-GuyNeural
- Alex: en-US-AndrewNeural

## Change dialogue/captions
Also edit `scene.json`. The renderer will regenerate missing TTS files inside `cache\tts`.

Delete `cache\tts` if you change dialogue text and want fresh narration.
