$ErrorActionPreference = "Stop"
& .\.venv\Scripts\python.exe render_v5_safe.py
