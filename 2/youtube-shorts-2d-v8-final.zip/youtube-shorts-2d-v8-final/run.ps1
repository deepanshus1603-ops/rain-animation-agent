$ErrorActionPreference = "Stop"
& .\.venv\Scripts\python.exe render_v8_safe.py
