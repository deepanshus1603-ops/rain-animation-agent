@echo off
".venv\Scripts\python.exe" render_v8_safe.py
pause
