YOUTUBE SHORTS 2D - V8 FINAL CLEANUP
====================================

V8 intentionally makes ONLY final composition fixes.

What changed from V7
--------------------
1. SAME illustrated street artwork, but re-cropped to show
   substantially more sidewalk and less road.

2. Alex and both bananas are staged comfortably on the sidewalk.

3. The dark V7 oval shadow is replaced by a low-opacity,
   Gaussian-blurred contact shadow.

4. Banana spacing is cleaned up around the PLOT TWIST section.

5. Story, dialogue, timing, captions, music, SFX, Alex design,
   and final reaction are unchanged.

Run
---
    .\setup.ps1
    .\run.ps1

or double-click:

    run_v8.bat

Output
------
    output\short_001_v8_final.mp4

Rendering still uses the proven Windows-safe 3-pass flow:

    PASS 1 - video
    PASS 2 - audio
    PASS 3 - FFmpeg mux

After V8
--------
Freeze Short #1 and build Short #2 using the same engine.
