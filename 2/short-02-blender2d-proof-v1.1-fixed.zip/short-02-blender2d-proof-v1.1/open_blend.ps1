$ErrorActionPreference = "Stop"
$project = Split-Path -Parent $MyInvocation.MyCommand.Path
$blend = Join-Path $project "output\short02_blender2d_proof.blend"
if (-not (Test-Path $blend)) {
    Write-Host "Blend file not created yet. Run run_proof.bat first." -ForegroundColor Yellow
    exit 1
}
Start-Process $blend
