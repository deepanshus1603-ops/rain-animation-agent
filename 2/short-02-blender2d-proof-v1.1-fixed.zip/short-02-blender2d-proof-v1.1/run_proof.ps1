$ErrorActionPreference = "Stop"

$project = Split-Path -Parent $MyInvocation.MyCommand.Path
$script = Join-Path $project "scripts\build_and_render_proof.py"
$outputDir = Join-Path $project "output"
$blendOut = Join-Path $outputDir "short02_blender2d_proof.blend"
$videoOut = Join-Path $outputDir "short02_blender2d_proof.mp4"

$blender = $null

$cmd = Get-Command blender -ErrorAction SilentlyContinue
if ($cmd) { $blender = $cmd.Source }

if (-not $blender) {
    $roots = @(
        "C:\Program Files\Blender Foundation\Blender 5.2\blender.exe",
        "C:\Program Files\Blender Foundation\Blender 5.1\blender.exe",
        "C:\Program Files\Blender Foundation\Blender 5.0\blender.exe",
        "C:\Program Files\Blender Foundation\Blender 4.5\blender.exe"
    )

    foreach ($candidate in $roots) {
        if (Test-Path $candidate) {
            $blender = $candidate
            break
        }
    }
}

if (-not $blender -and (Test-Path "C:\Program Files\Blender Foundation")) {
    $found = Get-ChildItem "C:\Program Files\Blender Foundation" `
        -Filter blender.exe -Recurse -ErrorAction SilentlyContinue |
        Select-Object -First 1

    if ($found) {
        $blender = $found.FullName
    }
}

if (-not $blender) {
    Write-Host "Blender executable was not found." -ForegroundColor Red
    exit 1
}

Write-Host "Using Blender: $blender" -ForegroundColor Cyan
Write-Host "Building and rendering 3-second proof..." -ForegroundColor Cyan

if (Test-Path $blendOut) { Remove-Item $blendOut -Force }
if (Test-Path $videoOut) { Remove-Item $videoOut -Force }

& $blender --background --python $script

if ($LASTEXITCODE -ne 0) {
    Write-Host "Blender returned exit code $LASTEXITCODE" -ForegroundColor Red
    exit $LASTEXITCODE
}

if (-not (Test-Path $blendOut)) {
    Write-Host ""
    Write-Host "FAILED: Blender did not create the .blend file." -ForegroundColor Red
    Write-Host "Check the Python error above." -ForegroundColor Yellow
    exit 2
}

if (-not (Test-Path $videoOut)) {
    Write-Host ""
    Write-Host "FAILED: Blender did not create the MP4." -ForegroundColor Red
    Write-Host "Check the Blender render error above." -ForegroundColor Yellow
    exit 3
}

Write-Host ""
Write-Host "SUCCESS" -ForegroundColor Green
Write-Host "Blend: output\short02_blender2d_proof.blend"
Write-Host "Video: output\short02_blender2d_proof.mp4"
