import bpy
import math
from pathlib import Path

# ------------------------------------------------------------
# Short #2 - Blender 2D Proof V1
# Blender 5.2 target
# Creates a 3-second 2D scene using flat PNG layers and real keyframes.
# ------------------------------------------------------------

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / "assets"
OUTPUT = ROOT / "output"
OUTPUT.mkdir(parents=True, exist_ok=True)

# ---------- helpers ----------
def clear_scene():
    bpy.ops.object.select_all(action='SELECT')
    bpy.ops.object.delete(use_global=False)
    for datablocks in (bpy.data.meshes, bpy.data.curves, bpy.data.materials, bpy.data.cameras):
        # keep images; they may be reused by materials during setup
        pass

def make_image_material(name, image_path):
    img = bpy.data.images.load(str(image_path), check_existing=True)
    mat = bpy.data.materials.new(name=name)
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()

    out = nodes.new('ShaderNodeOutputMaterial')
    transparent = nodes.new('ShaderNodeBsdfTransparent')
    emission = nodes.new('ShaderNodeEmission')
    tex = nodes.new('ShaderNodeTexImage')
    mix = nodes.new('ShaderNodeMixShader')

    tex.image = img
    tex.interpolation = 'Linear'
    emission.inputs['Strength'].default_value = 1.0

    links.new(tex.outputs['Color'], emission.inputs['Color'])
    links.new(tex.outputs['Alpha'], mix.inputs[0])
    links.new(transparent.outputs[0], mix.inputs[1])
    links.new(emission.outputs[0], mix.inputs[2])
    links.new(mix.outputs[0], out.inputs['Surface'])

    # Blender 4.2+/5.x transparency setting, with legacy fallback.
    try:
        mat.surface_render_method = 'DITHERED'
    except Exception:
        try:
            mat.blend_method = 'BLEND'
        except Exception:
            pass
    try:
        mat.use_transparency_overlap = False
    except Exception:
        pass
    return mat, img

def make_plane(name, image_path, width, z=0.0, parent=None, local_location=(0,0,0)):
    mat, img = make_image_material(name + '_MAT', image_path)
    aspect = img.size[1] / img.size[0]
    height = width * aspect
    verts = [(-width/2,-height/2,0),(width/2,-height/2,0),(width/2,height/2,0),(-width/2,height/2,0)]
    faces = [(0,1,2,3)]
    mesh = bpy.data.meshes.new(name + '_MESH')
    mesh.from_pydata(verts, [], faces)
    mesh.update()
    obj = bpy.data.objects.new(name, mesh)
    bpy.context.collection.objects.link(obj)
    obj.data.materials.append(mat)
    obj.location = (*local_location[:2], z if parent is None else local_location[2])

    # UV map
    uv = mesh.uv_layers.new(name='UVMap')
    coords = [(0,0),(1,0),(1,1),(0,1)]
    for poly in mesh.polygons:
        for li in poly.loop_indices:
            vi = mesh.loops[li].vertex_index
            uv.data[li].uv = coords[vi]

    if parent:
        obj.parent = parent
    return obj, height

def empty(name, location=(0,0,0), parent=None):
    obj = bpy.data.objects.new(name, None)
    bpy.context.collection.objects.link(obj)
    obj.empty_display_type = 'PLAIN_AXES'
    obj.empty_display_size = 0.35
    obj.location = location
    if parent:
        obj.parent = parent
    return obj

def key(obj, frame, location=None, rotation_z=None, scale=None):
    if location is not None:
        obj.location = location
        obj.keyframe_insert('location', frame=frame)
    if rotation_z is not None:
        obj.rotation_euler[2] = math.radians(rotation_z)
        obj.keyframe_insert('rotation_euler', index=2, frame=frame)
    if scale is not None:
        obj.scale = scale
        obj.keyframe_insert('scale', frame=frame)

def set_smooth(obj):
    if not obj.animation_data or not obj.animation_data.action:
        return
    action = obj.animation_data.action
    try:
        # Blender layered action API may expose fcurves differently; this path works for standard actions.
        curves = action.fcurves
    except Exception:
        return
    for fc in curves:
        for kp in fc.keyframe_points:
            kp.interpolation = 'BEZIER'

def key_visibility(obj, frame, visible):
    obj.hide_render = not visible
    obj.hide_viewport = not visible
    obj.keyframe_insert('hide_render', frame=frame)
    obj.keyframe_insert('hide_viewport', frame=frame)

def set_constant_visibility(obj):
    if not obj.animation_data or not obj.animation_data.action:
        return
    try:
        curves = obj.animation_data.action.fcurves
    except Exception:
        return
    for fc in curves:
        if fc.data_path in {'hide_render','hide_viewport'}:
            for kp in fc.keyframe_points:
                kp.interpolation = 'CONSTANT'

# ---------- scene ----------
clear_scene()
scene = bpy.context.scene
scene.frame_start = 1
scene.frame_end = 90
# Blender 5.2 uses BLENDER_EEVEE. Keep fallback for older/newer builds.
try:
    scene.render.engine = 'BLENDER_EEVEE'
except TypeError:
    try:
        scene.render.engine = 'BLENDER_EEVEE_NEXT'
    except TypeError:
        scene.render.engine = 'BLENDER_WORKBENCH'
scene.render.resolution_x = 1080
scene.render.resolution_y = 1920
scene.render.resolution_percentage = 50  # proof render = 540x960 for speed; change to 100 for final
scene.render.fps = 30
scene.render.film_transparent = False
scene.world.color = (0.04,0.04,0.04)

# Output video
scene.render.image_settings.file_format = 'FFMPEG'
scene.render.ffmpeg.format = 'MPEG4'
scene.render.ffmpeg.codec = 'H264'
scene.render.ffmpeg.constant_rate_factor = 'MEDIUM'
scene.render.filepath = str(OUTPUT / 'short02_blender2d_proof.mp4')

# Camera looking straight at XY planes.
cam_data = bpy.data.cameras.new('Camera')
cam = bpy.data.objects.new('Camera', cam_data)
bpy.context.collection.objects.link(cam)
cam.location = (0,0,20)
cam.rotation_euler = (0,0,0)
cam_data.type = 'ORTHO'
cam_data.ortho_scale = 19.2
scene.camera = cam

# Background fills portrait frame. Use a landscape source stretched only for this proof.
bg, _ = make_plane('BG', ASSETS/'cab_traffic_background_reference.jpg', 10.8, z=-5)
bg.scale.y = 2.0

# Add a dark translucent lower card to make the proof rig easier to see.
# (No lighting required; all PNGs use emission materials.)

# Character hierarchy.
root = empty('ALEX_ROOT', location=(0,-2.2,0))
torso_ctrl = empty('TORSO_CTRL', location=(0,0,0), parent=root)
torso, torso_h = make_plane('TORSO', ASSETS/'torso_seatbelt.png', 4.3, parent=torso_ctrl, local_location=(0,-0.45,0.0))

# Neck/head pivot lives above torso.
head_ctrl = empty('HEAD_CTRL', location=(0,2.25,0.5), parent=torso_ctrl)
head_neutral, head_h = make_plane('HEAD_NEUTRAL', ASSETS/'head_neutral.png', 3.15, parent=head_ctrl, local_location=(0,1.0,0.0))
head_blink, _ = make_plane('HEAD_BLINK', ASSETS/'head_blink.png', 3.15, parent=head_ctrl, local_location=(0,1.0,0.03))

# A small visible guide shows the intended character reference outside final render area.
# Keep proof simple: torso + independently controlled head.

# ---------- animation ----------
# 1) breathing: torso gently expands/contracts; head follows because it is parented.
key(torso_ctrl, 1, scale=(1.0,1.0,1.0))
key(torso_ctrl, 23, scale=(1.008,1.018,1.0))
key(torso_ctrl, 45, scale=(1.0,1.0,1.0))
key(torso_ctrl, 67, scale=(1.008,1.018,1.0))
key(torso_ctrl, 90, scale=(1.0,1.0,1.0))

# 2) blink around frame 15.
key_visibility(head_neutral, 1, True)
key_visibility(head_blink, 1, False)
key_visibility(head_neutral, 13, True)
key_visibility(head_blink, 13, False)
key_visibility(head_neutral, 15, False)
key_visibility(head_blink, 15, True)
key_visibility(head_neutral, 17, True)
key_visibility(head_blink, 17, False)
key_visibility(head_neutral, 90, True)
key_visibility(head_blink, 90, False)

# 3) look toward traffic: actual transform animation of head control.
key(head_ctrl, 1, location=(0,2.25,0.5), rotation_z=0, scale=(1,1,1))
key(head_ctrl, 30, location=(-0.15,2.25,0.5), rotation_z=-4.5, scale=(0.94,1.0,1.0))
key(head_ctrl, 42, location=(-0.15,2.25,0.5), rotation_z=-4.5, scale=(0.94,1.0,1.0))
key(head_ctrl, 54, location=(0,2.25,0.5), rotation_z=0, scale=(1,1,1))

# 4) look down toward phone: head lowers/tilts rather than swapping the whole body.
key(head_ctrl, 66, location=(0,2.25,0.5), rotation_z=0, scale=(1,1,1))
key(head_ctrl, 78, location=(0.10,2.05,0.5), rotation_z=3.5, scale=(0.98,0.98,1.0))
key(head_ctrl, 90, location=(0.10,2.05,0.5), rotation_z=3.5, scale=(0.98,0.98,1.0))

set_smooth(torso_ctrl)
set_smooth(head_ctrl)
set_constant_visibility(head_neutral)
set_constant_visibility(head_blink)

# Save before render so user can inspect/edit the rig.
blend_path = OUTPUT / 'short02_blender2d_proof.blend'
bpy.ops.wm.save_as_mainfile(filepath=str(blend_path))

# Render animation.
scene.frame_set(1)
bpy.ops.render.render(animation=True)
print('BLENDER2D_PROOF_DONE')
print('Blend:', blend_path)
print('Video:', scene.render.filepath)
