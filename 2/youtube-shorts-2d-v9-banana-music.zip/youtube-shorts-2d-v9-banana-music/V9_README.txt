YOUTUBE SHORTS 2D - V9 BETTER BANANA + MUSIC
=============================================

What changed
------------
1. Replaced the simple Python-drawn banana prop with image-generated
   illustrated banana assets.

2. Added:
       assets\props\banana_real_whole.png
       assets\props\banana_real_peel.png

3. The second banana/slip prop now uses an illustrated open peel.

4. Added a fuller original upbeat cartoon music bed:
       assets\audio\upbeat_cartoon_v2.wav

5. Music volume is raised from the very subtle V8 level so it is
   actually noticeable, while speech and SFX remain clear.

6. Same Alex, environment, captions, voice timing, and 3-pass
   Windows-safe rendering pipeline.

Run
---
    .\setup.ps1
    .\run.ps1

or double-click:

    run_v9.bat

Output
------
    output\short_001_v9_banana_music.mp4
