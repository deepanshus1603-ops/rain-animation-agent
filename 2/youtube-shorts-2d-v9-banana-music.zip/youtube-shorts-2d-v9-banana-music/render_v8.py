from pathlib import Path
import json, math, os
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter

ROOT = Path(__file__).resolve().parent
CFG = json.loads((ROOT/'scene.json').read_text(encoding='utf-8'))
W,H = CFG['width'], CFG['height']
DURATION,FPS = CFG['duration'], CFG['fps']

BG = Image.open(
    ROOT/'assets/backgrounds/street_vertical_v8.png'
).convert('RGB').resize((W,H))

BANANA = Image.open(ROOT/'assets/props/banana_real_whole.png').convert('RGBA')
BANANA_FLAT = Image.open(ROOT/'assets/props/banana_real_peel.png').convert('RGBA')

SPRITES = {}
for name in [
    'idle','walk_1','walk_2','notice','confident',
    'step','shocked','slip','falling','annoyed'
]:
    SPRITES[name] = Image.open(
        ROOT/'assets/character'/f'alex_{name}.png'
    ).convert('RGBA')

# Keep the V7 character sizing that already looked good.
POSE_SCALE = {
    'idle': .96,
    'walk_1': .98,
    'walk_2': .97,
    'notice': .98,
    'confident': .97,
    'step': .98,
    'shocked': .97,
    'slip': .97,
    'falling': .84,
    'annoyed': .88,
}

POSE_Y_OFFSET = {
    'idle':0,'walk_1':0,'walk_2':0,'notice':0,'confident':0,
    'step':0,'shocked':0,'slip':0,'falling':18,'annoyed':20
}

def ease(x):
    x=max(0,min(1,x))
    return x*x*(3-2*x)

def ease_out_back(x):
    x=max(0,min(1,x))
    c1=1.70158
    c3=c1+1
    return 1+c3*(x-1)**3+c1*(x-1)**2

def paste_center(base,sprite,cx,top,scale=1,angle=0):
    s=sprite
    if scale!=1:
        s=s.resize(
            (max(1,int(s.width*scale)),max(1,int(s.height*scale))),
            Image.Resampling.LANCZOS
        )
    if angle:
        s=s.rotate(
            angle,
            resample=Image.Resampling.BICUBIC,
            expand=True
        )
    base.paste(s,(int(cx-s.width/2),int(top)),s)

def paste_prop(base,sprite,cx,y,scale=1,angle=0):
    s=sprite.resize(
        (max(1,int(sprite.width*scale)),max(1,int(sprite.height*scale))),
        Image.Resampling.LANCZOS
    )
    if angle:
        s=s.rotate(
            angle,
            resample=Image.Resampling.BICUBIC,
            expand=True
        )
    base.paste(s,(int(cx-s.width/2),int(y)),s)

def get_font(size,bold=True):
    candidates=[
        'C:/Windows/Fonts/arialbd.ttf' if bold
            else 'C:/Windows/Fonts/arial.ttf',
        'C:/Windows/Fonts/segoeuib.ttf' if bold
            else 'C:/Windows/Fonts/segoeui.ttf',
    ]
    for p in candidates:
        if os.path.exists(p):
            return ImageFont.truetype(p,size)
    return ImageFont.load_default()

def caption_for(t):
    for c in CFG['captions']:
        if c['start']<=t<=c['end']:
            return c
    return None

def draw_caption(im,c,t):
    dr=ImageDraw.Draw(im)
    f=get_font(86 if len(c['text'])<16 else 72,True)
    box=dr.textbbox((0,0),c['text'],font=f,stroke_width=4)
    tw,th=box[2]-box[0],box[3]-box[1]
    age=max(0,t-c['start'])
    pop=min(1,age/.12)
    y=int(155-(1-pop)*24)
    x=(W-tw)//2
    pad=28
    dr.rounded_rectangle(
        (x-pad,y-pad,x+tw+pad,y+th+pad),
        radius=28,
        fill=(255,255,255,236)
    )
    dr.text(
        (x,y),c['text'],font=f,
        fill=(24,24,24,255),
        stroke_width=4,
        stroke_fill=(255,255,255,255)
    )

def reveal_lines(im,cx,cy,p):
    dr=ImageDraw.Draw(im)
    for a in np.linspace(-2.8,-.35,8):
        r1=55
        r2=105+45*p
        dr.line(
            (
                cx+math.cos(a)*r1,
                cy+math.sin(a)*r1,
                cx+math.cos(a)*r2,
                cy+math.sin(a)*r2
            ),
            fill=(255,207,38,255),
            width=11
        )

def impact_star(im,t):
    if not (9.45<=t<=10.0):
        return

    p=(t-9.45)/.55
    r2=145*(1-p)
    if r2<35:
        return

    cx,cy=415,1535
    pts=[]
    for i in range(16):
        a=2*math.pi*i/16
        r=r2 if i%2==0 else 35
        pts.append(
            (cx+math.cos(a)*r,cy+math.sin(a)*r)
        )

    ImageDraw.Draw(im).polygon(
        pts,
        fill=(255,218,74,215),
        outline=(88,56,30,255)
    )

def draw_soft_shadow(im,cx,pose):
    """Soft blurred contact shadow rather than V7's dark oval."""
    if pose == 'falling':
        return

    if pose == 'annoyed':
        cy=1536
        rx,ry=88,16
        opacity=36
    elif pose == 'slip':
        cy=1518
        rx,ry=82,14
        opacity=30
    else:
        cy=1518
        rx,ry=96,16
        opacity=32

    pad=45
    layer=Image.new('RGBA',(W,H),(0,0,0,0))
    dr=ImageDraw.Draw(layer,'RGBA')
    dr.ellipse(
        (
            cx-rx,
            cy-ry,
            cx+rx,
            cy+ry
        ),
        fill=(20,18,15,opacity)
    )

    # Gaussian blur creates a ground-contact shadow instead of a black disc.
    layer=layer.filter(ImageFilter.GaussianBlur(radius=18))
    im.alpha_composite(layer)

def draw_second_banana(im,t):
    # Slightly more spacing from Alex's feet than V7.
    if 7.20<=t<8.05:
        p=(t-7.20)/.85
        pulse=1+.16*math.sin(min(1,p)*math.pi)
        paste_prop(
            im,BANANA,
            505,1442,
            .88*pulse,
            10
        )
        reveal_lines(im,505,1490,ease(p))
    elif t>=8.05:
        paste_prop(
            im,
            BANANA_FLAT if t>=8.22 else BANANA,
            505,1442,
            .88,
            8
        )

def frame(t):
    im=BG.copy().convert('RGBA')

    # Both banana props are now comfortably inside the broad sidewalk.
    if t>=2.15:
        paste_prop(
            im,BANANA,
            345,1450,
            .82,
            -8
        )

    if t>=7.20:
        draw_second_banana(im,t)

    # V8 uses the broader sidewalk crop, so Alex can stay comfortably
    # visible instead of being pushed against the left frame edge.
    if t<2.10:
        p=ease(t/2.10)
        cx=-150+p*400
        top=665+math.sin(t*13)*3
        pose='walk_1' if int(t*5)%2==0 else 'walk_2'
        angle=0

    elif t<3.25:
        p=ease((t-2.10)/1.15)
        cx=250+p*45
        top=665
        pose='notice'
        angle=0

    elif t<4.20:
        cx=295
        top=665
        pose='notice'
        angle=0

    elif t<5.40:
        cx=295
        top=665
        pose='confident'
        angle=0

    elif t<6.70:
        p=ease((t-5.40)/1.30)
        cx=295+p*110
        top=665-math.sin(p*math.pi)*12
        pose='step'
        angle=-1.5*math.sin(p*math.pi)

    elif t<7.20:
        cx=405
        top=665
        pose='idle'
        angle=0

    elif t<7.70:
        cx=405
        top=665
        pose='shocked'
        angle=0

    elif t<8.05:
        p=ease((t-7.70)/.35)
        cx=405+p*45
        top=665
        pose='step'
        angle=0

    elif t<8.95:
        p=ease((t-8.05)/.90)
        cx=450-p*55
        top=665+p*70
        pose='slip'
        angle=48*p

    elif t<9.70:
        p=ease((t-8.95)/.75)
        cx=395-p*15
        top=735+p*410
        pose='falling'
        angle=48+18*p

    elif t<12.0:
        cx=380
        top=2300
        pose='idle'
        angle=0

    else:
        p=ease_out_back((t-12.0)/1.0)
        p=max(0,min(1.05,p))
        cx=370
        top=1450-p*505
        pose='annoyed'
        angle=0

    top += POSE_Y_OFFSET[pose]

    draw_soft_shadow(im,cx,pose)

    paste_center(
        im,
        SPRITES[pose],
        cx,
        top,
        POSE_SCALE[pose],
        angle
    )

    impact_star(im,t)

    c=caption_for(t)
    if c:
        draw_caption(im,c,t)

    return np.array(im.convert('RGB'))
