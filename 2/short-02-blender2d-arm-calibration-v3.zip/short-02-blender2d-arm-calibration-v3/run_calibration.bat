@echo off
powershell -ExecutionPolicy Bypass -File "%~dp0run_calibration.ps1"
pause
