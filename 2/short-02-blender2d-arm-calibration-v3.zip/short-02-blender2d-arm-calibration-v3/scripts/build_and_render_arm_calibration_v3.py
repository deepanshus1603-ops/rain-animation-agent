import bpy
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / "assets"
OUTPUT = ROOT / "output"
CONFIG_PATH = ROOT / "arm_calibration_config.json"

OUTPUT.mkdir(parents=True, exist_ok=True)
CFG = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))

def clear_scene():
    bpy.ops.object.select_all(action="SELECT")
    bpy.ops.object.delete(use_global=False)

def make_image_material(name, image_path):
    image = bpy.data.images.load(str(image_path), check_existing=True)

    material = bpy.data.materials.new(name=name)
    material.use_nodes = True

    nodes = material.node_tree.nodes
    links = material.node_tree.links
    nodes.clear()

    output_node = nodes.new("ShaderNodeOutputMaterial")
    transparent = nodes.new("ShaderNodeBsdfTransparent")
    emission = nodes.new("ShaderNodeEmission")
    texture = nodes.new("ShaderNodeTexImage")
    mix = nodes.new("ShaderNodeMixShader")

    texture.image = image
    texture.interpolation = "Linear"
    emission.inputs["Strength"].default_value = 1.0

    links.new(texture.outputs["Color"], emission.inputs["Color"])
    links.new(texture.outputs["Alpha"], mix.inputs[0])
    links.new(transparent.outputs[0], mix.inputs[1])
    links.new(emission.outputs[0], mix.inputs[2])
    links.new(mix.outputs[0], output_node.inputs["Surface"])

    try:
        material.surface_render_method = "DITHERED"
    except Exception:
        try:
            material.blend_method = "BLEND"
        except Exception:
            pass

    return material, image

def make_plane_with_pivot(
    name,
    image_path,
    pixels_per_unit,
    pivot_px,
    parent=None,
    local_location=(0.0, 0.0, 0.0),
):
    material, image = make_image_material(name + "_MAT", image_path)

    width_px = float(image.size[0])
    height_px = float(image.size[1])
    pivot_x = float(pivot_px[0])
    pivot_y = float(pivot_px[1])

    left = -pivot_x / pixels_per_unit
    right = (width_px - pivot_x) / pixels_per_unit
    top = pivot_y / pixels_per_unit
    bottom = -(height_px - pivot_y) / pixels_per_unit

    vertices = [
        (left, bottom, 0.0),
        (right, bottom, 0.0),
        (right, top, 0.0),
        (left, top, 0.0),
    ]

    mesh = bpy.data.meshes.new(name + "_MESH")
    mesh.from_pydata(vertices, [], [(0, 1, 2, 3)])
    mesh.update()

    obj = bpy.data.objects.new(name, mesh)
    bpy.context.collection.objects.link(obj)
    obj.data.materials.append(material)

    if parent is not None:
        obj.parent = parent

    obj.location = local_location

    uv_layer = mesh.uv_layers.new(name="UVMap")
    uv_coordinates = [(0, 0), (1, 0), (1, 1), (0, 1)]

    for polygon in mesh.polygons:
        for loop_index in polygon.loop_indices:
            vertex_index = mesh.loops[loop_index].vertex_index
            uv_layer.data[loop_index].uv = uv_coordinates[vertex_index]

    return obj

def make_fixed_plane(name, image_path, width, height, z):
    material, _ = make_image_material(name + "_MAT", image_path)

    vertices = [
        (-width / 2, -height / 2, 0),
        (width / 2, -height / 2, 0),
        (width / 2, height / 2, 0),
        (-width / 2, height / 2, 0),
    ]

    mesh = bpy.data.meshes.new(name + "_MESH")
    mesh.from_pydata(vertices, [], [(0, 1, 2, 3)])
    mesh.update()

    obj = bpy.data.objects.new(name, mesh)
    bpy.context.collection.objects.link(obj)
    obj.data.materials.append(material)
    obj.location = (0, 0, z)

    uv_layer = mesh.uv_layers.new(name="UVMap")
    uv_coordinates = [(0, 0), (1, 0), (1, 1), (0, 1)]

    for polygon in mesh.polygons:
        for loop_index in polygon.loop_indices:
            vertex_index = mesh.loops[loop_index].vertex_index
            uv_layer.data[loop_index].uv = uv_coordinates[vertex_index]

    return obj

def make_empty(name, parent=None, local_location=(0, 0, 0), size=0.22):
    obj = bpy.data.objects.new(name, None)
    bpy.context.collection.objects.link(obj)

    obj.empty_display_type = "PLAIN_AXES"
    obj.empty_display_size = size

    if parent is not None:
        obj.parent = parent

    obj.location = local_location
    return obj

def make_color_material(name, rgba):
    material = bpy.data.materials.new(name=name)
    material.use_nodes = True

    nodes = material.node_tree.nodes
    links = material.node_tree.links
    nodes.clear()

    output_node = nodes.new("ShaderNodeOutputMaterial")
    emission = nodes.new("ShaderNodeEmission")
    emission.inputs["Color"].default_value = rgba
    emission.inputs["Strength"].default_value = 1.0

    links.new(emission.outputs[0], output_node.inputs["Surface"])
    return material

def make_marker(name, rgba, parent):
    bpy.ops.mesh.primitive_circle_add(
        vertices=48,
        radius=0.115,
        fill_type="NGON",
        location=(0, 0, 0)
    )

    marker = bpy.context.object
    marker.name = name
    marker.parent = parent
    marker.location = (0, 0, 1.7)
    marker.data.materials.append(
        make_color_material(name + "_MAT", rgba)
    )
    return marker

def make_text(name, body, location, size=0.60):
    curve = bpy.data.curves.new(type="FONT", name=name + "_CURVE")
    curve.body = body
    curve.align_x = "CENTER"
    curve.align_y = "CENTER"
    curve.size = size
    curve.extrude = 0.0

    obj = bpy.data.objects.new(name, curve)
    bpy.context.collection.objects.link(obj)
    obj.location = location

    obj.data.materials.append(
        make_color_material(
            name + "_MAT",
            (1.0, 1.0, 1.0, 1.0)
        )
    )
    return obj

def key_rotation(obj, frame, degrees):
    obj.rotation_euler[2] = math.radians(degrees)
    obj.keyframe_insert(
        data_path="rotation_euler",
        index=2,
        frame=frame
    )

def key_visibility(obj, frame, visible):
    obj.hide_render = not visible
    obj.hide_viewport = not visible

    obj.keyframe_insert(
        data_path="hide_render",
        frame=frame
    )
    obj.keyframe_insert(
        data_path="hide_viewport",
        frame=frame
    )

def set_constant_interpolation(obj):
    if not obj.animation_data or not obj.animation_data.action:
        return

    try:
        curves = obj.animation_data.action.fcurves
    except Exception:
        return

    for curve in curves:
        for point in curve.keyframe_points:
            point.interpolation = "CONSTANT"

def enum_values(obj, property_name):
    try:
        return [
            item.identifier
            for item in obj.bl_rna.properties[property_name].enum_items
        ]
    except Exception:
        return []

def set_first_supported(obj, property_name, choices):
    available = enum_values(obj, property_name)

    for choice in choices:
        if not available or choice in available:
            try:
                setattr(obj, property_name, choice)
                print(property_name + ":", choice)
                return choice
            except Exception:
                pass

    raise RuntimeError(
        f"No supported value for {property_name}. "
        f"Available: {available}"
    )

def solve_ik(shoulder, wrist, upper_length, lower_length):
    sx, sy = shoulder
    tx, ty = wrist

    dx = tx - sx
    dy = ty - sy
    distance = math.hypot(dx, dy)

    distance = max(
        abs(upper_length - lower_length) + 1e-6,
        min(upper_length + lower_length - 1e-6, distance)
    )

    base_angle = math.atan2(dy, dx)
    inner = (
        upper_length ** 2
        + distance ** 2
        - lower_length ** 2
    ) / (2 * upper_length * distance)

    angle_offset = math.acos(
        max(-1.0, min(1.0, inner))
    )

    candidates = []

    for angle in [
        base_angle - angle_offset,
        base_angle + angle_offset
    ]:
        candidates.append((
            sx + upper_length * math.cos(angle),
            sy + upper_length * math.sin(angle)
        ))

    # Bend outward toward the viewer-right side.
    return max(candidates, key=lambda point: point[0])

clear_scene()

scene = bpy.context.scene
scene.frame_start = 1
scene.frame_end = int(CFG["frames"])
scene.render.fps = int(CFG["fps"])

print("Blender version:", bpy.app.version_string)

try:
    scene.render.engine = "BLENDER_EEVEE"
except TypeError:
    try:
        scene.render.engine = "BLENDER_EEVEE_NEXT"
    except TypeError:
        scene.render.engine = "BLENDER_WORKBENCH"

scene.render.resolution_x = int(CFG["video_resolution"][0])
scene.render.resolution_y = int(CFG["video_resolution"][1])
scene.render.resolution_percentage = int(
    CFG["video_resolution_percentage"]
)
scene.render.film_transparent = False
scene.world.color = (0.025, 0.030, 0.040)

camera_data = bpy.data.cameras.new("Camera")
camera = bpy.data.objects.new("Camera", camera_data)
bpy.context.collection.objects.link(camera)

camera.location = (0, 0, 20)
camera.rotation_euler = (0, 0, 0)
camera_data.type = "ORTHO"
camera_data.ortho_scale = 19.2
scene.camera = camera

make_fixed_plane(
    "CAB_BACKGROUND",
    ASSETS / "cab_background_portrait.png",
    10.8,
    19.2,
    -5.0
)

torso_ppu = float(CFG["torso_pixels_per_unit"])
arm_ppu = float(CFG["arm_pixels_per_unit"])

torso_center = CFG["torso_center"]
head_center = CFG["head_center"]
shoulder_world = CFG["shoulder_world"]

root = make_empty(
    "ALEX_ROOT",
    local_location=(0, 0, 0),
    size=0.38
)

torso = make_plane_with_pivot(
    "TORSO_CLEAN",
    ASSETS / "torso_phone_arm_removed.png",
    torso_ppu,
    (90, 78),
    parent=root,
    local_location=(
        float(torso_center[0]),
        float(torso_center[1]),
        0.20
    )
)

head = make_plane_with_pivot(
    "HEAD_NEUTRAL",
    ASSETS / "head_neutral.png",
    torso_ppu,
    (57, 77),
    parent=root,
    local_location=(
        float(head_center[0]),
        float(head_center[1]),
        0.60
    )
)

shoulder_ctrl = make_empty(
    "SHOULDER_CTRL",
    parent=root,
    local_location=(
        float(shoulder_world[0]),
        float(shoulder_world[1]),
        0.10
    ),
    size=0.20
)

pivots = CFG["source_pivots"]

upper_shoulder = pivots["upper_shoulder"]
upper_elbow_px = pivots["upper_elbow"]
lower_elbow_px = pivots["lower_elbow"]
lower_wrist_px = pivots["lower_wrist"]
hand_wrist_px = pivots["hand_wrist"]

upper_vector = (
    (upper_elbow_px[0] - upper_shoulder[0]) / arm_ppu,
    -(upper_elbow_px[1] - upper_shoulder[1]) / arm_ppu
)

lower_vector = (
    (lower_wrist_px[0] - lower_elbow_px[0]) / arm_ppu,
    -(lower_wrist_px[1] - lower_elbow_px[1]) / arm_ppu
)

upper_length = math.hypot(
    upper_vector[0],
    upper_vector[1]
)
lower_length = math.hypot(
    lower_vector[0],
    lower_vector[1]
)

upper_natural_angle = math.atan2(
    upper_vector[1],
    upper_vector[0]
)
lower_natural_angle = math.atan2(
    lower_vector[1],
    lower_vector[0]
)

upper_arm = make_plane_with_pivot(
    "UPPER_ARM_PHONE",
    ASSETS / "upper_arm_phone.png",
    arm_ppu,
    upper_shoulder,
    parent=shoulder_ctrl,
    local_location=(0, 0, 0.00)
)

elbow_ctrl = make_empty(
    "ELBOW_CTRL",
    parent=upper_arm,
    local_location=(
        upper_vector[0],
        upper_vector[1],
        0.10
    ),
    size=0.18
)

lower_arm = make_plane_with_pivot(
    "LOWER_ARM_PHONE",
    ASSETS / "lower_arm_phone.png",
    arm_ppu,
    lower_elbow_px,
    parent=elbow_ctrl,
    local_location=(0, 0, 0.10)
)

wrist_ctrl = make_empty(
    "WRIST_CTRL",
    parent=lower_arm,
    local_location=(
        lower_vector[0],
        lower_vector[1],
        0.10
    ),
    size=0.16
)

hand = make_plane_with_pivot(
    "HAND_AND_PHONE",
    ASSETS / "hand_phone.png",
    arm_ppu,
    hand_wrist_px,
    parent=wrist_ctrl,
    local_location=(0, 0, 0.10)
)

shoulder_marker = make_marker(
    "MARKER_SHOULDER_RED",
    CFG["marker_colors"]["shoulder"],
    shoulder_ctrl
)
elbow_marker = make_marker(
    "MARKER_ELBOW_GREEN",
    CFG["marker_colors"]["elbow"],
    elbow_ctrl
)
wrist_marker = make_marker(
    "MARKER_WRIST_BLUE",
    CFG["marker_colors"]["wrist"],
    wrist_ctrl
)

marker_objects = [
    shoulder_marker,
    elbow_marker,
    wrist_marker
]

labels = []

for pose_index, pose in enumerate(CFG["poses"]):
    label = make_text(
        "LABEL_" + pose["name"],
        pose["label"],
        (0, 7.35, 1.8),
        size=0.54
    )
    labels.append(label)

legend = make_text(
    "MARKER_LEGEND",
    "RED shoulder   GREEN elbow   BLUE wrist",
    (0, -8.30, 1.8),
    size=0.34
)

for pose_index, pose in enumerate(CFG["poses"]):
    frame = int(pose["frame"])

    wrist_target = (
        float(pose["wrist_target"][0]),
        float(pose["wrist_target"][1])
    )

    elbow_world = solve_ik(
        (
            float(shoulder_world[0]),
            float(shoulder_world[1])
        ),
        wrist_target,
        upper_length,
        lower_length
    )

    desired_upper = math.atan2(
        elbow_world[1] - float(shoulder_world[1]),
        elbow_world[0] - float(shoulder_world[0])
    )

    desired_lower = math.atan2(
        wrist_target[1] - elbow_world[1],
        wrist_target[0] - elbow_world[0]
    )

    upper_rotation = desired_upper - upper_natural_angle

    # Lower arm is parented below the rotated upper arm.
    lower_local_rotation = (
        desired_lower
        - upper_rotation
        - lower_natural_angle
    )

    desired_hand_world = math.radians(
        float(pose["hand_world_rotation_degrees"])
    )

    lower_world_rotation = (
        upper_rotation + lower_local_rotation
    )

    hand_local_rotation = (
        desired_hand_world - lower_world_rotation
    )

    key_rotation(
        upper_arm,
        frame,
        math.degrees(upper_rotation)
    )
    key_rotation(
        lower_arm,
        frame,
        math.degrees(lower_local_rotation)
    )
    key_rotation(
        hand,
        frame,
        math.degrees(hand_local_rotation)
    )

    for label_index, label in enumerate(labels):
        key_visibility(
            label,
            frame,
            label_index == pose_index
        )

# Hold final pose through frame 90.
final_pose = CFG["poses"][-1]
for obj in [upper_arm, lower_arm, hand]:
    obj.keyframe_insert(
        data_path="rotation_euler",
        index=2,
        frame=int(CFG["frames"])
    )

for label_index, label in enumerate(labels):
    key_visibility(
        label,
        int(CFG["frames"]),
        label_index == len(labels) - 1
    )

for obj in [upper_arm, lower_arm, hand] + labels:
    set_constant_interpolation(obj)

# Save an editable calibration .blend before rendering.
scene.frame_set(1)
blend_path = OUTPUT / "short02_arm_calibration_v3.blend"
bpy.ops.wm.save_as_mainfile(filepath=str(blend_path))

# ------------------------------------------------------------
# Render marker stills and clean stills at full resolution.
# ------------------------------------------------------------
image_settings = scene.render.image_settings

if hasattr(image_settings, "media_type"):
    image_settings.media_type = "IMAGE"

image_settings.file_format = "PNG"
scene.render.resolution_percentage = int(
    CFG["still_resolution_percentage"]
)

for pose in CFG["poses"]:
    frame = int(pose["frame"])
    scene.frame_set(frame)

    for marker in marker_objects:
        marker.hide_render = False
    legend.hide_render = False

    marker_path = OUTPUT / (
        "pose_" + pose["name"].lower() + "_markers.png"
    )
    scene.render.filepath = str(marker_path)
    bpy.ops.render.render(write_still=True)

    for marker in marker_objects:
        marker.hide_render = True
    legend.hide_render = True

    clean_path = OUTPUT / (
        "pose_" + pose["name"].lower() + "_clean.png"
    )
    scene.render.filepath = str(clean_path)
    bpy.ops.render.render(write_still=True)

# Restore marker visibility for the comparison video.
for marker in marker_objects:
    marker.hide_render = False
legend.hide_render = False

# ------------------------------------------------------------
# Render 3-second pose comparison video.
# ------------------------------------------------------------
scene.frame_set(1)
scene.render.resolution_percentage = int(
    CFG["video_resolution_percentage"]
)

if hasattr(image_settings, "media_type"):
    image_settings.media_type = "VIDEO"
else:
    image_settings.file_format = "FFMPEG"

set_first_supported(
    scene.render.ffmpeg,
    "format",
    ["MPEG4", "MATROSKA"]
)
set_first_supported(
    scene.render.ffmpeg,
    "codec",
    ["H264", "MPEG4"]
)

try:
    if "MEDIUM" in enum_values(
        scene.render.ffmpeg,
        "constant_rate_factor"
    ):
        scene.render.ffmpeg.constant_rate_factor = "MEDIUM"
except Exception:
    pass

video_path = OUTPUT / "short02_arm_calibration_v3_markers.mp4"
scene.render.filepath = str(video_path)
bpy.ops.render.render(animation=True)

print("BLENDER2D_ARM_CALIBRATION_V3_DONE")
print("Blend:", blend_path)
print("Video:", video_path)
