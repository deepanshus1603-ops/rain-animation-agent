# Short #2 — Blender 2D Arm Calibration V3

This package does **not** animate the arm yet.

It first fixes the structural problems found in V2 and renders three static
poses for approval.

## What changed from V2

### 1. Duplicate arm removed

The original torso image already contained both arms. V3 includes:

    assets\torso_phone_arm_removed.png

Only the phone-side arm is removed from the torso. The separate arm rig now
occupies that space.

### 2. True pivot-based image planes

Each PNG plane has its Blender origin at the real artwork joint:

- upper arm origin = shoulder
- lower arm origin = elbow
- hand origin = wrist

The image no longer rotates around its center.

### 3. Correct hierarchy

```text
SHOULDER_CTRL
└── UPPER_ARM_PHONE
    └── ELBOW_CTRL
        └── LOWER_ARM_PHONE
            └── WRIST_CTRL
                └── HAND_AND_PHONE
```

### 4. No duplicate phone

`hand_phone.png` already contains the phone. The oversized separate phone
object from V2 is not used.

### 5. Code-calculated 2D IK

The script calculates the elbow position from:

- fixed shoulder
- requested wrist target
- upper-arm length
- forearm length

It does not use guessed shoulder/elbow rotations.

## Three calibration poses

### Pose A — rest / phone low

Checks the natural shoulder connection and low arm position.

### Pose B — halfway

Checks whether the elbow bends in the correct direction.

### Pose C — phone near chest

Checks the final phone-reading pose before animation is added.

## Joint markers

- red = shoulder
- green = elbow
- blue = wrist

## Run

Open PowerShell inside the extracted folder:

```powershell
.\run_calibration.ps1
```

You may also run:

```text
run_calibration.bat
```

## Outputs

```text
output\short02_arm_calibration_v3.blend
output\short02_arm_calibration_v3_markers.mp4

output\pose_a_rest_markers.png
output\pose_b_halfway_markers.png
output\pose_c_phone_markers.png

output\pose_a_rest_clean.png
output\pose_b_halfway_clean.png
output\pose_c_phone_clean.png
```

## Review before animation

Check only these points:

1. Does the upper arm emerge naturally from the shoulder?
2. Is the green elbow at the real elbow joint?
3. Does the forearm connect without a gap?
4. Does the blue wrist align with the hand?
5. Is Pose C a believable phone-reading pose?

Do not add keyframed movement until the static anatomy is approved.

## Configuration

The positions and pivots are stored in:

```text
arm_calibration_config.json
```

The Blender build is fully code-controlled.
