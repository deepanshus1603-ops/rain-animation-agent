$project = Split-Path -Parent $MyInvocation.MyCommand.Path
$blend = Join-Path $project "output\short02_arm_calibration_v3.blend"

if (-not (Test-Path $blend)) {
    Write-Host "Run .\run_calibration.ps1 first." -ForegroundColor Yellow
    exit 1
}

$blender = "C:\Program Files\Blender Foundation\Blender 5.2\blender.exe"

if (-not (Test-Path $blender)) {
    $found = Get-ChildItem "C:\Program Files\Blender Foundation" `
        -Filter blender.exe -Recurse -ErrorAction SilentlyContinue |
        Select-Object -First 1

    if ($found) {
        $blender = $found.FullName
    }
}

& $blender $blend
