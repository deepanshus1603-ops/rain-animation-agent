$ErrorActionPreference = "Stop"

$project = Split-Path -Parent $MyInvocation.MyCommand.Path
$script = Join-Path $project "scripts\build_and_render_arm_calibration_v3.py"
$outputDir = Join-Path $project "output"

$blendOut = Join-Path $outputDir "short02_arm_calibration_v3.blend"
$videoOut = Join-Path $outputDir "short02_arm_calibration_v3_markers.mp4"

$requiredStills = @(
    "pose_a_rest_markers.png",
    "pose_b_halfway_markers.png",
    "pose_c_phone_markers.png"
)

$blender = $null

$cmd = Get-Command blender -ErrorAction SilentlyContinue
if ($cmd) {
    $blender = $cmd.Source
}

if (-not $blender) {
    $known = @(
        "C:\Program Files\Blender Foundation\Blender 5.2\blender.exe",
        "C:\Program Files\Blender Foundation\Blender 5.1\blender.exe",
        "C:\Program Files\Blender Foundation\Blender 5.0\blender.exe",
        "C:\Program Files\Blender Foundation\Blender 4.5\blender.exe"
    )

    foreach ($candidate in $known) {
        if (Test-Path $candidate) {
            $blender = $candidate
            break
        }
    }
}

if (-not $blender -and (Test-Path "C:\Program Files\Blender Foundation")) {
    $found = Get-ChildItem "C:\Program Files\Blender Foundation" `
        -Filter blender.exe -Recurse -ErrorAction SilentlyContinue |
        Select-Object -First 1

    if ($found) {
        $blender = $found.FullName
    }
}

if (-not $blender) {
    Write-Host "FAILED: Blender executable not found." -ForegroundColor Red
    exit 1
}

Write-Host "Using Blender: $blender" -ForegroundColor Cyan
Write-Host "Rendering arm calibration poses..." -ForegroundColor Cyan

New-Item -ItemType Directory -Force -Path $outputDir | Out-Null

& $blender --background --python $script

if ($LASTEXITCODE -ne 0) {
    Write-Host ""
    Write-Host "FAILED: Blender returned exit code $LASTEXITCODE." -ForegroundColor Red
    exit $LASTEXITCODE
}

if (-not (Test-Path $blendOut)) {
    Write-Host "FAILED: Calibration .blend was not created." -ForegroundColor Red
    exit 2
}

if (-not (Test-Path $videoOut)) {
    Write-Host "FAILED: Calibration MP4 was not created." -ForegroundColor Red
    exit 3
}

foreach ($fileName in $requiredStills) {
    $filePath = Join-Path $outputDir $fileName

    if (-not (Test-Path $filePath)) {
        Write-Host "FAILED: Missing $fileName" -ForegroundColor Red
        exit 4
    }
}

Write-Host ""
Write-Host "SUCCESS" -ForegroundColor Green
Write-Host "Blend: output\short02_arm_calibration_v3.blend"
Write-Host "Video: output\short02_arm_calibration_v3_markers.mp4"
Write-Host "Stills: output\pose_*_markers.png and output\pose_*_clean.png"
